# ============================================================
# YYC3 Hacker Chatbot — EditorConfig
# setup.sh copies this to .editorconfig
# https://editorconfig.org
# ============================================================

root = true

[*]
charset = utf-8
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true
indent_style = space
indent_size = 2

[*.md]
trim_trailing_whitespace = false
max_line_length = off

[*.{json,jsonc}]
indent_size = 2

[*.{ts,tsx}]
indent_size = 2
quote_type = single

[*.{css,scss}]
indent_size = 2

[*.{yaml,yml}]
indent_size = 2

[*.sh]
indent_size = 2
end_of_line = lf

[Makefile]
indent_style = tab
