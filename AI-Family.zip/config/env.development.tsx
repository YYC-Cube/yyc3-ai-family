# ============================================================
# YYC3 Hacker Chatbot — Development Environment
# Auto-loaded by: pnpm dev  (vite --mode development)
# setup.sh copies this to .env.development
#
# Personal overrides: copy to .env.development.local
# ============================================================

# --- NAS (dev mode: NAS may be offline, auto-degrades to localStorage) ---
VITE_NAS_HOST=192.168.3.45
VITE_NAS_SQLITE_PORT=8484
VITE_NAS_DOCKER_PORT=2375
VITE_HEARTBEAT_WS_HOST=192.168.3.45
VITE_HEARTBEAT_WS_PORT=9090
VITE_HEARTBEAT_WS_PATH=/ws/heartbeat

# --- Cluster Devices ---
VITE_DEVICE_M4_MAX=192.168.3.22
VITE_DEVICE_IMAC_M4=192.168.3.77
VITE_DEVICE_MATEBOOK=192.168.3.66
VITE_DEVICE_NAS=192.168.3.45

# --- LLM Keys (leave empty; configure in UI Settings) ---
VITE_OPENAI_API_KEY=
VITE_ANTHROPIC_API_KEY=
VITE_DEEPSEEK_API_KEY=
VITE_ZHIPU_API_KEY=
VITE_GOOGLE_API_KEY=
VITE_GROQ_API_KEY=

# --- Local LLM ---
VITE_OLLAMA_HOST=localhost
VITE_OLLAMA_PORT=11434
VITE_LMSTUDIO_HOST=localhost
VITE_LMSTUDIO_PORT=1234

# --- App Config (dev: debug logging enabled) ---
VITE_PERSISTENCE_STRATEGY=localStorage
VITE_METRICS_ARCHIVE_INTERVAL=30000
VITE_HEARTBEAT_SIMULATION_INTERVAL=8000
VITE_LOG_LEVEL=debug

# --- Backend (usually disabled in dev) ---
VITE_API_BASE_URL=http://localhost:3001/api
VITE_WS_URL=ws://localhost:3001/ws

# --- KB Backend (usually offline in dev) ---
VITE_KB_VECTOR_PORT=8090
VITE_KB_MULTIMODAL_PORT=8091
VITE_KB_NLP_PORT=8092
