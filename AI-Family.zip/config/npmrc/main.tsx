# ============================================================
# YYC3 Hacker Chatbot — pnpm / npm Configuration
# setup.sh copies this to .npmrc
# ============================================================

# Use pnpm as package manager
engine-strict=true

# Hoist dependencies (solve peer dep issues)
shamefully-hoist=true

# Network timeout (increase for slow connections)
fetch-timeout=60000

# Disable strict peer deps (avoid install failures)
strict-peer-dependencies=false

# Auto install peer dependencies
auto-install-peers=true

# Optional: China mirror (uncomment to enable)
# registry=https://registry.npmmirror.com
