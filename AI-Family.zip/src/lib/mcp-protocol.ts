// ============================================================
// YYC3 Hacker Chatbot — MCP Protocol Layer
// Phase 16.2: MCP 工具链真实化
// Phase 47:  MCP 工具真实闭环执行 (P0 Fix)
//
// 实现 Model Context Protocol (MCP) 标准:
//   - Tool Schema (tools/list, tools/call)
//   - Resource Schema (resources/list, resources/read)
//   - Prompt Schema (prompts/list, prompts/get)
//   - MCP Service Registry + Connection Management
//   - Preset Call Formats & Code Generation
//   - [Phase 47] Real Infrastructure Bridge (nas-client, pg-telemetry)
//   - [Phase 47] Rich Mock Data (structured JSON per tool)
//   - [Phase 47] Code Generator with real implementations
//
// 架构: 前端 MCP Client → JSON-RPC 2.0 → MCP Server (stdio/http)
//        ↓ (无后端时)
//        executeToolViaInfra() → Real NAS/Docker/PG API
//        ↓ (infra unreachable)
//        _toolMock() → Rich structured mock data
// ============================================================

import { encryptValue, decryptValue, isCryptoAvailable } from './crypto';

// ============================================================
// 1.1 Tool Execution Infrastructure Bridge (Phase 47)
// ============================================================

/**
 * Attempt to execute a tool via real infrastructure clients.
 * Returns null if real execution is not available, allowing fallback to rich mock.
 */
async function executeToolViaInfra(
  serverId: string,
  toolName: string,
  args: Record<string, unknown>
): Promise<MCPToolCallResult | null> {
  try {
    switch (serverId) {
      case 'mcp-yyc3-cluster':
        return await _execClusterTool(toolName, args);
      case 'mcp-postgres':
        return await _execPgTool(toolName, args);
      default:
        return null;
    }
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error);
    console.warn(`[MCP] Real execution failed for ${serverId}/${toolName}: ${msg}`);
    return null;
  }
}

async function _execClusterTool(toolName: string, args: Record<string, unknown>): Promise<MCPToolCallResult | null> {
  const { loadDeviceConfigs, pingDevice, docker, querySQLite, loadSQLiteConfig } = await import('./nas-client');
  switch (toolName) {
    case 'cluster_status': {
      const devices = loadDeviceConfigs();
      const node = (args.node as string) || 'all';
      const targets = node === 'all' ? devices : devices.filter(d => d.id === node);
      const settled = await Promise.allSettled(targets.map(async d => {
        const ping = await pingDevice(d);
        return { id: d.id, name: d.displayName, ip: d.ip, chip: d.chip, cores: d.cores, ram: d.ram, status: ping.reachable ? 'online' : 'offline', latencyMs: ping.latencyMs, services: d.services.filter(s => s.enabled).map(s => ({ name: s.name, port: s.port, status: s.status })) };
      }));
      const nodes = settled.filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled').map(r => r.value);
      return { content: [{ type: 'text', text: JSON.stringify({ cluster: 'yyc3-family', timestamp: new Date().toISOString(), nodes, summary: { total: nodes.length, online: nodes.filter((n: any) => n.status === 'online').length, offline: nodes.filter((n: any) => n.status === 'offline').length } }, null, 2) }] };
    }
    case 'docker_containers': {
      const action = args.action as string;
      const cid = args.container_id as string | undefined;
      if (action === 'list') {
        const cs = await docker.containers.list(true);
        return { content: [{ type: 'text', text: JSON.stringify({ action: 'list', timestamp: new Date().toISOString(), containers: cs.map(c => ({ id: c.Id.substring(0, 12), name: c.Names[0]?.replace(/^\//, ''), image: c.Image, state: c.State, status: c.Status, ports: c.Ports.map(p => p.PublicPort ? `${p.IP || '0.0.0.0'}:${p.PublicPort}->${p.PrivatePort}/${p.Type}` : `${p.PrivatePort}/${p.Type}`) })), total: cs.length, running: cs.filter(c => c.State === 'running').length }, null, 2) }] };
      }
      if (['start', 'stop', 'restart'].includes(action)) {
        if (!cid) return { content: [{ type: 'text', text: JSON.stringify({ error: 'container_id required' }) }], isError: true };
        if (action === 'start') await docker.containers.start(cid);
        else if (action === 'stop') await docker.containers.stop(cid);
        else await docker.containers.restart(cid);
        return { content: [{ type: 'text', text: JSON.stringify({ action, container_id: cid, success: true, timestamp: new Date().toISOString() }, null, 2) }] };
      }
      if (action === 'logs') {
        if (!cid) return { content: [{ type: 'text', text: JSON.stringify({ error: 'container_id required' }) }], isError: true };
        return { content: [{ type: 'text', text: await docker.containers.logs(cid, 50) }] };
      }
      return null;
    }
    case 'sqlite_query': {
      const sql = args.sql as string;
      if (!sql) return { content: [{ type: 'text', text: '{"error":"sql parameter required"}' }], isError: true };
      const cfg = loadSQLiteConfig();
      if (args.db_path) cfg.dbPath = args.db_path as string;
      const r = await querySQLite(sql, [], cfg);
      return { content: [{ type: 'text', text: JSON.stringify({ columns: r.columns, rows: r.rows, rowCount: r.rowCount, changesCount: r.changesCount }, null, 2) }] };
    }
    case 'system_diagnostics': {
      const devices = loadDeviceConfigs();
      const settled = await Promise.allSettled(devices.map(async d => ({ id: d.id, name: d.displayName, ...(await pingDevice(d)) })));
      const diag = settled.filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled').map(r => r.value);
      return { content: [{ type: 'text', text: JSON.stringify({ scope: args.scope || 'full', timestamp: new Date().toISOString(), network: { devices: diag, reachable: diag.filter((d: any) => d.reachable).length, unreachable: diag.filter((d: any) => !d.reachable).length }, recommendation: diag.every((d: any) => d.reachable) ? 'All nodes reachable. Cluster is healthy.' : `${diag.filter((d: any) => !d.reachable).map((d: any) => d.name).join(', ')} unreachable.` }, null, 2) }] };
    }
    case 'deploy_service': {
      return { content: [{ type: 'text', text: JSON.stringify({ action: 'deploy_service', dryRun: true, service: args.service_name, targetNode: args.target_node || 'auto', image: args.image, ports: args.ports || 'auto', steps: ['1. Pull image', '2. Create container', '3. Map ports', '4. Start container', '5. Health check (30s)'], estimatedTime: '45s' }, null, 2) }] };
    }
    default: return null;
  }
}

async function _execPgTool(toolName: string, args: Record<string, unknown>): Promise<MCPToolCallResult | null> {
  if (toolName !== 'query') return null;
  const sql = args.sql as string;
  if (!sql) return { content: [{ type: 'text', text: '{"error":"sql parameter required"}' }], isError: true };
  const upper = sql.trim().toUpperCase();
  if (!upper.startsWith('SELECT') && !upper.startsWith('WITH') && !upper.startsWith('EXPLAIN')) {
    return { content: [{ type: 'text', text: '{"error":"Only SELECT/WITH/EXPLAIN queries allowed (read-only)"}' }], isError: true };
  }
  const { getPgTelemetryConfig } = await import('./pg-telemetry-client');
  const cfg = getPgTelemetryConfig();
  if (!cfg.enabled) return null;
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), cfg.timeout);
  const res = await fetch(`${cfg.baseUrl}/query`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sql }), signal: ctrl.signal });
  clearTimeout(t);
  if (!res.ok) { const e = await res.text().catch(() => ''); return { content: [{ type: 'text', text: JSON.stringify({ error: `PG HTTP ${res.status}: ${e}` }) }], isError: true }; }
  return { content: [{ type: 'text', text: JSON.stringify(await res.json(), null, 2) }] };
}

// ============================================================
// 1.2 Rich Mock Data Generator (Phase 47)
// ============================================================

function _toolMock(serverId: string, toolName: string, args: Record<string, unknown>): MCPToolCallResult {
  const ts = new Date().toISOString();

  // --- mcp-filesystem ---
  if (serverId === 'mcp-filesystem') {
    if (toolName === 'read_file') {
      const p = args.path as string || '/unknown';
      const ext = p.split('.').pop()?.toLowerCase() || '';
      const samples: Record<string, string> = {
        ts: `// ${p}\nimport { Server } from "@modelcontextprotocol/sdk/server/index.js";\nconst server = new Server({ name: "yyc3", version: "1.0.0" });\n`,
        json: JSON.stringify({ name: 'yyc3-project', version: '1.0.0', dependencies: {} }, null, 2),
        md: `# ${p.split('/').pop()}\nProject documentation.`,
        py: `# ${p}\nimport os\ndef main(): print("YYC3")\nif __name__=="__main__": main()`,
      };
      return { content: [{ type: 'text', text: samples[ext] || `# Content of ${p}\n(mock — filesystem server not connected)` }] };
    }
    if (toolName === 'write_file') return { content: [{ type: 'text', text: JSON.stringify({ success: true, path: args.path, bytesWritten: ((args.content as string) || '').length, timestamp: ts }, null, 2) }] };
    if (toolName === 'list_directory') return { content: [{ type: 'text', text: JSON.stringify({ path: args.path || '/', entries: [{ name: 'src', type: 'directory' }, { name: 'docs', type: 'directory' }, { name: 'package.json', type: 'file', size: 1842 }, { name: 'tsconfig.json', type: 'file', size: 453 }, { name: 'docker-compose.yml', type: 'file', size: 2105 }], timestamp: ts }, null, 2) }] };
    if (toolName === 'search_files') return { content: [{ type: 'text', text: JSON.stringify({ pattern: args.pattern, matches: [{ path: '/src/lib/mcp-protocol.ts', line: 42, match: 'MCP Protocol' }, { path: '/src/lib/llm-bridge.ts', line: 18, match: 'LLM Bridge' }], totalMatches: 2, timestamp: ts }, null, 2) }] };
  }

  // --- mcp-postgres ---
  if (serverId === 'mcp-postgres' && toolName === 'query') {
    const sql = ((args.sql as string) || '').toUpperCase();
    if (sql.includes('INFORMATION_SCHEMA') || sql.includes('PG_TABLES')) {
      return { content: [{ type: 'text', text: JSON.stringify({ columns: ['schema', 'table_name', 'row_count'], rows: [['orchestration', 'agent_tasks', 1247], ['knowledge', 'documents', 3421], ['knowledge', 'embeddings', 28493], ['telemetry', 'metrics', 847293], ['telemetry', 'thermal_log', 124832], ['telemetry', 'alerts', 342], ['telemetry', 'latency_history', 93847]], rowCount: 7, note: 'mock data' }, null, 2) }] };
    }
    return { content: [{ type: 'text', text: JSON.stringify({ columns: ['id', 'node_id', 'cpu_percent', 'memory_percent', 'timestamp'], rows: [[1, 'm4-max', 23.4, 41.2, ts], [2, 'imac-m4', 12.8, 28.7, ts], [3, 'yanyucloud', 45.1, 62.3, ts]], rowCount: 3, note: 'mock data' }, null, 2) }] };
  }

  // --- mcp-yyc3-cluster ---
  if (serverId === 'mcp-yyc3-cluster') {
    if (toolName === 'cluster_status') {
      const node = (args.node as string) || 'all';
      const all = [
        { id: 'm4-max', name: 'MacBook Pro M4 Max', ip: '192.168.3.22', chip: 'Apple M4 Max', ram: '128GB', status: 'online', cpu: 23.4, memory: 41.2, latencyMs: 1 },
        { id: 'imac-m4', name: 'iMac M4', ip: '192.168.3.77', chip: 'Apple M4', ram: '32GB', status: 'online', cpu: 12.8, memory: 28.7, latencyMs: 2 },
        { id: 'matebook', name: 'MateBook X Pro', ip: '192.168.3.66', chip: 'Intel Ultra7', ram: '32GB', status: 'standby', cpu: 0, memory: 12.1, latencyMs: 0 },
        { id: 'yanyucloud', name: '铁威马 F4-423', ip: '192.168.3.45', chip: 'Intel Quad', ram: '32GB', status: 'online', cpu: 45.1, memory: 62.3, latencyMs: 3 },
      ];
      const nodes = node === 'all' ? all : all.filter(n => n.id === node);
      return { content: [{ type: 'text', text: JSON.stringify({ cluster: 'yyc3-family', timestamp: ts, nodes, summary: { total: nodes.length, online: nodes.filter(n => n.status === 'online').length } }, null, 2) }] };
    }
    if (toolName === 'docker_containers') {
      if ((args.action as string) === 'list') {
        return { content: [{ type: 'text', text: JSON.stringify({ action: 'list', timestamp: ts, containers: [{ id: 'a1b2c3', name: 'yyc3-postgres', image: 'postgres:16-alpine', state: 'running', status: 'Up 7d', ports: ['5432/tcp'] }, { id: 'b2c3d4', name: 'yyc3-redis', image: 'redis:7-alpine', state: 'running', status: 'Up 7d', ports: ['6379/tcp'] }, { id: 'c3d4e5', name: 'yyc3-sqlite-proxy', image: 'yyc3/sqlite-http', state: 'running', status: 'Up 3d', ports: ['8484/tcp'] }, { id: 'f6a1b2', name: 'yyc3-mcp-server', image: 'yyc3/mcp-server', state: 'exited', status: 'Exited 2h', ports: [] }], total: 4, running: 3 }, null, 2) }] };
      }
      return { content: [{ type: 'text', text: JSON.stringify({ action: args.action, container_id: args.container_id, success: true, timestamp: ts }, null, 2) }] };
    }
    if (toolName === 'sqlite_query') {
      return { content: [{ type: 'text', text: JSON.stringify({ sql: args.sql, columns: ['id', 'key', 'value', 'updated_at'], rows: [[1, 'cluster.health', '{"status":"healthy","score":97.3}', ts], [2, 'agent.sessions', '42', ts]], rowCount: 2, note: 'mock data' }, null, 2) }] };
    }
    if (toolName === 'system_diagnostics') {
      return { content: [{ type: 'text', text: JSON.stringify({ scope: args.scope || 'full', timestamp: ts, network: { devices: [{ id: 'm4-max', reachable: true, latencyMs: 0.3 }, { id: 'imac-m4', reachable: true, latencyMs: 1.2 }, { id: 'matebook', reachable: false, latencyMs: 0 }, { id: 'yanyucloud', reachable: true, latencyMs: 0.8 }] }, storage: { nas_raid6: { total: '32TB', used: '19.8TB', health: 'optimal' }, m4max_ssd: { total: '4TB', used: '1.8TB', health: 'optimal' } }, compute: { totalCores: 82, totalRam: '224GB', loadAvg: [2.1, 1.8, 1.5] }, security: { firewallActive: true, threats: 0, sslValid: true }, recommendation: 'All systems nominal.' }, null, 2) }] };
    }
    if (toolName === 'deploy_service') {
      return { content: [{ type: 'text', text: JSON.stringify({ action: 'deploy_service', dryRun: true, service: args.service_name, target: args.target_node || 'auto', image: args.image, steps: ['Pull image', 'Create container', 'Map ports', 'Start', 'Health check'], estimatedTime: '45s' }, null, 2) }] };
    }
  }

  // --- mcp-github ---
  if (serverId === 'mcp-github') {
    if (toolName === 'search_repositories') return { content: [{ type: 'text', text: JSON.stringify({ query: args.query, total_count: 3, items: [{ full_name: 'user/yyc3-hacker-chatbot', description: 'YYC3 DevOps Platform', stars: 42, language: 'TypeScript' }, { full_name: 'user/yyc3-mcp-server', description: 'MCP Server', stars: 12, language: 'Python' }] }, null, 2) }] };
    if (toolName === 'create_issue') return { content: [{ type: 'text', text: JSON.stringify({ number: 142, title: args.title, state: 'open', html_url: `https://github.com/${args.owner}/${args.repo}/issues/142`, created_at: ts }, null, 2) }] };
    if (toolName === 'get_file_contents') return { content: [{ type: 'text', text: JSON.stringify({ name: (args.path as string)?.split('/').pop(), path: args.path, type: 'file', size: 2048, note: 'mock data' }, null, 2) }] };
  }

  // --- mcp-web-search ---
  if (serverId === 'mcp-web-search') {
    const q = args.query as string || 'search';
    if (toolName === 'brave_web_search') return { content: [{ type: 'text', text: JSON.stringify({ query: q, results: [{ title: `${q} - Docs`, url: `https://docs.example.com/${q.replace(/\s+/g, '-')}`, description: `Guide for ${q}` }, { title: `${q} - GitHub`, url: `https://github.com/topics/${q.replace(/\s+/g, '-')}` }], total: 2, note: 'mock data' }, null, 2) }] };
    if (toolName === 'brave_local_search') return { content: [{ type: 'text', text: JSON.stringify({ query: q, results: [], total: 0, note: 'mock data' }, null, 2) }] };
  }

  // Generic fallback
  return { content: [{ type: 'text', text: JSON.stringify({ tool: toolName, server: serverId, args, timestamp: ts, note: 'No specific mock for this tool. Connect to real MCP server for actual results.' }, null, 2) }] };
}

/**
 * Rich resource mock data
 */
function _resourceMock(uri: string): string {
  const ts = new Date().toISOString();
  if (uri.includes('metrics/cluster')) return JSON.stringify({ cluster: 'yyc3-family', health: 'healthy', score: 97.3, nodes: { 'm4-max': { cpu: 23.4, mem: 41.2 }, 'imac-m4': { cpu: 12.8, mem: 28.7 }, 'yanyucloud': { cpu: 45.1, mem: 62.3 } }, timestamp: ts }, null, 2);
  if (uri.includes('projects/list')) return JSON.stringify({ projects: [{ id: 'yyc3-hacker-chatbot', status: 'active', lang: 'TypeScript' }, { id: 'yyc3-mcp-server', status: 'active', lang: 'Python' }, { id: 'yyc3-pg-proxy', status: 'deployed', lang: 'Go' }], total: 3 }, null, 2);
  if (uri.includes('logs/recent')) return JSON.stringify({ logs: [{ level: 'info', source: 'MCP', message: 'Server initialized', ts }, { level: 'info', source: 'Docker', message: 'yyc3-postgres health OK', ts }, { level: 'warn', source: 'NAS', message: 'RAID6 scrub scheduled', ts }] }, null, 2);
  if (uri.includes('docker/containers')) return JSON.stringify({ containers: [{ name: 'yyc3-postgres', state: 'running', uptime: '7d' }, { name: 'yyc3-redis', state: 'running', uptime: '7d' }, { name: 'yyc3-sqlite-proxy', state: 'running', uptime: '3d' }] }, null, 2);
  if (uri.includes('config/devices')) return JSON.stringify({ devices: [{ id: 'm4-max', ip: '192.168.3.22', role: 'Orchestrator' }, { id: 'imac-m4', ip: '192.168.3.77', role: 'Visual' }, { id: 'yanyucloud', ip: '192.168.3.45', role: 'Data Center' }] }, null, 2);
  if (uri.includes('schema')) return JSON.stringify({ schemas: ['orchestration', 'knowledge', 'telemetry'], tables: { orchestration: ['agent_tasks', 'workflow_runs'], knowledge: ['documents', 'embeddings'], telemetry: ['metrics', 'thermal_log', 'alerts', 'latency_history'] }, database: 'yyc3_devops', version: 'PG15' }, null, 2);
  return JSON.stringify({ uri, data: 'Resource content', timestamp: ts }, null, 2);
}

// ============================================================
// 1. MCP JSON-RPC 2.0 Types
// ============================================================

export interface MCPJsonRpcRequest {
  jsonrpc: '2.0';
  id: string | number;
  method: string;
  params?: Record<string, unknown>;
}

export interface MCPJsonRpcResponse {
  jsonrpc: '2.0';
  id: string | number;
  result?: unknown;
  error?: {
    code: number;
    message: string;
    data?: unknown;
  };
}

// ============================================================
// 2. MCP Tool Schema
// ============================================================

export interface MCPToolParameter {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object' | 'array';
  description: string;
  required: boolean;
  default?: unknown;
  enum?: string[];
}

export interface MCPTool {
  name: string;
  description: string;
  inputSchema: {
    type: 'object';
    properties: Record<string, {
      type: string;
      description?: string;
      enum?: string[];
      default?: unknown;
    }>;
    required?: string[];
  };
  annotations?: {
    title?: string;
    readOnlyHint?: boolean;
    destructiveHint?: boolean;
    idempotentHint?: boolean;
    openWorldHint?: boolean;
  };
}

export interface MCPToolCallRequest {
  name: string;
  arguments: Record<string, unknown>;
}

export interface MCPToolCallResult {
  content: Array<{
    type: 'text' | 'image' | 'resource';
    text?: string;
    data?: string;
    mimeType?: string;
    resource?: { uri: string; text?: string; blob?: string };
  }>;
  isError?: boolean;
}

// ============================================================
// 3. MCP Resource Schema
// ============================================================

export interface MCPResource {
  uri: string;
  name: string;
  description?: string;
  mimeType?: string;
  annotations?: {
    audience?: string[];
    priority?: number;
  };
}

export interface MCPResourceTemplate {
  uriTemplate: string;
  name: string;
  description?: string;
  mimeType?: string;
}

export interface MCPResourceContent {
  uri: string;
  mimeType?: string;
  text?: string;
  blob?: string;
}

// ============================================================
// 4. MCP Prompt Schema
// ============================================================

export interface MCPPrompt {
  name: string;
  description?: string;
  arguments?: Array<{
    name: string;
    description?: string;
    required?: boolean;
  }>;
}

export interface MCPPromptMessage {
  role: 'user' | 'assistant';
  content: {
    type: 'text' | 'image' | 'resource';
    text?: string;
    data?: string;
    mimeType?: string;
    resource?: { uri: string; text?: string };
  };
}

// ============================================================
// 5. MCP Server Definition
// ============================================================

export type MCPTransport = 'stdio' | 'http-sse' | 'streamable-http';

export interface MCPServerDefinition {
  id: string;
  name: string;
  version: string;
  description: string;
  transport: MCPTransport;
  command?: string;        // for stdio: e.g., "npx", "node", "python"
  args?: string[];         // for stdio: arguments
  env?: Record<string, string>;
  url?: string;            // for http transports
  // Capabilities
  capabilities: {
    tools: boolean;
    resources: boolean;
    prompts: boolean;
    logging: boolean;
    sampling: boolean;
  };
  // Registered items
  tools: MCPTool[];
  resources: MCPResource[];
  resourceTemplates: MCPResourceTemplate[];
  prompts: MCPPrompt[];
  // Status
  status: 'connected' | 'disconnected' | 'error' | 'initializing';
  lastConnected?: number;
  error?: string;
  // Metadata
  category: 'builtin' | 'community' | 'custom';
  tags: string[];
  icon?: string;
  color?: string;
  createdAt: string;
  updatedAt: string;
  encrypted?: boolean;     // Phase 35: encryption status flag for env vars
}

// ============================================================
// 6. Preset MCP Server Templates
// ============================================================

export const MCP_SERVER_PRESETS: MCPServerDefinition[] = [
  {
    id: 'mcp-filesystem',
    name: 'Filesystem',
    version: '1.0.0',
    description: 'MCP Filesystem Server - Secure file operations with configurable access controls',
    transport: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-filesystem', '/Users/dev/projects'],
    capabilities: { tools: true, resources: true, prompts: false, logging: true, sampling: false },
    tools: [
      {
        name: 'read_file',
        description: 'Read the complete contents of a file from the file system',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Path to the file to read' },
          },
          required: ['path'],
        },
      },
      {
        name: 'write_file',
        description: 'Create a new file or completely overwrite an existing file',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Path to write the file' },
            content: { type: 'string', description: 'Content to write' },
          },
          required: ['path', 'content'],
        },
        annotations: { destructiveHint: true },
      },
      {
        name: 'list_directory',
        description: 'Get a detailed listing of files and directories in a given path',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Directory path to list' },
          },
          required: ['path'],
        },
        annotations: { readOnlyHint: true },
      },
      {
        name: 'search_files',
        description: 'Recursively search for files matching a pattern',
        inputSchema: {
          type: 'object',
          properties: {
            path: { type: 'string', description: 'Starting directory' },
            pattern: { type: 'string', description: 'Search pattern (regex)' },
          },
          required: ['path', 'pattern'],
        },
        annotations: { readOnlyHint: true },
      },
    ],
    resources: [
      { uri: 'file:///Users/dev/projects', name: 'Project Root', description: 'Root project directory', mimeType: 'inode/directory' },
    ],
    resourceTemplates: [
      { uriTemplate: 'file:///{path}', name: 'File Content', description: 'Read any accessible file', mimeType: 'text/plain' },
    ],
    prompts: [],
    status: 'disconnected',
    category: 'community',
    tags: ['filesystem', 'files', 'io'],
    icon: 'folder',
    color: 'text-blue-400',
    createdAt: '2026-02-14T00:00:00Z',
    updatedAt: '2026-02-14T00:00:00Z',
  },
  {
    id: 'mcp-postgres',
    name: 'PostgreSQL',
    version: '1.0.0',
    description: 'MCP PostgreSQL Server - Read-only database access with schema inspection',
    transport: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-postgres', 'postgresql://yyc3_admin@localhost/yyc3_devops'],
    capabilities: { tools: true, resources: true, prompts: false, logging: true, sampling: false },
    tools: [
      {
        name: 'query',
        description: 'Run a read-only SQL query against the connected database',
        inputSchema: {
          type: 'object',
          properties: {
            sql: { type: 'string', description: 'SQL query to execute (SELECT only)' },
          },
          required: ['sql'],
        },
        annotations: { readOnlyHint: true },
      },
    ],
    resources: [
      { uri: 'postgres://localhost/yyc3_devops/schema', name: 'Database Schema', description: 'Complete database schema', mimeType: 'application/json' },
    ],
    resourceTemplates: [
      { uriTemplate: 'postgres://localhost/yyc3_devops/tables/{table}', name: 'Table Schema', description: 'Schema for a specific table' },
    ],
    prompts: [],
    status: 'disconnected',
    category: 'community',
    tags: ['database', 'sql', 'postgres'],
    icon: 'database',
    color: 'text-cyan-400',
    createdAt: '2026-02-14T00:00:00Z',
    updatedAt: '2026-02-14T00:00:00Z',
  },
  {
    id: 'mcp-yyc3-cluster',
    name: 'YYC3 Cluster',
    version: '1.0.0',
    description: 'YYC3 Custom MCP Server - Cluster management, metrics, Docker operations',
    transport: 'stdio',
    command: 'node',
    args: ['./mcp-server/index.js'],
    env: {
      NAS_HOST: '192.168.3.45',
      NAS_PORT: '9898',
      DOCKER_PORT: '2375',
    },
    capabilities: { tools: true, resources: true, prompts: true, logging: true, sampling: true },
    tools: [
      {
        name: 'cluster_status',
        description: 'Get real-time health and metrics for all cluster nodes',
        inputSchema: {
          type: 'object',
          properties: {
            node: { type: 'string', description: 'Specific node ID or "all"', enum: ['all', 'm4-max', 'imac-m4', 'matebook', 'yanyucloud'] },
          },
        },
      },
      {
        name: 'docker_containers',
        description: 'List and manage Docker containers on NAS',
        inputSchema: {
          type: 'object',
          properties: {
            action: { type: 'string', description: 'Action to perform', enum: ['list', 'start', 'stop', 'restart', 'logs'] },
            container_id: { type: 'string', description: 'Container ID (for start/stop/restart/logs)' },
          },
          required: ['action'],
        },
      },
      {
        name: 'sqlite_query',
        description: 'Execute SQL query on NAS SQLite database',
        inputSchema: {
          type: 'object',
          properties: {
            sql: { type: 'string', description: 'SQL query to execute' },
            db_path: { type: 'string', description: 'Database file path on NAS' },
          },
          required: ['sql'],
        },
      },
      {
        name: 'system_diagnostics',
        description: 'Run comprehensive system diagnostics across the cluster',
        inputSchema: {
          type: 'object',
          properties: {
            scope: { type: 'string', description: 'Diagnostic scope', enum: ['full', 'network', 'storage', 'compute', 'security'] },
          },
        },
      },
      {
        name: 'deploy_service',
        description: 'Deploy or update a service on the cluster',
        inputSchema: {
          type: 'object',
          properties: {
            service_name: { type: 'string', description: 'Service to deploy' },
            target_node: { type: 'string', description: 'Target deployment node' },
            image: { type: 'string', description: 'Docker image' },
            ports: { type: 'string', description: 'Port mapping (e.g., "8080:80")' },
          },
          required: ['service_name', 'image'],
        },
        annotations: { destructiveHint: true },
      },
    ],
    resources: [
      { uri: 'yyc3://metrics/cluster', name: 'Cluster Metrics', description: 'Real-time cluster health metrics', mimeType: 'application/json' },
      { uri: 'yyc3://projects/list', name: 'Project Registry', description: 'All registered YYC3 projects', mimeType: 'application/json' },
      { uri: 'yyc3://logs/recent', name: 'Recent Logs', description: 'Last 100 system log entries', mimeType: 'application/json' },
      { uri: 'yyc3://docker/containers', name: 'Docker Containers', description: 'NAS Docker container list', mimeType: 'application/json' },
      { uri: 'yyc3://config/devices', name: 'Device Configs', description: 'Cluster device configurations', mimeType: 'application/json' },
    ],
    resourceTemplates: [
      { uriTemplate: 'yyc3://metrics/{node_id}/{metric_type}', name: 'Node Metric', description: 'Specific metric for a node' },
      { uriTemplate: 'yyc3://docker/containers/{id}/logs', name: 'Container Logs', description: 'Logs for a specific container' },
    ],
    prompts: [
      {
        name: 'cluster_report',
        description: 'Generate a comprehensive cluster health report',
        arguments: [
          { name: 'timeframe', description: 'Report timeframe (1h, 6h, 24h, 7d)', required: false },
          { name: 'format', description: 'Output format (markdown, json, text)', required: false },
        ],
      },
      {
        name: 'incident_response',
        description: 'Guide through incident response for a cluster issue',
        arguments: [
          { name: 'severity', description: 'Incident severity (low, medium, high, critical)', required: true },
          { name: 'affected_node', description: 'Which node is affected', required: true },
        ],
      },
    ],
    status: 'disconnected',
    category: 'custom',
    tags: ['cluster', 'docker', 'nas', 'metrics', 'devops'],
    icon: 'server',
    color: 'text-amber-400',
    createdAt: '2026-02-14T00:00:00Z',
    updatedAt: '2026-02-14T00:00:00Z',
  },
  {
    id: 'mcp-github',
    name: 'GitHub',
    version: '1.0.0',
    description: 'MCP GitHub Server - Repository management, issues, PRs, and code search',
    transport: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-github'],
    env: { GITHUB_PERSONAL_ACCESS_TOKEN: 'YOUR_GITHUB_TOKEN' },
    capabilities: { tools: true, resources: true, prompts: false, logging: false, sampling: false },
    tools: [
      {
        name: 'search_repositories',
        description: 'Search for GitHub repositories',
        inputSchema: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Search query' },
            page: { type: 'number', description: 'Page number' },
          },
          required: ['query'],
        },
        annotations: { readOnlyHint: true },
      },
      {
        name: 'create_issue',
        description: 'Create a new issue in a GitHub repository',
        inputSchema: {
          type: 'object',
          properties: {
            owner: { type: 'string', description: 'Repository owner' },
            repo: { type: 'string', description: 'Repository name' },
            title: { type: 'string', description: 'Issue title' },
            body: { type: 'string', description: 'Issue body' },
          },
          required: ['owner', 'repo', 'title'],
        },
      },
      {
        name: 'get_file_contents',
        description: 'Get contents of a file or directory from a repository',
        inputSchema: {
          type: 'object',
          properties: {
            owner: { type: 'string', description: 'Repository owner' },
            repo: { type: 'string', description: 'Repository name' },
            path: { type: 'string', description: 'File or directory path' },
            branch: { type: 'string', description: 'Branch name' },
          },
          required: ['owner', 'repo', 'path'],
        },
        annotations: { readOnlyHint: true },
      },
    ],
    resources: [],
    resourceTemplates: [
      { uriTemplate: 'github://{owner}/{repo}', name: 'Repository', description: 'GitHub repository' },
      { uriTemplate: 'github://{owner}/{repo}/issues', name: 'Issues', description: 'Repository issues' },
    ],
    prompts: [],
    status: 'disconnected',
    category: 'community',
    tags: ['github', 'git', 'code', 'repository'],
    icon: 'github',
    color: 'text-zinc-300',
    createdAt: '2026-02-14T00:00:00Z',
    updatedAt: '2026-02-14T00:00:00Z',
  },
  {
    id: 'mcp-web-search',
    name: 'Web Search',
    version: '1.0.0',
    description: 'MCP Web Search Server - Brave Search API integration for web and local search',
    transport: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-brave-search'],
    env: { BRAVE_API_KEY: 'YOUR_BRAVE_API_KEY' },
    capabilities: { tools: true, resources: false, prompts: false, logging: false, sampling: false },
    tools: [
      {
        name: 'brave_web_search',
        description: 'Perform a web search using Brave Search API',
        inputSchema: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Search query' },
            count: { type: 'number', description: 'Number of results (max 20)' },
          },
          required: ['query'],
        },
        annotations: { readOnlyHint: true, openWorldHint: true },
      },
      {
        name: 'brave_local_search',
        description: 'Search for local businesses and places',
        inputSchema: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'Local search query' },
            count: { type: 'number', description: 'Number of results' },
          },
          required: ['query'],
        },
        annotations: { readOnlyHint: true },
      },
    ],
    resources: [],
    resourceTemplates: [],
    prompts: [],
    status: 'disconnected',
    category: 'community',
    tags: ['search', 'web', 'brave'],
    icon: 'search',
    color: 'text-orange-400',
    createdAt: '2026-02-14T00:00:00Z',
    updatedAt: '2026-02-14T00:00:00Z',
  },
];

// ============================================================
// 7. MCP Call Format Presets
// ============================================================

export interface MCPCallPreset {
  id: string;
  name: string;
  description: string;
  method: string;
  paramsTemplate: Record<string, unknown>;
  exampleResponse: unknown;
  category: 'lifecycle' | 'tools' | 'resources' | 'prompts' | 'utilities';
}

export const MCP_CALL_PRESETS: MCPCallPreset[] = [
  // Lifecycle
  {
    id: 'initialize',
    name: 'Initialize',
    description: 'Initialize MCP connection with capability negotiation',
    method: 'initialize',
    category: 'lifecycle',
    paramsTemplate: {
      protocolVersion: '2025-03-26',
      capabilities: {
        roots: { listChanged: true },
        sampling: {},
      },
      clientInfo: {
        name: 'yyc3-hacker-chatbot',
        version: '1.0.0',
      },
    },
    exampleResponse: {
      protocolVersion: '2025-03-26',
      capabilities: { tools: { listChanged: true }, resources: { subscribe: true, listChanged: true } },
      serverInfo: { name: 'yyc3-cluster', version: '1.0.0' },
    },
  },
  {
    id: 'ping',
    name: 'Ping',
    description: 'Health check ping to verify server is alive',
    method: 'ping',
    category: 'lifecycle',
    paramsTemplate: {},
    exampleResponse: {},
  },
  // Tools
  {
    id: 'tools-list',
    name: 'List Tools',
    description: 'Enumerate all available tools from the server',
    method: 'tools/list',
    category: 'tools',
    paramsTemplate: {},
    exampleResponse: {
      tools: [
        { name: 'cluster_status', description: 'Get cluster health', inputSchema: { type: 'object', properties: {} } },
      ],
    },
  },
  {
    id: 'tools-call',
    name: 'Call Tool',
    description: 'Invoke a specific tool with arguments',
    method: 'tools/call',
    category: 'tools',
    paramsTemplate: {
      name: 'tool_name',
      arguments: {},
    },
    exampleResponse: {
      content: [{ type: 'text', text: 'Tool execution result...' }],
    },
  },
  // Resources
  {
    id: 'resources-list',
    name: 'List Resources',
    description: 'Enumerate available resources from the server',
    method: 'resources/list',
    category: 'resources',
    paramsTemplate: {},
    exampleResponse: {
      resources: [
        { uri: 'yyc3://metrics/cluster', name: 'Cluster Metrics', mimeType: 'application/json' },
      ],
    },
  },
  {
    id: 'resources-read',
    name: 'Read Resource',
    description: 'Read a specific resource by URI',
    method: 'resources/read',
    category: 'resources',
    paramsTemplate: {
      uri: 'yyc3://metrics/cluster',
    },
    exampleResponse: {
      contents: [{ uri: 'yyc3://metrics/cluster', mimeType: 'application/json', text: '{"status":"healthy"}' }],
    },
  },
  {
    id: 'resources-templates',
    name: 'List Resource Templates',
    description: 'Get URI templates for parameterized resources',
    method: 'resources/templates/list',
    category: 'resources',
    paramsTemplate: {},
    exampleResponse: {
      resourceTemplates: [
        { uriTemplate: 'yyc3://metrics/{node_id}', name: 'Node Metrics' },
      ],
    },
  },
  // Prompts
  {
    id: 'prompts-list',
    name: 'List Prompts',
    description: 'Enumerate available prompt templates',
    method: 'prompts/list',
    category: 'prompts',
    paramsTemplate: {},
    exampleResponse: {
      prompts: [
        { name: 'cluster_report', description: 'Generate cluster health report' },
      ],
    },
  },
  {
    id: 'prompts-get',
    name: 'Get Prompt',
    description: 'Get a specific prompt with arguments applied',
    method: 'prompts/get',
    category: 'prompts',
    paramsTemplate: {
      name: 'cluster_report',
      arguments: { timeframe: '24h', format: 'markdown' },
    },
    exampleResponse: {
      description: 'Cluster health report for last 24 hours',
      messages: [
        { role: 'user', content: { type: 'text', text: 'Generate a cluster health report...' } },
      ],
    },
  },
  // Utilities
  {
    id: 'logging',
    name: 'Set Log Level',
    description: 'Configure server-side logging level',
    method: 'logging/setLevel',
    category: 'utilities',
    paramsTemplate: {
      level: 'info',
    },
    exampleResponse: {},
  },
  {
    id: 'completion',
    name: 'Completion',
    description: 'Request argument auto-completion from the server',
    method: 'completion/complete',
    category: 'utilities',
    paramsTemplate: {
      ref: { type: 'ref/resource', uri: 'yyc3://metrics/' },
      argument: { name: 'node_id', value: 'm' },
    },
    exampleResponse: {
      completion: { values: ['m4-max', 'matebook'], total: 2, hasMore: false },
    },
  },
];

// ============================================================
// 8. MCP Service Registry (localStorage)
// ============================================================

const MCP_REGISTRY_KEY = 'yyc3-mcp-registry';

export function loadMCPRegistry(): MCPServerDefinition[] {
  try {
    const raw = localStorage.getItem(MCP_REGISTRY_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return [];
}

/**
 * Phase 35: Decrypt MCP credentials (tokens in env)
 */
export async function initMCPRegistry(): Promise<MCPServerDefinition[]> {
  try {
    const raw = localStorage.getItem(MCP_REGISTRY_KEY);
    if (!raw) return [];
    const servers = JSON.parse(raw) as MCPServerDefinition[];
    
    return await Promise.all(servers.map(async s => {
      if (s.env && s.encrypted) {
        const decryptedEnv: Record<string, string> = {};
        for (const [key, value] of Object.entries(s.env)) {
          decryptedEnv[key] = await decryptValue(value);
        }
        return { ...s, env: decryptedEnv, encrypted: false };
      }
      return s;
    }));
  } catch { return []; }
}

export async function saveMCPRegistry(servers: MCPServerDefinition[]): Promise<void> {
  try {
    const encryptEnabled = isCryptoAvailable();
    const processedServers = await Promise.all(servers.map(async s => {
      // Check if any env value might be a token (heuristic: ALL_CAPS or contains 'TOKEN', 'KEY', 'SECRET')
      const envKeys = s.env ? Object.keys(s.env) : [];
      const hasSensitiveKeys = envKeys.some(k => 
        k.toUpperCase().includes('TOKEN') || 
        k.toUpperCase().includes('KEY') || 
        k.toUpperCase().includes('SECRET') ||
        (k === k.toUpperCase() && k.length > 2)
      );

      if (s.env && hasSensitiveKeys && !s.encrypted && encryptEnabled) {
        const encryptedEnv: Record<string, string> = {};
        for (const [key, value] of Object.entries(s.env)) {
          encryptedEnv[key] = await encryptValue(value);
        }
        return { ...s, env: encryptedEnv, encrypted: true };
      }
      return s;
    }));
    localStorage.setItem(MCP_REGISTRY_KEY, JSON.stringify(processedServers));
  } catch { /* ignore */ }
}

export function getAllMCPServers(): MCPServerDefinition[] {
  const custom = loadMCPRegistry();
  const presetIds = new Set(custom.map(s => s.id));
  const presets = MCP_SERVER_PRESETS.filter(p => !presetIds.has(p.id));
  return [...presets, ...custom];
}

export async function registerMCPServer(server: MCPServerDefinition): Promise<void> {
  const existing = await initMCPRegistry(); // use decrypted versions for manipulation
  const idx = existing.findIndex(s => s.id === server.id);
  if (idx >= 0) {
    existing[idx] = server;
  } else {
    existing.push(server);
  }
  await saveMCPRegistry(existing);
}

export async function removeMCPServer(serverId: string): Promise<void> {
  const existing = (await initMCPRegistry()).filter(s => s.id !== serverId);
  await saveMCPRegistry(existing);
}

// ============================================================
// 9. MCP Call Execution (Real→Mock Runtime, Phase 47)
// ============================================================

export interface MCPCallResult {
  success: boolean;
  method: string;
  serverId: string;
  latencyMs: number;
  response: MCPJsonRpcResponse;
  timestamp: number;
}

const MCP_CALL_LOG_KEY = 'yyc3-mcp-call-log';

export function logMCPCall(result: MCPCallResult): void {
  try {
    const log: MCPCallResult[] = JSON.parse(localStorage.getItem(MCP_CALL_LOG_KEY) || '[]');
    log.unshift(result);
    localStorage.setItem(MCP_CALL_LOG_KEY, JSON.stringify(log.slice(0, 200)));
  } catch { /* ignore */ }
}

export function getMCPCallLog(): MCPCallResult[] {
  try {
    return JSON.parse(localStorage.getItem(MCP_CALL_LOG_KEY) || '[]');
  } catch { return []; }
}

/**
 * Execute an MCP call with real infrastructure fallback to rich mock data.
 * Phase 47: Real execution → Rich mock (no more generic [Mock] responses).
 */
export async function executeMCPCall(
  serverId: string,
  method: string,
  params: Record<string, unknown> = {}
): Promise<MCPCallResult> {
  const start = performance.now();
  const id = Date.now();

  // Small latency simulation for UX
  await new Promise(r => setTimeout(r, 80 + Math.random() * 200));

  const server = getAllMCPServers().find(s => s.id === serverId);
  if (!server) {
    const result: MCPCallResult = {
      success: false,
      method,
      serverId,
      latencyMs: Math.round(performance.now() - start),
      response: {
        jsonrpc: '2.0',
        id,
        error: { code: -32601, message: `Server "${serverId}" not found` },
      },
      timestamp: Date.now(),
    };
    logMCPCall(result);
    return result;
  }

  let responseResult: unknown;

  switch (method) {
    case 'initialize':
      responseResult = {
        protocolVersion: '2025-03-26',
        capabilities: server.capabilities,
        serverInfo: { name: server.name, version: server.version },
      };
      break;
    case 'ping':
      responseResult = {};
      break;
    case 'tools/list':
      responseResult = { tools: server.tools };
      break;
    case 'tools/call': {
      const toolName = params.name as string;
      const toolArgs = (params.arguments || {}) as Record<string, unknown>;
      const tool = server.tools.find(t => t.name === toolName);
      if (!tool) {
        const errResult: MCPCallResult = {
          success: false,
          method,
          serverId,
          latencyMs: Math.round(performance.now() - start),
          response: {
            jsonrpc: '2.0',
            id,
            error: { code: -32602, message: `Tool "${toolName}" not found on server "${server.name}"` },
          },
          timestamp: Date.now(),
        };
        logMCPCall(errResult);
        return errResult;
      }

      // Phase 47: Try real infrastructure execution first
      let toolResult: MCPToolCallResult | null = null;
      try {
        toolResult = await executeToolViaInfra(serverId, toolName, toolArgs);
      } catch { /* fall through to mock */ }

      // Fallback to rich mock data
      if (!toolResult) {
        toolResult = _toolMock(serverId, toolName, toolArgs);
      }

      responseResult = toolResult;
      break;
    }
    case 'resources/list':
      responseResult = { resources: server.resources };
      break;
    case 'resources/read': {
      const uri = params.uri as string;
      const res = server.resources.find(r => r.uri === uri);
      // Phase 47: Use rich resource mock data instead of generic placeholder
      responseResult = {
        contents: [{
          uri,
          mimeType: res?.mimeType || 'application/json',
          text: _resourceMock(uri),
        }],
      };
      break;
    }
    case 'resources/templates/list':
      responseResult = { resourceTemplates: server.resourceTemplates };
      break;
    case 'prompts/list':
      responseResult = { prompts: server.prompts };
      break;
    case 'prompts/get': {
      const promptName = params.name as string;
      const promptArgs = (params.arguments || {}) as Record<string, string>;
      const prompt = server.prompts.find(p => p.name === promptName);
      // Phase 47: Generate meaningful prompt messages
      if (promptName === 'cluster_report') {
        const timeframe = promptArgs.timeframe || '24h';
        const format = promptArgs.format || 'markdown';
        responseResult = {
          description: prompt?.description || 'Cluster health report',
          messages: [
            { role: 'user', content: { type: 'text', text: `Generate a comprehensive cluster health report for the last ${timeframe} in ${format} format.\n\nInclude:\n- Node status for all 4 devices (M4 Max, iMac M4, MateBook, NAS)\n- Resource utilization (CPU, memory, storage)\n- Docker container status\n- Network latency between nodes\n- Any alerts or anomalies detected\n- Recommendations for optimization` } },
          ],
        };
      } else if (promptName === 'incident_response') {
        const severity = promptArgs.severity || 'medium';
        const node = promptArgs.affected_node || 'unknown';
        responseResult = {
          description: prompt?.description || 'Incident response guide',
          messages: [
            { role: 'user', content: { type: 'text', text: `Incident Response Protocol — Severity: ${severity.toUpperCase()}\nAffected Node: ${node}\n\nPlease guide through:\n1. Initial assessment and impact analysis\n2. Containment steps specific to ${node}\n3. Root cause investigation checklist\n4. Recovery procedure\n5. Post-incident review template\n\nContext: YYC3 cluster with 4 nodes (M4 Max orchestrator, iMac auxiliary, MateBook edge, NAS data center)` } },
          ],
        };
      } else {
        responseResult = {
          description: prompt?.description || 'Unknown prompt',
          messages: [
            { role: 'user', content: { type: 'text', text: `Execute prompt "${promptName}" with parameters: ${JSON.stringify(promptArgs)}` } },
          ],
        };
      }
      break;
    }
    default:
      responseResult = { message: `Method "${method}" not recognized`, supportedMethods: ['initialize', 'ping', 'tools/list', 'tools/call', 'resources/list', 'resources/read', 'resources/templates/list', 'prompts/list', 'prompts/get'] };
  }

  const result: MCPCallResult = {
    success: true,
    method,
    serverId,
    latencyMs: Math.round(performance.now() - start),
    response: {
      jsonrpc: '2.0',
      id,
      result: responseResult,
    },
    timestamp: Date.now(),
  };

  logMCPCall(result);
  return result;
}

// ============================================================
// 10. MCP Code Generator
// ============================================================

/**
 * Phase 47: Generate MCP server code with REAL implementations
 * instead of TODO stubs. Each tool gets a working handler based on its type.
 */
export function generateMCPServerCode(server: MCPServerDefinition): string {
  // Generate real tool handler code based on tool name patterns
  function _genToolHandler(tool: MCPTool): string {
    const name = tool.name;
    const props = Object.keys(tool.inputSchema.properties);
    const argsDestructure = props.length > 0
      ? `const { ${props.join(', ')} } = args;`
      : '// No arguments';

    // Filesystem tools
    if (name === 'read_file') return `    case "${name}": {\n      ${argsDestructure}\n      const fs = await import("node:fs/promises");\n      const content = await fs.readFile(path, "utf-8");\n      return { content: [{ type: "text", text: content }] };\n    }`;
    if (name === 'write_file') return `    case "${name}": {\n      ${argsDestructure}\n      const fs = await import("node:fs/promises");\n      await fs.writeFile(path, content, "utf-8");\n      return { content: [{ type: "text", text: JSON.stringify({ success: true, path, bytesWritten: content.length }) }] };\n    }`;
    if (name === 'list_directory') return `    case "${name}": {\n      ${argsDestructure}\n      const fs = await import("node:fs/promises");\n      const entries = await fs.readdir(path, { withFileTypes: true });\n      const result = entries.map(e => ({ name: e.name, type: e.isDirectory() ? "directory" : "file" }));\n      return { content: [{ type: "text", text: JSON.stringify({ path, entries: result }) }] };\n    }`;
    if (name === 'search_files') return `    case "${name}": {\n      ${argsDestructure}\n      const { execSync } = await import("node:child_process");\n      const output = execSync(\`grep -rn "\${pattern}" "\${path}" --include="*" -l 2>/dev/null || true\`, { encoding: "utf-8", timeout: 10000 });\n      const matches = output.trim().split("\\n").filter(Boolean).map(f => ({ path: f }));\n      return { content: [{ type: "text", text: JSON.stringify({ pattern, matches, totalMatches: matches.length }) }] };\n    }`;

    // Database tools
    if (name === 'query') return `    case "${name}": {\n      ${argsDestructure}\n      // Read-only query enforcement\n      const trimmed = sql.trim().toUpperCase();\n      if (!trimmed.startsWith("SELECT") && !trimmed.startsWith("WITH") && !trimmed.startsWith("EXPLAIN")) {\n        return { content: [{ type: "text", text: JSON.stringify({ error: "Only SELECT/WITH/EXPLAIN allowed" }) }], isError: true };\n      }\n      const pg = await import("pg");\n      const client = new pg.Client({ connectionString: process.env.DATABASE_URL || "${server.args?.[server.args.length - 1] || 'postgresql://localhost/mydb'}" });\n      await client.connect();\n      try {\n        const result = await client.query(sql);\n        return { content: [{ type: "text", text: JSON.stringify({ columns: result.fields.map(f => f.name), rows: result.rows, rowCount: result.rowCount }) }] };\n      } finally {\n        await client.end();\n      }\n    }`;
    if (name === 'sqlite_query') return `    case "${name}": {\n      ${argsDestructure}\n      const Database = (await import("better-sqlite3")).default;\n      const dbFile = db_path || process.env.SQLITE_DB || "./data.db";\n      const db = new Database(dbFile, { readonly: !sql.trim().toUpperCase().startsWith("SELECT") ? false : true });\n      try {\n        const stmt = db.prepare(sql);\n        if (sql.trim().toUpperCase().startsWith("SELECT")) {\n          const rows = stmt.all();\n          return { content: [{ type: "text", text: JSON.stringify({ rows, rowCount: rows.length }) }] };\n        } else {\n          const info = stmt.run();\n          return { content: [{ type: "text", text: JSON.stringify({ changes: info.changes }) }] };\n        }\n      } finally {\n        db.close();\n      }\n    }`;

    // Cluster / Docker tools
    if (name === 'cluster_status') return `    case "${name}": {\n      ${argsDestructure}\n      const os = await import("node:os");\n      const nodeId = node || "all";\n      const localNode = {\n        id: os.hostname(),\n        platform: os.platform(),\n        arch: os.arch(),\n        cpus: os.cpus().length,\n        totalMemory: (os.totalmem() / 1e9).toFixed(1) + "GB",\n        freeMemory: (os.freemem() / 1e9).toFixed(1) + "GB",\n        uptime: Math.round(os.uptime()) + "s",\n        loadAvg: os.loadavg(),\n      };\n      return { content: [{ type: "text", text: JSON.stringify({ node: nodeId, timestamp: new Date().toISOString(), status: localNode }) }] };\n    }`;
    if (name === 'docker_containers') return `    case "${name}": {\n      ${argsDestructure}\n      const dockerHost = process.env.DOCKER_HOST || "http://localhost:2375";\n      if (action === "list") {\n        const res = await fetch(\`\${dockerHost}/v1.41/containers/json?all=true\`);\n        const containers = await res.json();\n        return { content: [{ type: "text", text: JSON.stringify(containers.map(c => ({ id: c.Id?.substring(0,12), name: c.Names?.[0], image: c.Image, state: c.State, status: c.Status }))) }] };\n      }\n      if (["start","stop","restart"].includes(action) && container_id) {\n        await fetch(\`\${dockerHost}/v1.41/containers/\${container_id}/\${action}\`, { method: "POST" });\n        return { content: [{ type: "text", text: JSON.stringify({ action, container_id, success: true }) }] };\n      }\n      if (action === "logs" && container_id) {\n        const res = await fetch(\`\${dockerHost}/v1.41/containers/\${container_id}/logs?stdout=true&stderr=true&tail=100\`);\n        return { content: [{ type: "text", text: await res.text() }] };\n      }\n      return { content: [{ type: "text", text: JSON.stringify({ error: "Invalid action or missing container_id" }) }], isError: true };\n    }`;
    if (name === 'system_diagnostics') return `    case "${name}": {\n      ${argsDestructure}\n      const os = await import("node:os");\n      const { execSync } = await import("node:child_process");\n      const diagnosticScope = scope || "full";\n      const result = {\n        scope: diagnosticScope,\n        timestamp: new Date().toISOString(),\n        system: { platform: os.platform(), arch: os.arch(), cpus: os.cpus().length, totalMem: os.totalmem(), freeMem: os.freemem(), uptime: os.uptime(), loadAvg: os.loadavg() },\n      };\n      if (["full","storage"].includes(diagnosticScope)) {\n        try { result.disk = execSync("df -h", { encoding: "utf-8", timeout: 5000 }); } catch { result.disk = "unavailable"; }\n      }\n      if (["full","network"].includes(diagnosticScope)) {\n        result.network = os.networkInterfaces();\n      }\n      return { content: [{ type: "text", text: JSON.stringify(result, null, 2) }] };\n    }`;
    if (name === 'deploy_service') return `    case "${name}": {\n      ${argsDestructure}\n      const dockerHost = process.env.DOCKER_HOST || "http://localhost:2375";\n      // Pull image\n      await fetch(\`\${dockerHost}/v1.41/images/create?fromImage=\${encodeURIComponent(image)}\`, { method: "POST" });\n      // Create container\n      const portBindings = {};\n      if (ports) {\n        const [host, container] = ports.split(":");\n        portBindings[\`\${container}/tcp\`] = [{ HostPort: host }];\n      }\n      const createRes = await fetch(\`\${dockerHost}/v1.41/containers/create?name=\${service_name}\`, {\n        method: "POST",\n        headers: { "Content-Type": "application/json" },\n        body: JSON.stringify({ Image: image, HostConfig: { PortBindings: portBindings } }),\n      });\n      const { Id } = await createRes.json();\n      // Start container\n      await fetch(\`\${dockerHost}/v1.41/containers/\${Id}/start\`, { method: "POST" });\n      return { content: [{ type: "text", text: JSON.stringify({ success: true, containerId: Id, service: service_name, image }) }] };\n    }`;

    // GitHub tools
    if (name === 'search_repositories') return `    case "${name}": {\n      ${argsDestructure}\n      const token = process.env.GITHUB_PERSONAL_ACCESS_TOKEN;\n      const res = await fetch(\`https://api.github.com/search/repositories?q=\${encodeURIComponent(query)}&page=\${page||1}\`, {\n        headers: { Authorization: token ? \`Bearer \${token}\` : "", "User-Agent": "yyc3-mcp" },\n      });\n      return { content: [{ type: "text", text: JSON.stringify(await res.json()) }] };\n    }`;
    if (name === 'create_issue') return `    case "${name}": {\n      ${argsDestructure}\n      const token = process.env.GITHUB_PERSONAL_ACCESS_TOKEN;\n      const res = await fetch(\`https://api.github.com/repos/\${owner}/\${repo}/issues\`, {\n        method: "POST",\n        headers: { Authorization: \`Bearer \${token}\`, "Content-Type": "application/json", "User-Agent": "yyc3-mcp" },\n        body: JSON.stringify({ title, body: body || "" }),\n      });\n      return { content: [{ type: "text", text: JSON.stringify(await res.json()) }] };\n    }`;
    if (name === 'get_file_contents') return `    case "${name}": {\n      ${argsDestructure}\n      const token = process.env.GITHUB_PERSONAL_ACCESS_TOKEN;\n      const branchParam = branch ? \`?ref=\${branch}\` : "";\n      const res = await fetch(\`https://api.github.com/repos/\${owner}/\${repo}/contents/\${path}\${branchParam}\`, {\n        headers: { Authorization: token ? \`Bearer \${token}\` : "", "User-Agent": "yyc3-mcp" },\n      });\n      return { content: [{ type: "text", text: JSON.stringify(await res.json()) }] };\n    }`;

    // Search tools
    if (name === 'brave_web_search') return `    case "${name}": {\n      ${argsDestructure}\n      const apiKey = process.env.BRAVE_API_KEY;\n      const res = await fetch(\`https://api.search.brave.com/res/v1/web/search?q=\${encodeURIComponent(query)}&count=\${count||10}\`, {\n        headers: { "X-Subscription-Token": apiKey, Accept: "application/json" },\n      });\n      return { content: [{ type: "text", text: JSON.stringify(await res.json()) }] };\n    }`;
    if (name === 'brave_local_search') return `    case "${name}": {\n      ${argsDestructure}\n      const apiKey = process.env.BRAVE_API_KEY;\n      const res = await fetch(\`https://api.search.brave.com/res/v1/local/search?q=\${encodeURIComponent(query)}&count=\${count||5}\`, {\n        headers: { "X-Subscription-Token": apiKey, Accept: "application/json" },\n      });\n      return { content: [{ type: "text", text: JSON.stringify(await res.json()) }] };\n    }`;

    // Fallback for unknown tools
    return `    case "${name}": {\n      ${argsDestructure}\n      // Implement ${name}: ${tool.description}\n      return { content: [{ type: "text", text: JSON.stringify({ tool: "${name}", args, timestamp: new Date().toISOString(), note: "Implementation needed" }) }] };\n    }`;
  }

  const toolCases = server.tools.map(t => _genToolHandler(t)).join('\n\n');

  // Resource read handler with real implementations
  const resourceReadHandler = server.resources.length > 0
    ? `  const resourceHandlers = {\n${server.resources.map(r => {
        if (r.uri.includes('schema')) return `    "${r.uri}": async () => {\n      // Return database schema\n      const pg = await import("pg");\n      const client = new pg.Client({ connectionString: process.env.DATABASE_URL });\n      await client.connect();\n      try {\n        const result = await client.query("SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')");\n        return JSON.stringify(result.rows);\n      } finally { await client.end(); }\n    }`;
        if (r.uri.includes('metrics')) return `    "${r.uri}": async () => {\n      const os = await import("node:os");\n      return JSON.stringify({ cpus: os.cpus().length, loadAvg: os.loadavg(), totalMem: os.totalmem(), freeMem: os.freemem(), uptime: os.uptime() });\n    }`;
        if (r.uri.includes('docker')) return `    "${r.uri}": async () => {\n      const res = await fetch((process.env.DOCKER_HOST || "http://localhost:2375") + "/v1.41/containers/json?all=true");\n      return JSON.stringify(await res.json());\n    }`;
        return `    "${r.uri}": async () => JSON.stringify({ uri: "${r.uri}", status: "ok", timestamp: new Date().toISOString() })`;
      }).join(',\n')}\n  };\n  const handler = resourceHandlers[uri];\n  const text = handler ? await handler() : JSON.stringify({ uri, error: "Resource not found" });\n  return { contents: [{ uri, mimeType: "application/json", text }] };`
    : `  return { contents: [{ uri, mimeType: "application/json", text: JSON.stringify({ uri, status: "ok" }) }] };`;

  // Prompt handler with real implementations
  const promptGetHandler = server.prompts.length > 0
    ? server.prompts.map(p => {
        const pArgs = (p.arguments || []).map(a => a.name);
        return `    if (name === "${p.name}") {\n      ${pArgs.map(a => `const ${a} = args?.${a} || "";`).join('\n      ')}\n      return {\n        description: "${p.description || p.name}",\n        messages: [{ role: "user", content: { type: "text", text: \`${p.description || p.name}: ${pArgs.map(a => `\${${a}}`).join(', ')}\` } }],\n      };\n    }`;
      }).join('\n')
    : '';

  return `import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

const server = new Server({
  name: "${server.name.toLowerCase().replace(/\s+/g, '-')}",
  version: "${server.version}",
}, {
  capabilities: {
    ${server.capabilities.tools ? 'tools: {},' : ''}
    ${server.capabilities.resources ? 'resources: {},' : ''}
    ${server.capabilities.prompts ? 'prompts: {},' : ''}
    ${server.capabilities.logging ? 'logging: {},' : ''}
  },
});

// ============================
// Tools Registration
// ============================
server.setRequestHandler("tools/list", async () => ({
  tools: ${JSON.stringify(server.tools, null, 4).replace(/\n/g, '\n  ')}
}));

server.setRequestHandler("tools/call", async (request) => {
  const { name, arguments: args } = request.params;
  
  switch (name) {
${toolCases}
    default:
      throw new Error(\`Unknown tool: \${name}\`);
  }
});

${server.capabilities.resources ? `// ============================
// Resources Registration
// ============================
server.setRequestHandler("resources/list", async () => ({
  resources: ${JSON.stringify(server.resources, null, 4).replace(/\n/g, '\n  ')}
}));

server.setRequestHandler("resources/read", async (request) => {
  const { uri } = request.params;
${resourceReadHandler}
});` : ''}

${server.capabilities.prompts ? `// ============================
// Prompts Registration
// ============================
server.setRequestHandler("prompts/list", async () => ({
  prompts: ${JSON.stringify(server.prompts, null, 4).replace(/\n/g, '\n  ')}
}));

server.setRequestHandler("prompts/get", async (request) => {
  const { name, arguments: args } = request.params;
${promptGetHandler}
  return {
    messages: [{ role: "user", content: { type: "text", text: \`Prompt \${name} with args: \${JSON.stringify(args)}\` } }],
  };
});` : ''}

// ============================
// Start Server
// ============================
const transport = new StdioServerTransport();
await server.connect(transport);
console.error("${server.name} MCP server running on stdio");
`;
}

export function generateMCPClientConfig(servers: MCPServerDefinition[]): string {
  const config: Record<string, unknown> = {
    mcpServers: {} as Record<string, unknown>,
  };

  for (const server of servers) {
    const entry: Record<string, unknown> = {};
    if (server.transport === 'stdio') {
      entry.command = server.command;
      entry.args = server.args;
      if (server.env && Object.keys(server.env).length > 0) {
        entry.env = server.env;
      }
    } else {
      entry.url = server.url;
    }
    (config.mcpServers as Record<string, unknown>)[server.name.toLowerCase().replace(/\s+/g, '-')] = entry;
  }

  return JSON.stringify(config, null, 2);
}

// ============================================================
// 11. Real MCP Transport Layer (Phase 18.3)
// ============================================================

/**
 * Transport connection state for HTTP-based MCP servers.
 * stdio transport cannot be used from a browser — those are for
 * CLI/desktop clients (Claude Desktop, Cursor, etc.)
 */

export interface MCPTransportConnection {
  serverId: string;
  transport: MCPTransport;
  status: 'connecting' | 'connected' | 'disconnected' | 'error';
  url?: string;
  sessionId?: string;
  lastPing?: number;
  latencyMs?: number;
  error?: string;
}

const _connections = new Map<string, MCPTransportConnection>();

/**
 * Get active connection for a server
 */
export function getMCPConnection(serverId: string): MCPTransportConnection | undefined {
  return _connections.get(serverId);
}

/**
 * Get all active connections
 */
export function getAllMCPConnections(): MCPTransportConnection[] {
  return Array.from(_connections.values());
}

/**
 * Test connectivity to an HTTP-based MCP server
 */
export async function testMCPConnection(
  server: MCPServerDefinition
): Promise<{ success: boolean; latencyMs: number; error?: string; serverInfo?: unknown }> {
  if (server.transport === 'stdio') {
    return {
      success: false,
      latencyMs: 0,
      error: 'stdio transport cannot be directly connected from the browser. Use Claude Desktop or Cursor config instead.',
    };
  }

  if (!server.url) {
    return { success: false, latencyMs: 0, error: 'No URL configured for this server' };
  }

  const startTime = performance.now();

  try {
    // Send JSON-RPC 2.0 initialize request
    const initRequest: MCPJsonRpcRequest = {
      jsonrpc: '2.0',
      id: Date.now(),
      method: 'initialize',
      params: {
        protocolVersion: '2025-03-26',
        capabilities: {
          roots: { listChanged: true },
        },
        clientInfo: {
          name: 'yyc3-hacker-chatbot',
          version: '1.0.0',
        },
      },
    };

    const response = await fetch(server.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(server.env?.['AUTH_TOKEN'] ? { 'Authorization': `Bearer ${server.env['AUTH_TOKEN']}` } : {}),
      },
      body: JSON.stringify(initRequest),
      signal: AbortSignal.timeout(10000),
    });

    const latencyMs = Math.round(performance.now() - startTime);

    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      return {
        success: false,
        latencyMs,
        error: `HTTP ${response.status}: ${errText.slice(0, 200)}`,
      };
    }

    const data = await response.json() as MCPJsonRpcResponse;

    if (data.error) {
      return {
        success: false,
        latencyMs,
        error: `MCP Error ${data.error.code}: ${data.error.message}`,
      };
    }

    return {
      success: true,
      latencyMs,
      serverInfo: data.result,
    };
  } catch (error) {
    const latencyMs = Math.round(performance.now() - startTime);
    const err = error as Error;

    if (err.name === 'TimeoutError' || err.name === 'AbortError') {
      return { success: false, latencyMs, error: 'Connection timeout (10s)' };
    }

    if (err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError')) {
      return { success: false, latencyMs, error: 'Network error — server unreachable or CORS blocked' };
    }

    return { success: false, latencyMs, error: err.message || 'Unknown error' };
  }
}

/**
 * Connect to an HTTP-based MCP server
 * Establishes session and discovers capabilities
 */
export async function connectMCPServer(
  server: MCPServerDefinition
): Promise<MCPTransportConnection> {
  const conn: MCPTransportConnection = {
    serverId: server.id,
    transport: server.transport,
    status: 'connecting',
  };
  _connections.set(server.id, conn);

  if (server.transport === 'stdio') {
    conn.status = 'error';
    conn.error = 'stdio transport not available in browser';
    return conn;
  }

  const testResult = await testMCPConnection(server);

  if (testResult.success) {
    conn.status = 'connected';
    conn.url = server.url;
    conn.latencyMs = testResult.latencyMs;
    conn.lastPing = Date.now();

    // Send initialized notification (per MCP spec)
    if (server.url) {
      try {
        await fetch(server.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }),
        });
      } catch { /* notification failures are non-critical */ }
    }
  } else {
    conn.status = 'error';
    conn.error = testResult.error;
    conn.latencyMs = testResult.latencyMs;
  }

  return conn;
}

/**
 * Disconnect from an MCP server
 */
export function disconnectMCPServer(serverId: string): void {
  _connections.delete(serverId);
}

/**
 * Execute a real JSON-RPC 2.0 call to a connected HTTP MCP server.
 * Falls back to mock execution if not connected.
 */
export async function executeRealMCPCall(
  serverId: string,
  method: string,
  params: Record<string, unknown> = {}
): Promise<MCPCallResult> {
  const start = performance.now();
  const id = Date.now();

  const conn = _connections.get(serverId);
  const server = getAllMCPServers().find(s => s.id === serverId);

  // If not connected or no URL, fall back to mock
  if (!conn || conn.status !== 'connected' || !conn.url) {
    return executeMCPCall(serverId, method, params);
  }

  try {
    const request: MCPJsonRpcRequest = {
      jsonrpc: '2.0',
      id,
      method,
      params: Object.keys(params).length > 0 ? params : undefined,
    };

    const response = await fetch(conn.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(server?.env?.['AUTH_TOKEN'] ? { 'Authorization': `Bearer ${server.env['AUTH_TOKEN']}` } : {}),
      },
      body: JSON.stringify(request),
      signal: AbortSignal.timeout(30000),
    });

    const latencyMs = Math.round(performance.now() - start);

    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      const result: MCPCallResult = {
        success: false,
        method,
        serverId,
        latencyMs,
        response: {
          jsonrpc: '2.0',
          id,
          error: { code: -32000, message: `HTTP ${response.status}: ${errText.slice(0, 200)}` },
        },
        timestamp: Date.now(),
      };
      logMCPCall(result);
      return result;
    }

    const data = await response.json() as MCPJsonRpcResponse;

    const result: MCPCallResult = {
      success: !data.error,
      method,
      serverId,
      latencyMs,
      response: data,
      timestamp: Date.now(),
    };

    logMCPCall(result);
    conn.lastPing = Date.now();
    conn.latencyMs = latencyMs;
    return result;

  } catch (error) {
    const latencyMs = Math.round(performance.now() - start);
    const err = error as Error;

    const result: MCPCallResult = {
      success: false,
      method,
      serverId,
      latencyMs,
      response: {
        jsonrpc: '2.0',
        id,
        error: { code: -32603, message: err.message || 'Transport error' },
      },
      timestamp: Date.now(),
    };

    logMCPCall(result);

    // Mark connection as errored
    conn.status = 'error';
    conn.error = err.message;

    return result;
  }
}

/**
 * Smart MCP call executor — uses real transport if connected, mock otherwise
 */
export async function smartMCPCall(
  serverId: string,
  method: string,
  params: Record<string, unknown> = {}
): Promise<MCPCallResult> {
  const conn = _connections.get(serverId);

  // Emit to event bus
  try {
    const { eventBus } = await import('./event-bus');
    const mode = conn?.status === 'connected' ? 'REAL' : 'MOCK';
    eventBus.mcp('call', `[${mode}] ${method} → ${serverId}`, 'info', { serverId, method, mode });
  } catch { /* bus not available */ }

  if (conn?.status === 'connected') {
    return executeRealMCPCall(serverId, method, params);
  }

  return executeMCPCall(serverId, method, params);
}