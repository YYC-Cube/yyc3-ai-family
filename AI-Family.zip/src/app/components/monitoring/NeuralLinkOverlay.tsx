import * as React from "react";
import { cn } from "@/lib/utils";
import { useSystemStore } from "@/lib/store";
import { useTranslation } from "@/lib/i18n";
import { eventBus } from "@/lib/event-bus";
import type { EventCategory } from "@/lib/event-bus";
import { EVENT_CATEGORY_META } from "@/lib/event-bus";
import { getLastInfraReport } from "@/lib/useInfraHealth";
import type { InfraStatus } from "@/lib/useInfraHealth";
import { loadProviderConfigs } from "@/lib/llm-bridge";
import { PROVIDERS } from "@/lib/llm-providers";
import { getRunnerHealth, onRunnerHealthChange } from "@/lib/useDAGExecutor";
import type { RunnerStatus } from "@/lib/useDAGExecutor";
import { getPgTelemetryState, onPgTelemetryChange } from "@/lib/pg-telemetry-client";
import type { PgTelemetryStatus } from "@/lib/pg-telemetry-client";
import {
  Brain, Cpu, HardDrive, Wifi, WifiOff,
  Activity, Shield, Zap, ChevronRight, X,
  TerminalSquare, Eye, EyeOff, Maximize2, Minimize2,
  Network, Sparkles, AlertTriangle, CheckCircle2,
  ArrowUpRight, Clock, Database, Radio, Server,
  Key, FileText, Layers, Settings2
} from "lucide-react";
import { AGENT_REGISTRY } from "@/lib/types";
import { loadBranding, type BrandingConfig, loadAgentCustomConfig, getMergedAgents } from "@/lib/branding-config";
import { getPersistenceEngine } from "@/lib/persistence-engine";

// ============================================================
// NeuralLinkOverlay — Real-time Collaboration HUD
//
// A floating heads-up display providing constant system awareness:
//   - System health pulse (optimal/warning/critical)
//   - Active agent indicator
//   - Streaming status
//   - Event bus live feed (last 5 events)
//   - Quick-nav breadcrumb
//   - Hardware vitals mini-bars
//   - Keyboard shortcut hints
//
// Design: "Neural Link = 人机神经链接, always-on awareness"
// ============================================================

// --- Compact Mini-Bar Component ---
function MiniBar({ value, max, color, label }: { value: number; max: number; color: string; label: string }) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));
  return (
    <div className="flex items-center gap-1.5 group" title={`${label}: ${value.toFixed(1)}%`}>
      <span className="text-[8px] font-mono text-zinc-500 w-6 text-right uppercase tracking-wider">{label}</span>
      <div className="w-12 h-1 bg-zinc-800 rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all duration-700 ease-out", color)}
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-[8px] font-mono text-zinc-500 w-7">{pct.toFixed(0)}%</span>
    </div>
  );
}

// --- Pulse Dot ---
function PulseDot({ status }: { status: 'optimal' | 'warning' | 'critical' | 'booting' }) {
  const colors = {
    optimal: "bg-emerald-500 shadow-emerald-500/50",
    warning: "bg-amber-500 shadow-amber-500/50",
    critical: "bg-red-500 shadow-red-500/50",
    booting: "bg-sky-500 shadow-sky-500/50",
  };
  return (
    <div className="relative">
      <div className={cn("w-2 h-2 rounded-full shadow-[0_0_6px]", colors[status])} />
      <div className={cn("absolute inset-0 w-2 h-2 rounded-full animate-ping opacity-40", colors[status])} />
    </div>
  );
}

// --- Event Feed Item ---
function EventItem({ event }: { event: { level: string; source: string; message: string; timestamp: string } }) {
  const levelColors: Record<string, string> = {
    info: "text-sky-400",
    success: "text-emerald-400",
    warn: "text-amber-400",
    error: "text-red-400",
    debug: "text-zinc-500",
  };
  return (
    <div className="flex items-start gap-1.5 text-[9px] font-mono leading-tight py-0.5 animate-in fade-in slide-in-from-right-2 duration-300">
      <span className={cn("shrink-0 mt-0.5", levelColors[event.level] || "text-zinc-500")}>
        {event.level === 'error' ? '!' : event.level === 'warn' ? '~' : event.level === 'success' ? '+' : '-'}
      </span>
      <span className="text-zinc-600 shrink-0">{event.source.slice(0, 8)}</span>
      <span className="text-zinc-400 truncate">{event.message.slice(0, 50)}</span>
    </div>
  );
}

// --- Main Component ---
export function NeuralLinkOverlay() {
  const { t, language } = useTranslation();
  const status = useSystemStore((s) => s.status);
  const cpuLoad = useSystemStore((s) => s.cpuLoad);
  const latency = useSystemStore((s) => s.latency);
  const isStreaming = useSystemStore((s) => s.isStreaming);
  const activeView = useSystemStore((s) => s.activeView);
  const consoleTab = useSystemStore((s) => s.consoleTab);
  const consoleAgent = useSystemStore((s) => s.consoleAgent);
  const chatMode = useSystemStore((s) => s.chatMode);
  const clusterMetrics = useSystemStore((s) => s.clusterMetrics);
  const dbConnected = useSystemStore((s) => s.dbConnected);
  const messages = useSystemStore((s) => s.messages);
  const isMobile = useSystemStore((s) => s.isMobile);
  const setActiveView = useSystemStore((s) => s.setActiveView);
  const navigateToConsoleTab = useSystemStore((s) => s.navigateToConsoleTab);
  const navigateToAgent = useSystemStore((s) => s.navigateToAgent);

  // HUD visibility state
  const [isExpanded, setIsExpanded] = React.useState(false);
  const [isVisible, setIsVisible] = React.useState(true);
  const [eventFeed, setEventFeed] = React.useState<Array<{
    id: string; level: string; source: string; message: string; timestamp: string;
  }>>([]);

  // Phase 51: Branding config (reactive)
  const [branding, setBranding] = React.useState<BrandingConfig>(() => loadBranding());
  React.useEffect(() => {
    const handler = () => setBranding(loadBranding());
    window.addEventListener('yyc3-branding-update', handler);
    return () => window.removeEventListener('yyc3-branding-update', handler);
  }, []);

  // Phase 51: NAS sync status (poll every 3s when expanded)
  const [nasSyncStatus, setNasSyncStatus] = React.useState(() => {
    try { return getPersistenceEngine().getSyncStatus(); } catch { return null; }
  });
  React.useEffect(() => {
    if (!isExpanded) return;
    const poll = () => {
      try { setNasSyncStatus(getPersistenceEngine().getSyncStatus()); } catch { /* ignore */ }
    };
    poll();
    const timer = setInterval(poll, 3000);
    return () => clearInterval(timer);
  }, [isExpanded]);

  // Phase 37: EventBus category filter state
  const [activeFilters, setActiveFilters] = React.useState<Set<EventCategory>>(
    new Set<EventCategory>(['orchestrate', 'persist', 'mcp', 'system', 'security', 'ui'])
  );
  // Track category on each event for filtering
  const [eventFeedWithCategory, setEventFeedWithCategory] = React.useState<Array<{
    id: string; level: string; source: string; message: string; timestamp: string; category: EventCategory;
  }>>([]);

  // Phase 38: Unread event counters per category
  const [unreadCounts, setUnreadCounts] = React.useState<Record<EventCategory, number>>({
    orchestrate: 0, persist: 0, mcp: 0, system: 0, security: 0, ui: 0,
  });
  const lastViewedRef = React.useRef<Record<EventCategory, number>>({
    orchestrate: Date.now(), persist: Date.now(), mcp: Date.now(),
    system: Date.now(), security: Date.now(), ui: Date.now(),
  });

  const toggleFilter = React.useCallback((cat: EventCategory) => {
    setActiveFilters(prev => {
      const next = new Set(prev);
      if (next.has(cat)) {
        // Don't allow removing all filters
        if (next.size <= 1) return prev;
        next.delete(cat);
      } else {
        next.add(cat);
      }
      return next;
    });
  }, []);

  // Subscribe to Event Bus for live feed
  React.useEffect(() => {
    const subId = eventBus.on((event) => {
      setEventFeedWithCategory(prev => [
        { id: event.id, level: event.level, source: event.source, message: event.message, timestamp: event.timestamp, category: event.category },
        ...prev.slice(0, 19), // keep 20 events in buffer for filtering
      ]);
      setEventFeed(prev => [
        { id: event.id, level: event.level, source: event.source, message: event.message, timestamp: event.timestamp },
        ...prev.slice(0, 4),
      ]);
      // Phase 38: Increment unread if category is filtered out or HUD is collapsed
      setUnreadCounts(prev => ({
        ...prev,
        [event.category]: (prev[event.category] || 0) + 1,
      }));
    });
    return () => { eventBus.off(subId); };
  }, []);

  // Phase 38: Clear unread when filter chip is clicked (category becomes active)
  const handleFilterClick = React.useCallback((cat: EventCategory) => {
    // Clear unread for this category when it's activated
    setUnreadCounts(prev => ({ ...prev, [cat]: 0 }));
    lastViewedRef.current[cat] = Date.now();
    toggleFilter(cat);
  }, [toggleFilter]);

  // Phase 38: Clear all unreads when HUD expands
  React.useEffect(() => {
    if (isExpanded) {
      // Clear unreads for all active filter categories
      setUnreadCounts(prev => {
        const next = { ...prev };
        activeFilters.forEach(cat => { next[cat] = 0; });
        return next;
      });
    }
  }, [isExpanded, activeFilters]);

  // Filtered events for display
  const filteredEventFeed = React.useMemo(() => {
    return eventFeedWithCategory
      .filter(e => activeFilters.has(e.category))
      .slice(0, 5);
  }, [eventFeedWithCategory, activeFilters]);

  // Keyboard toggle: Ctrl+H for HUD
  React.useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
        e.preventDefault();
        setIsVisible(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  // Don't render on mobile
  if (isMobile) return (
    <MobileNeuralLink
      status={status}
      chatMode={chatMode}
      cpuLoad={cpuLoad}
      latency={latency}
      isStreaming={isStreaming}
      messages={messages}
    />
  );
  if (!isVisible) {
    return (
      <button
        onClick={() => setIsVisible(true)}
        className="fixed bottom-4 right-4 z-50 w-8 h-8 rounded-full bg-black/80 border border-zinc-700/50 flex items-center justify-center text-zinc-500 hover:text-primary hover:border-primary/30 transition-all hover:scale-110 backdrop-blur-md group"
        title="Show Neural Link HUD (Ctrl+H)"
      >
        <Eye className="w-3.5 h-3.5 group-hover:animate-pulse" />
      </button>
    );
  }

  // Derive active agent info (supports custom agents via getMergedAgents)
  const activeAgent = consoleAgent
    ? getMergedAgents(loadAgentCustomConfig()).find(a => a.id === consoleAgent) ?? AGENT_REGISTRY.find(a => a.id === consoleAgent) ?? null
    : null;

  // Phase 38: Total unread count for collapsed badge
  const totalUnread = Object.values(unreadCounts).reduce((sum, c) => sum + c, 0);

  // Derive metrics
  const m4Metrics = clusterMetrics?.['m4-max'];
  const memUsage = m4Metrics?.memory ?? 42;
  const diskUsage = m4Metrics?.disk ?? 35;
  const netUsage = m4Metrics?.network ?? 15;
  const temp = m4Metrics?.temperature ?? 48;

  // View label
  const viewLabels: Record<string, string> = {
    terminal: language === 'zh' ? '终端' : 'Terminal',
    console: language === 'zh' ? '控制台' : 'Console',
    projects: language === 'zh' ? '项目' : 'Projects',
    monitor: language === 'zh' ? '监控' : 'Monitor',
    artifacts: language === 'zh' ? '产物' : 'Artifacts',
    services: language === 'zh' ? '服务' : 'Services',
    knowledge: language === 'zh' ? '知识库' : 'Knowledge',
    bookmarks: language === 'zh' ? '收藏' : 'Bookmarks',
  };

  const statusLabels: Record<string, string> = {
    optimal: 'OPTIMAL',
    warning: 'WARNING',
    critical: 'CRITICAL',
    booting: 'BOOTING',
  };

  return (
    <div className={cn(
      "fixed z-50 transition-all duration-500 ease-[cubic-bezier(0.4,0,0.2,1)]",
      isExpanded
        ? "bottom-4 right-4 w-[320px]"
        : "bottom-4 right-4 w-[200px]"
    )}>
      {/* Main HUD Panel */}
      <div className={cn(
        "bg-black/85 backdrop-blur-xl border rounded-xl overflow-hidden transition-all duration-300",
        status === 'optimal' ? "border-emerald-500/20 shadow-[0_0_20px_rgba(16,185,129,0.08)]" :
        status === 'warning' ? "border-amber-500/20 shadow-[0_0_20px_rgba(245,158,11,0.08)]" :
        status === 'critical' ? "border-red-500/30 shadow-[0_0_20px_rgba(239,68,68,0.15)]" :
        "border-sky-500/20 shadow-[0_0_20px_rgba(14,165,233,0.08)]"
      )}>
        {/* Header Bar */}
        <div className="flex items-center justify-between px-3 py-1.5 border-b border-white/5 bg-zinc-900/40">
          <div className="flex items-center gap-2">
            <PulseDot status={status} />
            {branding.logoDataUrl ? (
              <div className="w-3.5 h-3.5 rounded overflow-hidden shrink-0">
                <img src={branding.logoDataUrl} alt="" className="w-full h-full object-cover" />
              </div>
            ) : null}
            <span className="text-[9px] font-mono text-zinc-300 tracking-widest">
              {branding.appName && branding.appName !== 'YYC3_DEVOPS' ? branding.appName.slice(0, 12) : 'NEURAL_LINK'}
            </span>
            {!isExpanded && totalUnread > 0 && (
              <span className="min-w-[14px] h-[14px] flex items-center justify-center rounded-full bg-red-500/80 text-[7px] font-mono text-white px-0.5 animate-in fade-in zoom-in-50 duration-200">
                {totalUnread > 99 ? '99+' : totalUnread}
              </span>
            )}
            {isStreaming && (
              <span className="text-[8px] font-mono text-sky-400 animate-pulse flex items-center gap-0.5">
                <Radio className="w-2.5 h-2.5" />
                STREAM
              </span>
            )}
          </div>
          <div className="flex items-center gap-0.5">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 text-zinc-600 hover:text-zinc-300 transition-colors"
              title={isExpanded ? "Collapse" : "Expand"}
            >
              {isExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
            </button>
            <button
              onClick={() => setIsVisible(false)}
              className="p-1 text-zinc-600 hover:text-red-400 transition-colors"
              title="Hide HUD (Ctrl+H)"
            >
              <EyeOff className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* System Status Row */}
        <div className="px-3 py-2 flex items-center gap-3">
          <div className="flex-1">
            {/* Breadcrumb: View > Tab > Agent */}
            <div className="flex items-center gap-1 text-[9px] font-mono text-zinc-400 mb-1">
              <button
                className="text-zinc-300 hover:text-primary transition-colors cursor-pointer"
                onClick={() => {
                  setActiveView(activeView as any);
                  eventBus.emit({ category: 'ui', type: 'ui.hud_navigate', level: 'info', source: 'NeuralLink', message: `HUD nav: view=${activeView}` });
                }}
                title={`Navigate to ${activeView}`}
              >
                {viewLabels[activeView] || activeView}
              </button>
              {activeView === 'console' && (
                <>
                  <ChevronRight className="w-2.5 h-2.5 text-zinc-600" />
                  <button
                    className="text-primary hover:text-primary/80 transition-colors cursor-pointer"
                    onClick={() => {
                      navigateToConsoleTab(consoleTab);
                      eventBus.emit({ category: 'ui', type: 'ui.hud_navigate', level: 'info', source: 'NeuralLink', message: `HUD nav: console/${consoleTab}` });
                    }}
                    title={`Navigate to ${consoleTab}`}
                  >
                    {consoleTab}
                  </button>
                </>
              )}
              {activeAgent && (
                <>
                  <ChevronRight className="w-2.5 h-2.5 text-zinc-600" />
                  <button
                    className={cn(activeAgent.color, "hover:opacity-80 transition-opacity cursor-pointer")}
                    onClick={() => {
                      navigateToAgent(activeAgent.id);
                      eventBus.emit({ category: 'ui', type: 'ui.hud_navigate', level: 'info', source: 'NeuralLink', message: `HUD nav: agent=${activeAgent.id}` });
                    }}
                    title={`Navigate to ${activeAgent.nameEn}`}
                  >
                    {language === 'zh' ? activeAgent.name : activeAgent.nameEn}
                  </button>
                </>
              )}
            </div>

            {/* Status + Mode */}
            <div className="flex items-center gap-2">
              <span className={cn(
                "text-[8px] font-mono tracking-widest px-1.5 py-0.5 rounded",
                status === 'optimal' ? "text-emerald-400 bg-emerald-500/10" :
                status === 'warning' ? "text-amber-400 bg-amber-500/10" :
                status === 'critical' ? "text-red-400 bg-red-500/10" :
                "text-sky-400 bg-sky-500/10"
              )}>
                {statusLabels[status]}
              </span>
              <span className={cn(
                "text-[8px] font-mono tracking-wider px-1.5 py-0.5 rounded",
                chatMode === 'ai'
                  ? "text-emerald-400 bg-emerald-500/10"
                  : "text-amber-400 bg-amber-500/10"
              )}>
                {chatMode === 'ai' ? 'AI_MODE' : 'NAV_MODE'}
              </span>
              {dbConnected && (
                <Database className="w-3 h-3 text-emerald-500" title="PG15 Connected" />
              )}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="text-right">
            <div className="text-[9px] font-mono text-zinc-400">
              <span className="text-primary">{latency}</span>ms
            </div>
            <div className="text-[8px] font-mono text-zinc-600">
              {messages.length} msgs
            </div>
          </div>
        </div>

        {/* Hardware Vitals Mini-Bars */}
        <div className="px-3 pb-2 space-y-0.5">
          <MiniBar value={cpuLoad} max={100} color={cpuLoad > 80 ? "bg-red-500" : cpuLoad > 60 ? "bg-amber-500" : "bg-emerald-500"} label="CPU" />
          <MiniBar value={memUsage} max={100} color={memUsage > 85 ? "bg-red-500" : memUsage > 70 ? "bg-amber-500" : "bg-sky-500"} label="MEM" />
          {isExpanded && (
            <>
              <MiniBar value={diskUsage} max={100} color="bg-violet-500" label="DSK" />
              <MiniBar value={netUsage} max={100} color="bg-cyan-500" label="NET" />
              <div className="flex items-center gap-1.5">
                <span className="text-[8px] font-mono text-zinc-500 w-6 text-right uppercase tracking-wider">TMP</span>
                <span className={cn(
                  "text-[9px] font-mono",
                  temp > 85 ? "text-red-400" : temp > 70 ? "text-amber-400" : "text-zinc-400"
                )}>
                  {temp}C
                </span>
              </div>
            </>
          )}
        </div>

        {/* Expanded: Live Event Feed */}
        {isExpanded && (
          <div className="border-t border-white/5 px-3 py-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
                EVENT_STREAM
              </span>
              <span className="text-[8px] font-mono text-zinc-700">{eventFeed.length}/5</span>
            </div>
            {/* Phase 37: Category filter chips */}
            <div className="flex items-center gap-0.5 mb-1.5 flex-wrap">
              {(Object.entries(EVENT_CATEGORY_META) as [EventCategory, typeof EVENT_CATEGORY_META[EventCategory]][]).map(([cat, meta]) => {
                const isActive = activeFilters.has(cat);
                return (
                  <button
                    key={cat}
                    onClick={() => handleFilterClick(cat)}
                    className={cn(
                      "px-1 py-0.5 rounded text-[7px] font-mono transition-all border",
                      isActive
                        ? cn(meta.color, meta.bgColor, "border-current/20")
                        : "text-zinc-700 bg-transparent border-zinc-800/50 hover:text-zinc-500"
                    )}
                    title={`${isActive ? 'Hide' : 'Show'} ${language === 'zh' ? meta.labelZh : meta.label} events`}
                  >
                    {meta.dimension}
                    {unreadCounts[cat] > 0 && (
                      <span className="ml-1 text-[6px] font-mono text-red-400">
                        {unreadCounts[cat]}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
            <div className="space-y-0 min-h-[50px]">
              {filteredEventFeed.length === 0 ? (
                <div className="text-[9px] font-mono text-zinc-700 py-2 text-center">
                  {language === 'zh' ? '等待事件...' : 'Awaiting events...'}
                </div>
              ) : (
                filteredEventFeed.map(e => <EventItem key={e.id} event={e} />)
              )}
            </div>
          </div>
        )}

        {/* Expanded: Active Agent Card */}
        {isExpanded && activeAgent && (
          <div className="border-t border-white/5 px-3 py-2">
            <button
              className="flex items-center gap-2 w-full text-left hover:opacity-80 transition-opacity"
              onClick={() => {
                navigateToAgent(activeAgent.id);
                eventBus.emit({ category: 'ui', type: 'ui.hud_agent_click', level: 'info', source: 'NeuralLink', message: `Agent clicked: ${activeAgent.id}` });
              }}
              title={`Go to ${activeAgent.nameEn} console`}
            >
              <div className={cn(
                "w-6 h-6 rounded flex items-center justify-center border",
                activeAgent.bgColor, activeAgent.borderColor
              )}>
                <Brain className={cn("w-3.5 h-3.5", activeAgent.color)} />
              </div>
              <div className="flex-1">
                <div className={cn("text-[10px] font-mono", activeAgent.color)}>
                  {language === 'zh' ? activeAgent.name : activeAgent.nameEn}
                </div>
                <div className="text-[8px] text-zinc-600">
                  {language === 'zh' ? activeAgent.desc : activeAgent.descEn}
                </div>
              </div>
              <ArrowUpRight className="w-3 h-3 text-zinc-700" />
            </button>
          </div>
        )}

        {/* Expanded: Infrastructure Health Summary (Phase 39) */}
        {isExpanded && (() => {
          const infraReport = getLastInfraReport();
          if (!infraReport || infraReport.status === 'idle') return null;
          const { summary } = infraReport;
          const infraStatusColor = summary.offline > 2 ? 'text-red-400' :
            summary.offline > 0 ? 'text-amber-400' : 'text-emerald-400';
          const keyServices = infraReport.checks.filter(c => c.category === 'service').slice(0, 4);
          return (
            <div className="border-t border-white/5 px-3 py-1.5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
                  INFRA_HEALTH
                </span>
                <span className={cn("text-[8px] font-mono", infraStatusColor)}>
                  {summary.online}/{summary.total}
                </span>
              </div>
              <div className="flex items-center gap-1 flex-wrap">
                {keyServices.map(svc => {
                  const dotColor = svc.status === 'online' ? 'bg-emerald-500' :
                    svc.status === 'degraded' ? 'bg-amber-500' :
                    svc.status === 'offline' ? 'bg-red-500' :
                    svc.status === 'checking' ? 'bg-sky-500 animate-pulse' : 'bg-zinc-700';
                  return (
                    <div
                      key={svc.id}
                      className="flex items-center gap-1 px-1 py-0.5 rounded bg-zinc-800/30 border border-zinc-800/50"
                      title={`${svc.name}: ${svc.status}${svc.latencyMs ? ` (${svc.latencyMs}ms)` : ''}`}
                    >
                      <div className={cn("w-1.5 h-1.5 rounded-full", dotColor)} />
                      <span className="text-[7px] font-mono text-zinc-500">{svc.name.split(' ')[0]}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })()}

        {/* Expanded: Model Routing Status (Phase 40) */}
        {isExpanded && (() => {
          const configs = loadProviderConfigs();
          const enabled = configs.filter(c => c.enabled && c.apiKey);
          const total = Object.keys(PROVIDERS).length;
          if (enabled.length === 0 && total === 0) return null;
          return (
            <div className="border-t border-white/5 px-3 py-1.5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
                  MODEL_ROUTING
                </span>
                <span className={cn("text-[8px] font-mono", enabled.length > 0 ? "text-emerald-400" : "text-zinc-600")}>
                  {enabled.length}/{total}
                </span>
              </div>
              <div className="flex items-center gap-1 flex-wrap">
                {enabled.slice(0, 5).map(cfg => {
                  const provider = PROVIDERS[cfg.providerId];
                  return (
                    <div
                      key={cfg.providerId}
                      className="flex items-center gap-1 px-1 py-0.5 rounded bg-zinc-800/30 border border-zinc-800/50"
                      title={`${provider?.displayName || cfg.providerId}: ${cfg.defaultModel || provider?.defaultModel}`}
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span className="text-[7px] font-mono text-zinc-500">
                        {provider?.icon || cfg.providerId.slice(0, 2).toUpperCase()}
                      </span>
                    </div>
                  );
                })}
                {enabled.length === 0 && (
                  <span className="text-[7px] font-mono text-zinc-700">No active providers</span>
                )}
              </div>
            </div>
          );
        })()}

        {/* Expanded: Runner Service Status (Phase 42) */}
        {isExpanded && (() => {
          const runner = getRunnerHealth();
          const dotColor = runner.status === 'online' ? 'bg-emerald-500' :
            runner.status === 'checking' ? 'bg-sky-500 animate-pulse' :
            runner.status === 'offline' ? 'bg-red-500' :
            runner.status === 'error' ? 'bg-amber-500' : 'bg-zinc-700';
          const statusText = runner.status === 'online' ? `Online (${runner.latencyMs}ms)` :
            runner.status === 'offline' ? 'Offline' :
            runner.status === 'error' ? runner.error || 'Error' :
            runner.status === 'checking' ? 'Testing...' : 'Not tested';
          return (
            <div className="border-t border-white/5 px-3 py-1.5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
                  RUNNER_SVC
                </span>
                <span className={cn("text-[8px] font-mono",
                  runner.status === 'online' ? "text-emerald-400" :
                  runner.status === 'offline' ? "text-red-400" : "text-zinc-600"
                )}>
                  :3002
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={cn("w-1.5 h-1.5 rounded-full", dotColor)} />
                <span className="text-[7px] font-mono text-zinc-500">{statusText}</span>
              </div>
            </div>
          );
        })()}

        {/* Expanded: PG Telemetry Schema Status (Phase 43) */}
        {isExpanded && (() => {
          const pg = getPgTelemetryState();
          const pgDotColor = pg.status === 'connected' ? 'bg-cyan-500' :
            pg.status === 'checking' ? 'bg-sky-500 animate-pulse' :
            pg.status === 'disconnected' ? 'bg-red-500' :
            pg.status === 'error' ? 'bg-amber-500' : 'bg-zinc-700';
          const pgText = pg.status === 'connected'
            ? `Connected (${pg.latencyMs}ms)${pg.rowCount ? ` · ${pg.rowCount} rows` : ''}`
            : pg.status === 'disconnected' ? 'Disconnected'
            : pg.status === 'error' ? pg.error || 'Error'
            : pg.status === 'checking' ? 'Testing...' : 'Not configured';
          return (
            <div className="border-t border-white/5 px-3 py-1.5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
                  TELEMETRY_DB
                </span>
                <span className={cn("text-[8px] font-mono",
                  pg.status === 'connected' ? "text-cyan-400" :
                  pg.status === 'disconnected' ? "text-red-400" : "text-zinc-600"
                )}>
                  :3003
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={cn("w-1.5 h-1.5 rounded-full", pgDotColor)} />
                <span className="text-[7px] font-mono text-zinc-500">{pgText}</span>
              </div>
            </div>
          );
        })()}

        {/* Expanded: NAS Sync Status (Phase 51) */}
        {isExpanded && nasSyncStatus && (() => {
          const nasOnline = nasSyncStatus.nasOnline;
          const pending = nasSyncStatus.pendingCount;
          const overflow = nasSyncStatus.overflowCount;
          const strategy = nasSyncStatus.strategy;
          const nasDotColor = nasOnline ? 'bg-emerald-500' :
            pending > 0 ? 'bg-amber-500 animate-pulse' : 'bg-zinc-600';
          const nasText = nasOnline
            ? `Online · Q:${pending}${overflow > 0 ? ` · OVF:${overflow}` : ''}`
            : `Offline · Q:${pending}${nasSyncStatus.retryAttempt > 0 ? ` · Retry:${nasSyncStatus.retryAttempt}` : ''}`;
          return (
            <div className="border-t border-white/5 px-3 py-1.5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
                  NAS_SYNC
                </span>
                <div className="flex items-center gap-1.5">
                  <span className={cn("text-[8px] font-mono",
                    nasOnline ? "text-emerald-400" : pending > 0 ? "text-amber-400" : "text-zinc-600"
                  )}>
                    {strategy.toUpperCase()}
                  </span>
                  <button
                    onClick={() => {
                      useSystemStore.getState().openSettings('general');
                      eventBus.emit({ category: 'ui', type: 'ui.hud_settings', level: 'info', source: 'NeuralLink', message: 'Open settings from NAS_SYNC panel' });
                    }}
                    className="p-0.5 rounded text-zinc-600 hover:text-primary hover:bg-primary/10 transition-all"
                    title={language === 'zh' ? '打开通用设置' : 'Open General Settings'}
                  >
                    <Settings2 className="w-2.5 h-2.5" />
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={cn("w-1.5 h-1.5 rounded-full", nasDotColor)} />
                <span className="text-[7px] font-mono text-zinc-500">{nasText}</span>
                {nasOnline && (
                  <HardDrive className="w-2.5 h-2.5 text-emerald-500/50 ml-auto" />
                )}
              </div>
            </div>
          );
        })()}

        {/* Expanded: Quick Navigation */}
        {isExpanded && (
          <div className="border-t border-white/5 px-3 py-1.5 flex items-center gap-1">
            {[
              { icon: Cpu, label: 'HW', tab: 'hardware_monitor', color: 'text-violet-400' },
              { icon: TerminalSquare, label: 'DevOps', tab: 'devops', color: 'text-emerald-400' },
              { icon: Shield, label: 'Sec', tab: 'security_audit', color: 'text-red-400' },
              { icon: Network, label: 'MCP', tab: 'mcp', color: 'text-pink-400' },
              { icon: Activity, label: 'Infra', tab: 'infra_health', color: 'text-emerald-400' },
              { icon: FileText, label: 'Ops', tab: 'ops_script', color: 'text-amber-400' },
              { icon: Radio, label: 'Agent', tab: 'telemetry_agent_manager', color: 'text-pink-400' },
              { icon: Database, label: 'PG:Tel', tab: 'metrics_history', color: 'text-cyan-400' },
              { icon: Server, label: 'PG:Dpl', tab: 'pg_proxy_deploy_kit', color: 'text-cyan-400' },
            ].map(q => (
              <button
                key={q.tab}
                onClick={() => {
                  navigateToConsoleTab(q.tab);
                  eventBus.emit({ category: 'ui', type: 'ui.hud_quicknav', level: 'info', source: 'NeuralLink', message: `Quick nav: ${q.tab}` });
                }}
                className={cn(
                  "flex items-center gap-1 px-1.5 py-0.5 rounded text-[8px] font-mono transition-all hover:bg-white/5",
                  q.color
                )}
                title={`Open ${q.label}`}
              >
                <q.icon className="w-2.5 h-2.5" />
                {q.label}
              </button>
            ))}
          </div>
        )}

        {/* Expanded: Keyboard Shortcuts */}
        {isExpanded && (
          <div className="border-t border-white/5 px-3 py-1.5 flex flex-wrap gap-x-3 gap-y-0.5">
            {[
              { keys: '⌘M', label: language === 'zh' ? '模式' : 'Mode' },
              { keys: '⌘K', label: language === 'zh' ? '搜索' : 'Search' },
              { keys: '⌘H', label: 'HUD' },
              { keys: '/', label: language === 'zh' ? '命令' : 'Cmd' },
            ].map(s => (
              <div key={s.keys} className="flex items-center gap-1 text-[8px] font-mono text-zinc-600">
                <kbd className="px-1 py-0.5 bg-zinc-800/80 rounded border border-zinc-700/50 text-[7px] text-zinc-400">{s.keys}</kbd>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Bottom Scanline Effect */}
        <div className="h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      </div>
    </div>
  );
}

// Mobile Neural Link Component
function MobileNeuralLink({ status, chatMode, cpuLoad, latency, isStreaming, messages }: {
  status: 'optimal' | 'warning' | 'critical' | 'booting';
  chatMode: 'navigate' | 'ai';
  cpuLoad: number;
  latency: number;
  isStreaming: boolean;
  messages: { id: string }[];
}) {
  const statusColors = {
    optimal: "border-emerald-500/30 bg-emerald-500/5",
    warning: "border-amber-500/30 bg-amber-500/5",
    critical: "border-red-500/30 bg-red-500/5",
    booting: "border-sky-500/30 bg-sky-500/5",
  };
  const dotColors = {
    optimal: "bg-emerald-500",
    warning: "bg-amber-500",
    critical: "bg-red-500",
    booting: "bg-sky-500",
  };

  return (
    <div className="fixed bottom-[60px] left-2 right-2 z-30">
      <div className={cn(
        "flex items-center justify-between px-3 py-1.5 rounded-lg border backdrop-blur-md",
        statusColors[status]
      )}>
        <div className="flex items-center gap-2">
          <div className="relative">
            <div className={cn("w-2 h-2 rounded-full", dotColors[status])} />
            <div className={cn("absolute inset-0 w-2 h-2 rounded-full animate-ping opacity-30", dotColors[status])} />
          </div>
          <span className={cn(
            "text-[8px] font-mono tracking-wider px-1.5 py-0.5 rounded",
            chatMode === 'ai' ? "text-emerald-400 bg-emerald-500/10" : "text-amber-400 bg-amber-500/10"
          )}>
            {chatMode === 'ai' ? 'AI' : 'NAV'}
          </span>
          {isStreaming && (
            <span className="text-[8px] font-mono text-sky-400 animate-pulse">STREAM</span>
          )}
        </div>
        <div className="flex items-center gap-3 text-[9px] font-mono text-zinc-500">
          <span>CPU {Math.round(cpuLoad)}%</span>
          <span>{latency}ms</span>
          <span>{messages.length} msg</span>
        </div>
      </div>
    </div>
  );
}