# YYC3 Navigation System Design - Level 4 & Level 5 (The Micro-Universe)

## 🧭 Navigation Deep Dive: From Macro to Nano

While Levels 1-3 handle the structural navigation of the platform, **Level 4 (Resource Units)** and **Level 5 (Detail Properties)** are where the actual operational work occurs. These levels are dynamic, context-sensitive, and data-driven.

### 🟡 Level 4: Resource Units Navigation (The "Nano" View)

**Design Goal**: Provide navigation within a specific collection of resources identified by the Level 3 context.

**Contextual Behavior**:
*   **When in L04 AI Intelligence**: Tabs or Cards representing specific Agents (Navigator, Thinker, Oracle).
*   **When in L01 Infrastructure**: List or Grid of specific Nodes, Pods, or Clusters.
*   **When in L05 Business**: List of active Projects or Workflows.

**UI Pattern**:
*   **Split View**: A secondary list panel appearing to the right of the L3 sidebar.
*   **Card Grid**: Main content area displays a grid of resource cards (as seen in the current ConsoleView).
*   **Search/Filter Bar**: Localized search for this specific resource set.

**Example: AI Intelligence Layer (L4)**
*   *Navigation Items*:
    1.  **Agent: Navigator** (Status: Idle)
    2.  **Agent: Thinker** (Status: Thinking)
    3.  **Agent: Oracle** (Status: Offline)
    4.  **Vector DB: Main** (Status: Ready)

### 🔴 Level 5: Detail Properties Navigation (The "Pico" View)

**Design Goal**: Deep introspection of a single resource unit selected in Level 4.

**Contextual Behavior**:
*   Activated when a specific Resource (e.g., "Agent: Navigator") is clicked.
*   Replaces the main content area or opens a slide-over panel.

**UI Pattern**:
*   **Internal Tabs**: Located within the resource view.
*   **Standard Tabs**:
    *   `Overview`: Health, Vital Metrics, Summary.
    *   `Config`: YAML/JSON configuration editor.
    *   `Logs`: Real-time streaming logs.
    *   `Metrics`: Historical performance charts.
    *   `Terminal`: SSH/Exec console (for L1/L4 resources).
    *   `Trace`: Distributed tracing (for L3/L5 resources).

**Example: Agent: Navigator (L5 View)**
*   **Tab 1: Status**: "Current Task: Analyzing Codebase..."
*   **Tab 2: Conversation**: Chat history with this agent.
*   **Tab 3: Memory**: View RAG context and short-term memory.
*   **Tab 4: Settings**: Adjust temperature, model (GPT-4/Claude-3), and prompts.

---

## 🔄 Interaction Flow Example

1.  **User Clicks L1 "System"**: Sidebar shows L1-L9 layers.
2.  **User Clicks L3 "L01 Infrastructure"**: Main area shows K8s Clusters.
3.  **User Clicks L4 "Cluster-Alpha"**: Main area focuses on Cluster-Alpha.
4.  **User Clicks L5 "Nodes" Tab**: Views list of nodes in that cluster.
5.  **User Clicks Specific Node**: Opens detailed node metrics.

## 🎨 Visual Hierarchy Summary

| Level | Component | Color/Style | Permanence |
| :--- | :--- | :--- | :--- |
| **L1** | Main Sidebar | Glass/Dark | Permanent |
| **L2** | Top Bar | Transparent | Permanent |
| **L3** | Context Sidebar | Layer Colors | Contextual (Arch View) |
| **L4** | Resource List/Grid | Card/Surface | Dynamic |
| **L5** | Detail Tabs | Accent Underline | Dynamic |

---
*Design Date: 2026-02-08 | Status: Design Completed*
