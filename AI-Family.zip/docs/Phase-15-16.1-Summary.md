# YYC3 Hacker Chatbot — Phase 15.1 + 15.2 + 16.1 + Device Cards Summary

**完成日期:** 2026-02-14
**执行者:** YYC3 DevOps AI Assistant
**状态:** 已完成

---

## 1. Phase 15.1 — DatabaseSelector NAS SQLite 真实连接

### 核心改进

将 DatabaseSelector 的 Mock 验证升级为**真实 HTTP 连接验证**:

| 数据库类型 | 验证方式 | 降级策略 |
|-----------|---------|---------|
| **SQLite** | `POST http://NAS_IP:8484/api/db/query` + `SELECT sqlite_version()` | NAS 不可达时自动降级到 localStorage |
| **其他 DB** | `fetch(HEAD, no-cors)` 测试端点可达性 | 端点不可达时接受配置并标注未验证 |

### 新增客户端: `/src/lib/nas-client.ts`

完整的 NAS 与集群 HTTP 客户端:

```
nas-client.ts (~450 行)
├── Device Registry (4 设备配置, 基于 /docs/yyc3-Max.md)
├── Device Config Persistence (localStorage)
├── Network Health Check (HTTP ping)
├── NAS SQLite HTTP Proxy Client
│   ├── querySQLite(sql, params, config)
│   └── testSQLiteConnection(config) → { success, latencyMs, version }
├── Docker Engine API Client
│   ├── docker.info()
│   ├── docker.ping()
│   ├── docker.containers.list/start/stop/restart/remove/logs
│   └── docker.images.list()
└── Mock Data (Fallback)
    ├── MOCK_DOCKER_CONTAINERS (7 个模拟容器)
    └── MOCK_DOCKER_INFO
```

### SQLite 连接流程

```
用户选择 SQLite → 自动填充 NAS IP:Port
     │
     ├── VALIDATE 点击
     │   ├── POST {host}:{port}/api/db/query
     │   │   body: { db: "/Volume2/yyc3/yyc3.db", sql: "SELECT sqlite_version()" }
     │   │
     │   ├── 成功 → "SQLite 3.x.x @ 192.168.3.45:8484 — Connected (42ms)"
     │   └── 失败 → "SQLite — localStorage fallback mode (NAS offline)"
     │
     └── 两种情况都 setDbConnected(true), 保证前端功能不中断
```

---

## 2. Phase 15.2 — WebSocket 多端点实时数据流

### 核心改进

| 特性 | 旧版 | 新版 |
|------|------|------|
| 端点 | 硬编码 `ws://localhost:3001/ws` | 动态从 Device Registry 读取 |
| 端点数 | 1 个 | 3 个 (NAS → M4-Max → localhost) |
| 故障转移 | 单端点重连 | 多端点轮转 + 指数退避 |
| 频道 | metrics, logs, heartbeat | + docker_events |
| 状态导出 | `{ status, send }` | + `activeEndpoint` |

### 连接策略

```
Priority 1: ws://192.168.3.45:3001/ws  (NAS WS Relay)
        ↓ fail
Priority 2: ws://192.168.3.22:3001/ws  (M4-Max Local)
        ↓ fail
Priority 3: ws://localhost:3001/ws      (Fallback)
        ↓ all fail
        → simulation mode (useMetricsSimulator)
```

---

## 3. Phase 16.1 — Docker API 代理 (铁威马 F4-423)

### 新增组件: `DockerManager.tsx` (~350 行)

完整的 Docker 容器管理界面:

```
DockerManager
├── Header (连接状态 LIVE/MOCK + CONFIG + REFRESH)
├── Config Panel (Host/Port/API Version 可配置, localStorage 持久化)
├── System Info Overview (4 个统计卡片)
│   ├── Containers (running/total)
│   ├── Images (count + driver)
│   ├── CPU / Arch (cores + architecture)
│   └── Memory (total + Docker version)
├── Container List (按状态排序: running 优先)
│   └── ContainerRow ×N
│       ├── Status Dot (green pulse / red)
│       ├── Name + Image + Status
│       ├── Port Mappings (chips)
│       ├── Actions: Start/Stop/Restart + Logs
│       └── Expandable Log Viewer (50 行 tail)
└── Connection Notice (NAS 不可达时的提示)
```

### Docker API 端点映射

| 操作 | HTTP | URL |
|------|------|-----|
| System Info | GET | `/v1.41/info` |
| Ping | GET | `/v1.41/_ping` |
| List Containers | GET | `/v1.41/containers/json?all=true` |
| Start Container | POST | `/v1.41/containers/{id}/start` |
| Stop Container | POST | `/v1.41/containers/{id}/stop` |
| Restart Container | POST | `/v1.41/containers/{id}/restart` |
| Remove Container | DELETE | `/v1.41/containers/{id}` |
| Container Logs | GET | `/v1.41/containers/{id}/logs?stdout=true&stderr=true&tail=100` |
| List Images | GET | `/v1.41/images/json` |

### Mock 容器 (NAS 不可达时)

| Container | Image | State | Ports |
|-----------|-------|-------|-------|
| yyc3-postgres | postgres:16-alpine | running | 5432 |
| yyc3-redis | redis:7-alpine | running | 6379 |
| yyc3-sqlite-proxy | yyc3/sqlite-http | running | 8484 |
| yyc3-ws-relay | yyc3/ws-relay | running | 3001 |
| portainer | portainer-ce | running | 9000 |
| yyc3-mcp-server | yyc3/mcp-server | exited | 8080 |
| elasticsearch | elasticsearch:8.12 | running | 9200,9300 |

---

## 4. 设备信息卡片 — 可编辑/只读双模式

### 新增组件: `DeviceCardManager.tsx` (~450 行)

替代原有的静态 `ClusterTopology.tsx`:

```
DeviceCardManager
├── Header (在线计数 + PING ALL + EDIT 按钮)
├── Edit Mode Banner (蓝色提示条)
└── Device Grid (2×2)
    └── DeviceCard ×4
        ├── [可编辑] Display Name (input)
        ├── [可编辑] Hostname (input)
        ├── [可编辑] IP Address (input)
        ├── [只读] Chip (Cpu icon + auto-detected)
        ├── [只读] Cores (Activity icon + auto-detected)
        ├── [只读] RAM (MemoryStick icon + auto-detected)
        ├── [只读] Storage (HardDrive icon + auto-detected)
        ├── Live Metrics (CPU/MEM/DSK bars + Temp + Network)
        ├── Services Panel (expandable)
        │   └── ServiceRow ×N (status dot + name + port + protocol + open/toggle)
        └── PING Button
```

### 设备数据源 (基于 `/docs/yyc3-Max.md`)

| ID | 设备 | IP | Chip | RAM | Storage |
|----|------|----|------|-----|---------|
| m4-max | MacBook Pro M4 Max | 192.168.3.22 | Apple M4 Max | 128GB | 2TB + 2TB |
| imac-m4 | iMac M4 | 192.168.3.77 | Apple M4 | 32GB | 2TB + 2TB SN850X |
| matebook | MateBook X Pro | 192.168.3.66 | Intel Ultra7 155H | 32GB | 1TB |
| yanyucloud | 铁威马 F4-423 NAS | 192.168.3.45 | Intel Quad-Core | 32GB | RAID6 4x8TB + RAID1 2x2TB SSD |

### 可编辑 vs 只读 字段矩阵

| 字段 | 可编辑 | 说明 |
|------|--------|------|
| Display Name | 可编辑 | 用户自定义设备名称 |
| Hostname | 可编辑 | 网络主机名 |
| IP Address | 可编辑 | 局域网 IP |
| Chip | 只读 | 系统自动识别 |
| Cores | 只读 | 系统自动识别 |
| RAM | 只读 | 系统自动识别 |
| Storage | 只读 | 系统自动识别 |
| OS | 只读 | 系统自动识别 |
| Services | 可切换启用/禁用 | 编辑模式下可 toggle |

### 网络服务集成

每个设备预配了实用网络服务项:

| 设备 | 服务 |
|------|------|
| M4-Max | SSH, Ollama (11434), LM Studio (1234), Dev Server (5173) |
| iMac M4 | SSH, Ollama (11434) |
| MateBook | SSH, RDP (3389) |
| NAS | TOS Web (9898), SSH, Docker API (2375), SQLite HTTP (8484), SMB (445), WebDAV (5005) |

---

## 5. 文件变更清单

### 新增文件 (3个)

| 文件路径 | 行数 | 说明 |
|----------|------|------|
| `src/lib/nas-client.ts` | ~450 | NAS/Docker/设备统一客户端 |
| `src/app/components/console/DeviceCardManager.tsx` | ~450 | 可编辑设备卡片管理器 |
| `src/app/components/console/DockerManager.tsx` | ~350 | Docker 容器管理界面 |

### 修改文件 (3个)

| 文件路径 | 变更 |
|----------|------|
| `src/lib/useWebSocket.ts` | 多端点轮转 + docker_events 频道 |
| `src/app/components/console/DatabaseSelector.tsx` | NAS SQLite 真实连接 + HTTP 端点验证 |
| `src/app/components/console/ConsoleView.tsx` | +DeviceCardManager +DockerManager +Docker 导航项 |

---

## 6. 导航栏更新

左侧 Dock 导航栏现有 7 个入口:

| 图标 | Label | View |
|------|-------|------|
| LayoutDashboard | 总控台 | Dashboard (DeviceCardManager + Metrics + Logs) |
| Brain | 智愈中心 | AI Agent Matrix / Chat |
| BarChart3 | LLM 用量 | Token Usage Dashboard |
| Layers2 | 架构全景 | 9-Layer Architecture |
| Box | Docker | Docker Container Manager |
| Terminal | DevOps | DevOps Terminal |
| Sliders | 系统设置 | Settings |

---

## 7. 累计交付物

| Phase | 状态 | 核心交付 |
|-------|------|----------|
| 14.1 | 已完成 | LLM Bridge + Provider Registry + Crypto |
| 14.2 | 已完成 | Circuit Breaker + Health Score + Failover |
| 14.3 | 已完成 | 7 Agent 结构化 Prompt 工程 |
| 14.4 | 已完成 | Recharts Token Dashboard |
| **15.1** | **已完成** | **NAS SQLite 真实连接 + HTTP 验证** |
| **15.2** | **已完成** | **多端点 WebSocket + 设备可编辑卡片** |
| **16.1** | **已完成** | **Docker API 代理 + 容器管理 UI** |

---

## 8. 下一步建议

| 阶段 | 名称 | 预计工期 | 描述 |
|------|------|----------|------|
| 16.2 | MCP 工具链真实化 | 3天 | MCP Server 本地集成 + Tool Registry |
| 17.1 | 全链路数据引擎 | 4天 | 指标持久化 + 历史查询 + 趋势分析 |
| 17.2 | Agent 协作编排 | 3天 | 多 Agent 串联工作流 + 状态传递 |
| 18.1 | 安全加固 | 3天 | CSP + API Key 审计 + 依赖扫描 |

---

*Generated by YYC3 DevOps AI Assistant | Phase 15.1 + 15.2 + 16.1 Complete*
*遵循 "五高五标五化" 设计系统 | 赛博朋克视觉语言*
