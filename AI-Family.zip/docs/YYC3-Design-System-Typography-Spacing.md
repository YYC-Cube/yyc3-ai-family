# YYC3 Design System - 1.2 & 1.3 Core Foundations

## 1.2 Typography System (字体系统)

The typography system is engineered for readability across high-density dashboards and document-heavy views.

### Font Family
*   **System Stack**: `San Francisco` (macOS), `Segoe UI` (Windows), `Roboto` (Android), fallback to `sans-serif`.
*   *Rationale*: Zero latency, native OS feel, perfect rendering.

### Hierarchy & Scale

| Semantic | Tag | Size (Desktop) | Weight | Line Height | Tracking (CN) | Tracking (EN) | Usage |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **Header 1** | `<h1>` | 32px | 700 (Bold) | 1.4 | 0.05em | 0.01em | Page Titles |
| **Header 2** | `<h2>` | 24px | 600 (Semi) | 1.4 | 0.05em | 0.01em | Section Headers |
| **Header 3** | `<h3>` | 20px | 600 (Semi) | 1.5 | 0.05em | 0.01em | Card Titles |
| **Header 4** | `<h4>` | 18px | 500 (Med) | 1.5 | 0.05em | 0.01em | Subsection |
| **Body** | `<p>` | 14px/16px | 400 (Reg) | 1.6 | 0.05em | 0.01em | Primary Content |
| **Small** | `<small>`| 12px | 400 (Reg) | 1.4 | 0.05em | 0.01em | Metadata, Hints |

### Responsive Behavior
*   Uses `rem` units for accessibility scaling.
*   Letter spacing automatically adjusts based on `lang="zh"` or `lang="en"` context.

---

## 1.3 Spacing System (间距系统)

Built on a **4px base grid** to ensure visual rhythm and alignment.

### Grid Scale

| Token | Pixels | Usage Context |
| :--- | :--- | :--- |
| `space-1` | 4px | Icon/Text gaps, Tight grouping |
| `space-2` | 8px | **Component Internal** (Button padding, Inputs) |
| `space-3` | 12px | List items, Form gaps |
| `space-4` | 16px | **Component Internal** (Card padding, Large inputs) |
| `space-5` | 20px | Navigation items |
| `space-6` | 24px | **Page Margins** (Mobile) |
| `space-8` | 32px | **Component External** (Card separation) |
| `space-10` | 40px | Section delineation |
| `space-12` | 48px | **Page Margins** (Desktop), Section Blocks |
| `space-16` | 64px | Major Layout Areas |

### Layout Standards
*   **Component Internal**: 8px - 16px
*   **Component External**: 16px - 32px
*   **Page Container**: 24px (Mobile) / 48px (Desktop) - *Implemented via `.page-container`*
*   **Section Vertical**: 32px - 48px - *Implemented via `.section-spacing`*

---
*System Version: 1.0.0 | Updated: 2026-02-08*
