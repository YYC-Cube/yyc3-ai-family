# YYC3 5-Level Navigation System Specification (Aligned)

## 🧭 Navigation Hierarchy Definitions

Based on the latest architectural review, the navigation system is strictly defined as follows:

### 🚨 Level 1: Global Context (全局功能导航)
*Location: Left Sidebar (Fixed)*
*   🏠 **Home** (首页)
*   📊 **Dashboard** (仪表盘)
*   🤖 **AI Intelligence** (AI智能)
*   💼 **Business Services** (业务服务)
*   🗄️ **Data Management** (数据管理)
*   ⚙️ **System** (系统)
*   🔧 **Settings** (设置)

### 🚨 Level 2: Functional Views (功能视图导航)
*Location: Top Bar (Tabs)*
*   📐 **Architecture View** (架构视图)
*   🔍 **Search** (搜索)
*   📚 **Documentation** (文档)
*   🧪 **Testing** (测试)
*   📈 **Monitoring** (监控)
*   🔐 **Security** (安全)
*   📊 **Analytics** (分析)
*   📝 **Logs** (日志)

### 🚨 Level 3: Architecture Layers (架构层级导航)
*Location: Inner Sidebar (Contextual)*
*   **Layer-09** System Settings (系统设置层)
*   **Layer-08** Extension & Evolution (扩展演进层)
*   **Layer-07** User Interaction (用户交互层)
*   **Layer-06** Application Presentation (应用表现层)
*   **Layer-05** Business Logic (业务逻辑层)
*   **Layer-04** AI Intelligence (AI 智能层)
*   **Layer-03** Core Services (核心服务层)
*   **Layer-02** Data Storage (数据存储层)
*   **Layer-01** Infrastructure (基础设施层)

### 🚨 Level 4: Functional Modules (功能模块导航)
*Location: Resource Grid / List Panel*

**The 7 Identity Agents (七大智能体):**
1.  🧠 **智愈·领航员** (Navigator) - Strategic Planning
2.  💡 **洞见·思想家** (Thinker) - Deep Analysis
3.  🔮 **预见·先知** (Prophet) - Predictive Modeling
4.  👤 **知遇·伯乐** (Talent Scout) - Resource Matching
5.  🌐 **元启·天枢** (Pivot) - Central Control
6.  🛡️ **卫安·哨兵** (Sentinel) - Security & Defense
7.  📚 **格物·宗师** (Grandmaster) - Knowledge Engineering

**System Modules:**
*   ⚙️ System Config (系统配置)
*   👤 User Settings (用户设置)
*   📊 Monitoring & Diag (监控诊断)
*   🔧 Maint & Optimization (维护优化)
*   📝 Log Audit (日志审计)

### 🚨 Level 5: Presentation Views (展示视图导航)
*Location: Detail Panel / Workspace*
*   📂 **File Tree** (文件树)
*   🔄 **Flow** (流程)
*   📊 **Data** (数据)
*   🔗 **Relation** (关系)
*   📝 **Logs** (日志)
*   📈 **Chart** (图表)
*   🗺️ **Topology** (拓扑)
*   📋 **List** (列表)

---
*Status: Aligned with Audit Requirements | Date: 2026-02-08*
