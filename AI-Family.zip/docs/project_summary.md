# YYC3 Hacker Chatbot - Project Summary

## 1. Project Overview
**YYC3 Hacker Chatbot** is a DevOps Intelligent Development Platform designed with a high-fidelity Cyberpunk aesthetic mixed with modern UI principles. It simulates a hacker terminal environment for developers to manage cloud infrastructure, generate code, and orchestrate AI agents.

## 2. Design System
- **Theme**: Cyberpunk / Sci-Fi Industrial.
- **Colors**: 
  - Primary: `#0EA5E9` (Tech Blue)
  - Background: `#0F172A` -> `#1E293B` (Deep Space Gradient)
  - Accents: Neon Green (`#22C55E`) for success, Warning Yellow (`#F59E0B`), Agent Colors (Purple, Blue, Orange).
- **Typography**: 
  - Headings: `JetBrains Mono`
  - Body: `Inter`
  - Code: `Fira Code`
- **Effects**: CRT Scanlines, Glassmorphism, Glow Text, Smooth Transitions, Micro-interactions.

## 3. Core Components Implemented
### 3.1 Layout & Navigation
- **Sidebar (`Sidebar.tsx`)**: 
  - Navigation for Terminal, Console, Projects, Artifacts views.
  - User status indicator with online/offline simulation.
  - "New Session" quick action with hover scaling effects.
  - **i18n Support**: Full Chinese/English bilingual support.
- **Settings (`SettingsModal.tsx`)**:
  - Full-screen modal with tabs for AI Models, GitOps, Extensions, etc.
  - Language toggle (ZH/EN).
  - Deep linking support.
  - Animated entrance and tab transitions.

### 3.2 Chat Interface (`ChatArea.tsx`)
- **Streaming Response**: Simulated typing effect for AI responses.
- **Message Bubbles**: 
  - Custom markdown parsing.
  - Code block detection with syntax highlighting.
  - **Agent Identity**: Visual distinction for Architect, Coder, Auditor agents (localized).
- **Global Search (`SearchPalette.tsx`)**:
  - `Ctrl+K` or click-to-open command palette.
  - Search results grouped by File, Chat, Code.
  - Term highlighting.

### 3.3 System Console (`ConsoleView.tsx`)
- **New Feature**: Full-screen simulated bash terminal.
- **Features**:
  - CRT overlay effects (scanlines, flicker).
  - Command parsing (`ls`, `cd`, `help`, `git`) with localized help text.
  - Command history (Up/Down arrows).

### 3.4 Artifacts System (`ArtifactsPanel.tsx`)
- **Dynamic Content**: Displays code from chat context.
- **Tabs**: Source / Render / Stdout views.
- **Transitions**: Smooth slide-in animations.

## 4. Interaction Flows
### Flow 1: Start New Session (Implemented)
- Triggers reset via `terminal.exe` or `NEW_SESSION`.
- Shows `ClaudeWelcome` screen with animated cards.
- Typing "Generate microservice" demos streaming text and artifact generation.

### Flow 2: Global Search (Implemented)
- **Trigger**: Click top search bar or press `Ctrl+K`.
- **UI**: `SearchPalette` overlay appears relative to the input.
- **Features**: 
  - Real-time filtering of mock data.
  - Highlighting of search terms.
  - Bilingual UI labels.

### Flow 3: AI Agent Collaboration (Implemented)
- **Trigger**: User asks "Build a React Component" (or Chinese equivalent "构建一个React组件").
- **Sequence**:
  1. **Architect**: Outlines the plan.
  2. **Coder**: Generates the code snippet.
  3. **Auditor**: Reviews for security/accessibility.
  4. **Orchestrator**: Confirms completion.
- **Localization**: Agent roles and responses adapt to selected language.

### Flow 4: Terminal Simulation (Implemented)
- **Trigger**: Click `sys_console` in Sidebar.
- **UI**: Transitions to a dark, CRT-styled terminal view.
- **Interaction**:
  - Localized `help` command output.
  - Full keyboard navigation support.

### Flow 5: Settings Deep Link (Implemented)
- **Trigger**: Click Github icon in Sidebar.
- **Action**: Opens `SettingsModal` switched to `GitOps`.

## 5. Technology Stack
- **Framework**: React + Vite
- **Styling**: Tailwind CSS v4 + Tailwind Merge + CLSX
- **Motion**: Framer Motion (`motion/react`) + Tailwind Animate
- **Icons**: Lucide React
- **Syntax Highlighting**: React Syntax Highlighter
- **Localization**: Custom Context-based i18n solution (`src/lib/i18n.tsx`)

## 6. Next Steps
- Connect real backend (Supabase) for history persistence.
- Implement `projects_dir` file explorer view with tree navigation.
- Add real execution sandbox for the Artifacts panel.
