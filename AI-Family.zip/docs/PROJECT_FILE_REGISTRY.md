# YYC3 Hacker Chatbot - Project File Registry

> **Phase 30 Audit** | Scan Date: 2026-02-17
> Full codebase inventory with status tracking for Figma Make sandbox deployment.

---

## Quick Stats

| Metric | Count |
|--------|-------|
| Total Files (src/) | 116 |
| Build Config Files | 7 |
| CSS Pipeline Files | 4 |
| Core Lib Modules | 18 |
| React Components | 57 |
| UI Base (shadcn) | 37 |
| Hooks | 5 |
| Test Files | 3 |
| Server (ref only) | 3 |
| Type Declarations | 2 |
| Docs | 40+ |
| `any` Violations | **0** |

---

## 1. Build Config Layer

> These files control the build pipeline. Manually edited versions take precedence.

| # | File | Lines | Role | Status |
|---|------|-------|------|--------|
| 1 | `/package.json` | 102 | Dependency manifest. `react`/`react-dom` in `peerDependencies` (platform-provided). Zustand v5, Zod v4, Tailwind v4. | Clean |
| 2 | `/tsconfig.json` | 33 | TypeScript config. `strict: true`, path alias `@/* -> ./src/*`, target ES2022. | Clean |
| 3 | `/vite.config.ts` | 22 | Vite + `@vitejs/plugin-react` + `@tailwindcss/vite`. Alias `@` -> `./src`. | Clean |
| 4 | `/vitest.config.ts` | 35 | Vitest config. jsdom env, setup file, coverage thresholds (60/50/60/60). | Clean |
| 5 | `/postcss.config.mjs` | 15 | Empty PostCSS config (Tailwind v4 handled by Vite plugin). | Clean |
| 6 | `/index.html` | 15 | HTML entry. `lang="zh-CN"`, theme-color `#0EA5E9`, loads `/src/main.tsx`. | Clean |
| 7 | `/public/favicon.svg` | 4 | Gem-blue `Y3` monospace icon, 32x32, rx=6. | Clean |

### Key Constraints

- `react` / `react-dom` **MUST** stay in `peerDependencies` (Figma Make sandbox provides them)
- `@tailwindcss/vite` plugin replaces PostCSS-based Tailwind processing
- `assetsInclude` covers `*.svg` and `*.csv` only (never `.css`/`.tsx`/`.ts`)

---

## 2. CSS Pipeline Layer

> Single Tailwind entry point. No duplicate `@import "tailwindcss"`.

```
main.tsx
  -> @/styles/index.css
       -> ./fonts.css          (Google Fonts: Inter, Fira Code, JetBrains Mono)
       -> ./tailwind.css       (THE ONLY @import 'tailwindcss')
       -> ./theme.css          (@theme tokens + :root vars + @layer base/utilities)
```

| # | File | Lines | Role | Status |
|---|------|-------|------|--------|
| 9 | `/src/styles/index.css` | 3 | Aggregator: imports fonts -> tailwind -> theme in order. | Clean |
| 10 | `/src/styles/fonts.css` | 1 | Google Fonts `@import url(...)` for Inter, Fira Code, JetBrains Mono. | Clean |
| 11 | `/src/styles/tailwind.css` | 5 | `@import 'tailwindcss' source(none)` + `@source` directives + `tw-animate-css`. | **Fixed P30** |
| 12 | `/src/styles/theme.css` | 261 | Design tokens (`@theme`), `:root` dark vars, `.light` override, base typography, utilities (scanline, glow-text, scrollbar, overlay). | **Fixed P30** |

### Phase 30 Fixes Applied

1. **`tailwind.css`**: Added `@source not "../server/**"` to exclude `src/server/` from Tailwind scanning (those files import `express`/`pg`/`ws` which are not installed in sandbox).
2. **`theme.css`**: Removed duplicate `@import "tailwindcss"` (was causing dual Tailwind root -> CSS compile failure -> cascade module load error).
3. **`App.tsx`**: Removed redundant `import "@/styles/theme.css"` (already imported via index.css chain).

---

## 3. Entry Layer

| # | File | Lines | Role | Status |
|---|------|-------|------|--------|
| 13 | `/src/main.tsx` | 15 | React 18 root mount with `StrictMode`. Imports `@/styles/index.css`. | Clean |
| 14 | `/src/vite-env.d.ts` | 58 | Vite env types (`ImportMetaEnv`) + `figma:asset/*` module declaration. | **Fixed P30** |
| 15 | `/src/types/global.d.ts` | 139 | Web Speech API, Local Font Access API, Window extensions. | Clean |

### Phase 30 Fix

- **`vite-env.d.ts`**: Added `declare module 'figma:asset/*'` so TypeScript resolves the virtual module used by `ClaudeWelcome.tsx`.

---

## 4. Main Application

| # | File | Lines | Role | Status |
|---|------|-------|------|--------|
| 16 | `/src/app/App.tsx` | 605 | Root component. `LanguageProvider` wrapper, `ErrorBoundary`, responsive detection, three-panel resizable layout (Vercel v0 style), `React.lazy` code-splitting for 7 views, ChatMode dual-mode (navigate/AI), LLM Bridge streaming integration. | Clean |

### App.tsx Architecture

```
<LanguageProvider>
  <AppContent>
    <YYC3Background />           -- CSS background effects
    <div.scanline />              -- CRT scanline overlay
    <Sidebar />                   -- Left navigation
    <main>
      <ErrorBoundary>
        <React.Suspense>
          activeView === 'terminal'  -> PanelGroup (Chat + Artifacts)
          activeView === 'console'   -> <ConsoleView /> (lazy)
          activeView === 'monitor'   -> <ServiceHealthMonitor /> (lazy)
          activeView === 'projects'  -> <ProjectsView /> (lazy)
          activeView === 'artifacts' -> <ArtifactsView /> (lazy)
          activeView === 'services'  -> <ServicesView /> (lazy)
          activeView === 'knowledge' -> <KnowledgeBaseView /> (lazy)
          activeView === 'bookmarks' -> <BookmarksView /> (lazy)
        </React.Suspense>
      </ErrorBoundary>
    </main>
    <SettingsModal />             -- 21-tab settings dialog
  </AppContent>
</LanguageProvider>
```

---

## 5. Chat Components

| # | File | Role | Key Dependencies |
|---|------|------|-----------------|
| 17 | `chat/ChatArea.tsx` | Chat main area: input bar, message list, file attachments, prompt templates, mode indicator | SearchPalette, MessageBubble, ClaudeWelcome, store |
| 18 | `chat/ClaudeWelcome.tsx` | Welcome screen with logo + quick actions | Inline `YYC3Logo` SVG component (zero external deps) |
| 19 | `chat/MessageBubble.tsx` | User/AI message bubbles with code block highlighting | react-syntax-highlighter (vscDarkPlus) |
| 20 | `chat/ArtifactsPanel.tsx` | Code preview panel + project navigation tree | react-resizable-panels, react-syntax-highlighter |
| 21 | `chat/YYC3Background.tsx` | Dynamic background image/brightness/blur from localStorage | None (pure CSS) |

### Note on `figma:asset`

~~`ClaudeWelcome.tsx` previously imported `figma:asset/bbf3e3fa...png`.~~ **RESOLVED in Phase 30 Global Audit**: replaced with inline `YYC3Logo` SVG component. Zero external dependencies. See Fix 3 in Section 15.

---

## 6. Layout, Settings, Search

| # | File | Role |
|---|------|------|
| 22 | `layout/Sidebar.tsx` | Left sidebar: view navigation, session list, status indicator, pin/collapse |
| 23 | `settings/SettingsModal.tsx` | 21-tab settings dialog (AI Models, Appearance, MCP, Persistence, etc.) |
| 24 | `search/SearchPalette.tsx` | Cmd+K global search palette |
| 25 | `monitoring/ServiceHealthMonitor.tsx` | Network monitoring dashboard view |

---

## 7. View Components (React.lazy)

| # | File | Role |
|---|------|------|
| 26 | `views/ProjectsView.tsx` | Project directory browser with file tree |
| 27 | `views/ArtifactsView.tsx` | Build artifacts log viewer |
| 28 | `views/ServicesView.tsx` | Service registry and management |
| 29 | `views/KnowledgeBaseView.tsx` | Knowledge base CRUD interface |
| 30 | `views/BookmarksView.tsx` | Bookmark manager with drag-and-drop |

---

## 8. Console Components

> All loaded via `ConsoleView.tsx` which itself uses `React.lazy` for heavy sub-panels.

| # | File | Role |
|---|------|------|
| 31 | `console/ConsoleView.tsx` | Console tab router (20+ tabs), lazy-loads sub-panels |
| 32 | `console/ActivityChart.tsx` | Real-time activity sparkline (Recharts) |
| 33 | `console/AgentChatInterface.tsx` | Per-agent chat with LLM Bridge streaming |
| 34 | `console/AgentIdentityCard.tsx` | Agent dual-identity role cards |
| 35 | `console/AgentOrchestrator.tsx` | Multi-agent collaboration UI |
| 36 | `console/ApiDocsViewer.tsx` | Interactive API documentation |
| 37 | `console/ClusterTopology.tsx` | Device cluster topology map |
| 38 | `console/CoreTestPanel.tsx` | In-app programmatic test runner |
| 39 | `console/DatabaseSelector.tsx` | NAS SQLite / localStorage toggle |
| 40 | `console/DevOpsTerminal.tsx` | DAG workflow editor + template library |
| 41 | `console/DeviceCardManager.tsx` | 4-node device monitoring cards |
| 42 | `console/DockerManager.tsx` | Docker container management |
| 43 | `console/FamilyPresenceBoard.tsx` | Family heartbeat presence board |
| 44 | `console/KnowledgeBase.tsx` | Knowledge base panel (console embed) |
| 45 | `console/LiveLogStream.tsx` | Real-time event bus log stream |
| 46 | `console/McpServiceBuilder.tsx` | MCP tool chain builder |
| 47 | `console/McpWorkflowsView.tsx` | MCP workflow visualization |
| 48 | `console/MetricsHistoryDashboard.tsx` | Historical metrics charts |
| 49 | `console/NasDeploymentToolkit.tsx` | NAS connectivity & deployment tools |
| 50 | `console/NasDiagnosticsPanel.tsx` | Startup self-diagnostics |
| 51 | `console/OllamaManager.tsx` | Local Ollama model management |
| 52 | `console/PersistenceManager.tsx` | Data persistence snapshots & export |
| 53 | `console/RemoteDockerDeploy.tsx` | One-click remote Docker deployment |
| 54 | `console/SettingsView.tsx` | Console-embedded settings |
| 55 | `console/SmokeTestRunner.tsx` | 25-target smoke test runner |
| 56 | `console/StreamDiagnostics.tsx` | LLM provider streaming health tests |
| 57 | `console/TestFrameworkRunner.tsx` | In-app test framework (NAV-16, I18N-03, 21 tabs) |
| 58 | `console/TokenUsageDashboard.tsx` | Token usage analytics |
| 59 | `console/WorkflowOrchestrator.tsx` | DAG workflow execution engine |

---

## 9. UI Base Components (shadcn/Radix)

> 37 components in `/src/app/components/ui/`. Standard shadcn primitives.

| File | Component |
|------|-----------|
| `accordion.tsx` | Accordion |
| `alert-dialog.tsx` | AlertDialog |
| `alert.tsx` | Alert |
| `aspect-ratio.tsx` | AspectRatio |
| `avatar.tsx` | Avatar |
| `badge.tsx` | Badge |
| `breadcrumb.tsx` | Breadcrumb |
| `button.tsx` | Button |
| `calendar.tsx` | Calendar |
| `card.tsx` | Card |
| `carousel.tsx` | Carousel |
| `chart.tsx` | Chart |
| `checkbox.tsx` | Checkbox |
| `collapsible.tsx` | Collapsible |
| `command.tsx` | Command (cmdk) |
| `context-menu.tsx` | ContextMenu |
| `dialog.tsx` | Dialog |
| `drawer.tsx` | Drawer (vaul) |
| `dropdown-menu.tsx` | DropdownMenu |
| `form.tsx` | Form (react-hook-form) |
| `hover-card.tsx` | HoverCard |
| `input-otp.tsx` | InputOTP |
| `input.tsx` | Input |
| `label.tsx` | Label |
| `menubar.tsx` | Menubar |
| `navigation-menu.tsx` | NavigationMenu |
| `pagination.tsx` | Pagination |
| `popover.tsx` | Popover |
| `progress.tsx` | Progress |
| `radio-group.tsx` | RadioGroup |
| `resizable.tsx` | Resizable |
| `scroll-area.tsx` | ScrollArea |
| `select.tsx` | Select |
| `separator.tsx` | Separator |
| `sheet.tsx` | Sheet |
| `sidebar.tsx` | Sidebar |
| `skeleton.tsx` | Skeleton |
| `slider.tsx` | Slider |
| `sonner.tsx` | Sonner (toast) |
| `switch.tsx` | Switch |
| `table.tsx` | Table |
| `tabs.tsx` | Tabs |
| `textarea.tsx` | Textarea |
| `toggle-group.tsx` | ToggleGroup |
| `toggle.tsx` | Toggle |
| `tooltip.tsx` | Tooltip |
| `use-mobile.ts` | useMobile hook |
| `utils.ts` | cn() utility |

### Protected File

- `/src/app/components/figma/ImageWithFallback.tsx` - Platform-provided, **DO NOT MODIFY**.

---

## 10. Core Lib Layer

> Heavy modules forming the intelligence/data/protocol backbone.

| # | File | ~Lines | Role |
|---|------|--------|------|
| 60 | `/src/lib/llm-bridge.ts` | 1048 | 7-provider unified LLM interface. SSE streaming, circuit breaker, failover chain, token tracking, `generalStreamChat()`, `agentStreamChat()`. |
| 61 | `/src/lib/llm-providers.ts` | Large | Provider registry: OpenAI, Anthropic, DeepSeek, Zhipu, Google, Groq, Local (Ollama/LM Studio). Model catalogs, API format definitions, agent route weights. |
| 62 | `/src/lib/llm-router.ts` | Large | Smart LLM router. Health-score routing (0-100), 3-state circuit breaker (CLOSED/OPEN/HALF_OPEN), exponential backoff, concurrent load tracking. |
| 63 | `/src/lib/mcp-protocol.ts` | 1326 | MCP JSON-RPC 2.0 layer. Tool/Resource/Prompt schemas, service registry, connection management, mock runtime for offline. |
| 64 | `/src/lib/agent-orchestrator.ts` | 1427 | Multi-agent collaboration. 5 modes (Pipeline/Parallel/Debate/Ensemble/Delegation), task decomposition, DAG execution, result aggregation, learning loop. |
| 65 | `/src/lib/persistence-engine.ts` | 830 | Full-chain persistence. StorageAdapter interface (Strategy Pattern), LocalStorageAdapter, NasSQLiteAdapter, auto-degradation, versioned snapshots, import/export. |
| 66 | `/src/lib/persistence-binding.ts` | Medium | Zustand <-> PersistenceEngine binding. `usePersistenceSync()` hook, debounced writes, boot hydration, ClusterMetrics archive (30s interval). |
| 67 | `/src/lib/persist-schemas.ts` | 223 | Zod v4 schemas: ChatMessage, ChatSession, AgentHistory, Preferences, SystemLog, KnowledgeEntry, LLMProviderConfig, NodeMetrics, MetricsSnapshot. `validateRecord()`, `validateArray()`, domain validators. |
| 68 | `/src/lib/store.ts` | Large | Zustand v5 global state. Navigation, layout, chat, agent histories, settings, system health, cluster metrics, logs, DAG workflows. |
| 69 | `/src/lib/types.ts` | Large | Centralized type system. SystemStatus, ViewMode, AgentId, AgentRole, AGENT_REGISTRY, ChatMessage, AgentChatMessage, ChatArtifact, PromptTemplate, DAG types, FileAttachment. |
| 70 | `/src/lib/i18n.tsx` | Medium | LanguageProvider (React Context). zh/en translations, `useTranslation()` hook, `t()` key lookup. |
| 71 | `/src/lib/event-bus.ts` | Medium | Five-dimensional event bus. Typed pub/sub, ring buffer (500 events), `useEventBus()` hook, `useSyncExternalStore` integration. |
| 72 | `/src/lib/nas-client.ts` | Medium | NAS HTTP client. Device registry (4 nodes), SQLite proxy, Docker Engine API, network health detection, device config persistence. |
| 73 | `/src/lib/crypto.ts` | Medium | Web Crypto API. AES-GCM 256-bit encryption, PBKDF2 key derivation, device-fixed salt. |
| 74 | `/src/lib/api.ts` | Medium | REST API layer. Auto-degrade to localStorage mock when backend unavailable. |
| 75 | `/src/lib/db-schema.ts` | Medium | PostgreSQL 15 schema definitions (reference, not executed in sandbox). |
| 76 | `/src/lib/agent-identity.ts` | Medium | Agent identity system. Dual identity (Primary + Secondary), presence status, mood state, per-device port mapping. |
| 77 | `/src/lib/utils.ts` | 6 | `cn()` = `twMerge(clsx(...))`. |

---

## 11. Custom Hooks

| # | File | Role |
|---|------|------|
| 78 | `/src/lib/useWebSocket.ts` | Multi-endpoint WebSocket client. Device config discovery, exponential backoff reconnection, fallback to simulation. |
| 79 | `/src/lib/useMetricsSimulator.ts` | Real-time metrics simulation for 4 hardware nodes (M4 Max, iMac M4, MateBook, NAS). |
| 80 | `/src/lib/useOllamaDiscovery.ts` | Ollama local LLM auto-discovery. Probes `/api/tags`, `/api/ps`, auto-registers models. |
| 81 | `/src/lib/useHeartbeatWebSocket.ts` | Family heartbeat WebSocket. Real-time presence stream from NAS relay. |
| 82 | `/src/lib/useNasDiagnostics.ts` | Startup self-diagnostics. SQLite proxy, Docker API, WebSocket, cluster reachability. |

---

## 12. Test Layer

| # | File | Role | Test Count |
|---|------|------|------------|
| 83 | `/src/lib/__tests__/setup.ts` | Vitest setup. localStorage clear before/after each test. | - |
| 84 | `/src/lib/__tests__/persist-schemas.test.ts` | Zod schema validation tests. 13 suites, 44 test cases (ZOD-01 through ZOD-44). | 44 |
| 85 | `/src/lib/__tests__/core-test-suite.ts` | In-app programmatic test suite. `CoreTestRunner.runAll()` for browser console. | 25+ |

---

## 13. Server Files (Reference Only)

> These files are **NOT executed** in the Figma Make sandbox. They exist as deployment references for a separate Express backend.

| # | File | Imports (NOT installed in sandbox) | Role |
|---|------|-----------------------------------|------|
| 86 | `/src/server/index.ts` | `express`, `cors`, `pg`, `ws`, `dotenv` | Express server entry point |
| 87 | `/src/server/routes.ts` | `express`, `pg`, `uuid` | 15 REST API endpoints |
| 88 | `/src/server/ws.ts` | `ws`, `pg`, `http` | WebSocket metrics broadcast |

### Important

These files are excluded from Tailwind scanning via `@source not "../server/**"` in `tailwind.css` (Phase 30 fix).

---

## 14. Manually Edited Files

> These files were hand-edited by the project owner. Assistant must **read current content before modifying**.

| File | What Was Edited |
|------|----------------|
| `/src/lib/__tests__/setup.ts` | Test setup logic |
| `/src/lib/__tests__/persist-schemas.test.ts` | Zod test cases (44 tests) |
| `/src/lib/persist-schemas.ts` | Zod schemas + validators |
| `/docs/execution_summary_v15.md` | Execution summary content |
| `/vitest.config.ts` | Test configuration |
| `/src/main.tsx` | Entry point imports |
| `/src/vite-env.d.ts` | Env type declarations + figma:asset module |
| `/tsconfig.json` | Compiler options |
| `/index.html` | HTML meta + structure |
| `/public/favicon.svg` | Brand icon |
| `/docs/YYC3-AI-Knowledge-Base.md` | AI智能知识库产品规格文档：6大功能模块设计、技术架构、核心特性(智能/高效/便捷/真实)、知识图谱构建 |

---

## 15. Phase 30 Fixes Summary

### Fix 1: Tailwind Source Exclusion

**File**: `/src/styles/tailwind.css`

```css
@import 'tailwindcss' source(none);
@source '../**/*.{js,ts,jsx,tsx}';
@source not "../server/**";          /* <-- ADDED */

@import 'tw-animate-css';
```

**Reason**: `@source '../**/*.{js,ts,jsx,tsx}'` scanned `src/server/` files that import `express`, `pg`, `ws` (not installed in Figma Make sandbox). This caused Tailwind/Vite CSS compilation failures that cascaded as `TypeError: Failed to fetch dynamically imported module`.

### Fix 2: figma:asset Type Declaration

**File**: `/src/vite-env.d.ts`

```typescript
declare module 'figma:asset/*' {
  const src: string;
  export default src;
}
```

**Reason**: `ClaudeWelcome.tsx` imports `figma:asset/bbf3e3fa...png`. Without this declaration, TypeScript cannot resolve the virtual module, potentially disrupting Vite's module graph and causing build errors.

### Previous Fixes (Still Active)

- **`theme.css`**: Removed duplicate `@import "tailwindcss"` (was creating dual Tailwind root)
- **`App.tsx`**: Removed redundant `import "@/styles/theme.css"` (already in CSS chain via index.css)

### Fix 3: ClaudeWelcome figma:asset Elimination (Global Audit)

**File**: `/src/app/components/chat/ClaudeWelcome.tsx`

**Before** (DANGEROUS):
```typescript
import logoImg from "figma:asset/bbf3e3fa0f74d88bf01cb28b236dfeee49fdfab5.png";
// ...
<img src={logoImg} alt="YanYu Cloud" />
```

**After** (SAFE):
```typescript
function YYC3Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 80 80" ...>
      <rect width="80" height="80" rx="16" fill="url(#yyc3-grad)" />
      <text x="40" y="52" ...>Y3</text>
      ...
    </svg>
  );
}
// ...
<YYC3Logo className="w-20 h-20" />
```

**Reason**: `figma:asset/bbf3e3fa...` is a session-specific virtual module. If the asset hash is unavailable, the static import fails at Vite transform time. Since ChatArea statically imports ClaudeWelcome, and App.tsx statically imports ChatArea, this cascades as: `figma:asset fail -> ClaudeWelcome fail -> ChatArea fail -> App.tsx fail -> entire app crash`. The inline SVG has zero external dependencies.

### Fix 4: ErrorBoundary Enhancement (Global Audit)

**File**: `/src/app/App.tsx`

- Added optional `fallback` prop for zone-specific error recovery
- Added `RETRY_MODULE` button (resets error state without page reload)
- Added error message display for debugging
- Original `REBOOT_KERNEL` button retained as secondary action

---

## 16. Global Audit Results (Phase 30 Deep Scan)

### Methodology

Multi-dimensional audit covering:
1. CSS pipeline integrity (import chain, duplicate detection)
2. Module resolution (31 component imports, 21 lazy targets)
3. TypeScript strict compliance (`any` violation scan)
4. Dangerous import detection (`express`, `pg`, `ws`, `react-router-dom`)
5. figma:asset virtual module references
6. Circular dependency analysis
7. Orphan code detection
8. Build config consistency

### Verification Matrix

| Dimension | Items Checked | Status |
|-----------|--------------|--------|
| CSS Pipeline | 4 files, import chain, no duplicate `@import` | PASS |
| Build Config | 7 files, peerDeps, aliases, plugins | PASS |
| Entry Layer | main.tsx, vite-env.d.ts, global.d.ts | PASS |
| App.tsx Lazy Targets | 7 components, named exports verified | PASS |
| ConsoleView Lazy Targets | 14 components, named exports verified | PASS |
| ConsoleView Static Imports | 10 components, named exports verified | PASS |
| Layout/Settings/Search | 3 components, named exports verified | PASS |
| `any` Violations | Full `.ts` + `.tsx` scan | **0 violations** |
| `react-router-dom` Import | Full `.tsx` scan | **0 matches** |
| `express`/`pg`/`ws` in Client | `src/app/` + `src/lib/` scan | **0 matches** |
| `figma:asset` References | Full `.tsx` scan | **0 active** (comments only) |
| Circular Dependencies | Manual import chain analysis | **None detected** |
| Orphan Components | `ClusterTopology.tsx` | 1 (harmless) |

### Component Import Verification (31 total)

**App.tsx Lazy (7):**
`ConsoleView` `ServiceHealthMonitor` `ProjectsView` `ArtifactsView` `ServicesView` `KnowledgeBaseView` `BookmarksView`

**ConsoleView Lazy (14):**
`McpServiceBuilder` `PersistenceManager` `AgentOrchestrator` `AgentIdentityCards` `FamilyPresenceBoard` `KnowledgeBase` `NasDeploymentToolkit` `MetricsHistoryDashboard` `RemoteDockerDeploy` `OllamaManager` `ApiDocsViewer` `SmokeTestRunner` `TestFrameworkRunner` `StreamDiagnostics`

**ConsoleView Static (10):**
`LiveLogStream` `ActivityChart` `DeviceCardManager` `DockerManager` `SettingsView` `DevOpsTerminal` `AgentChatInterface` `DatabaseSelector` `TokenUsageDashboard` `NasDiagnosticsPanel`

All named exports verified via `export function X` pattern matching.

### Orphan Files

| File | Status | Impact |
|------|--------|--------|
| `console/ClusterTopology.tsx` | Exported but never imported | Harmless dead code. Was replaced by `DeviceCardManager` inline usage. |

### Import Chain Safety

```
main.tsx -> @/styles/index.css (CSS only, no TS)
         -> @/app/App.tsx
              -> @/app/components/chat/ChatArea.tsx (STATIC)
              |    -> ./ClaudeWelcome.tsx (STATIC, figma:asset REMOVED)
              |    -> ./MessageBubble.tsx (STATIC)
              -> @/app/components/chat/ArtifactsPanel.tsx (STATIC)
              -> @/app/components/chat/YYC3Background.tsx (STATIC)
              -> @/app/components/layout/Sidebar.tsx (STATIC)
              -> @/app/components/settings/SettingsModal.tsx (STATIC)
              -> @/lib/store.ts -> @/lib/types.ts (ONE-WAY)
              -> @/lib/persistence-binding.ts -> @/lib/store.ts (ONE-WAY)
              |                              -> @/lib/persistence-engine.ts -> @/lib/nas-client.ts
              |                              -> @/lib/event-bus.ts
              |                              -> @/lib/persist-schemas.ts
              -> @/lib/agent-orchestrator.ts (uses globalThis pattern, NO circular dep)
              -> @/lib/llm-bridge.ts -> @/lib/llm-providers.ts
              |                      -> @/lib/llm-router.ts
              -> @/lib/i18n.tsx (STANDALONE)
              -> ConsoleView (LAZY) -> 10 static + 14 lazy sub-components
              -> 6 other views (LAZY)
```

No circular dependency chains detected.

---

## 17. Troubleshooting Checklist

If `TypeError: Failed to fetch dynamically imported module` persists after all fixes:

1. **Verify CSS chain**: `index.css` imports `tailwind.css` (single `@import 'tailwindcss'`), then `theme.css` (NO tailwindcss import). Only ONE Tailwind root.
2. **Verify server exclusion**: `tailwind.css` has `@source not "../server/**"`.
3. **Verify no redundant theme import**: `App.tsx` does NOT import `theme.css` directly.
4. **Verify figma:asset eliminated**: `ClaudeWelcome.tsx` uses inline `YYC3Logo` SVG, NOT `figma:asset` import. Grep for `from "figma:asset` should return zero results.
5. **Check lazy imports**: Each `React.lazy(() => import('...').then(m => ({ default: m.X })))` must match the actual named export of the target module. All 21 verified in Phase 30 audit.
6. **Circular dependency check**: Run `npx madge --circular src/` if available, or manually verify no A->B->A import chains in lib modules. None detected in Phase 30 audit.
7. **Console errors**: Check browser DevTools Network tab for specific 404/500 on chunk files.
8. **ErrorBoundary test**: If a specific view crashes, the ErrorBoundary will show the error message and offer `RETRY_MODULE` (no page reload). Use this to identify which module is failing.

---

*Generated by Phase 30 codebase audit. Last updated: 2026-02-17.*

---

## 18. Phase 31.5 — Deep Integrity Audit (Continuation)

### Scope

Extended verification covering areas not fully explored in Phase 30:
1. Zustand Store completeness (all App.tsx selectors/actions exist)
2. i18n translation key coverage (ClaudeWelcome + ChatArea)
3. Zod v4 API compatibility (safeParse, ZodType, issues)
4. `next-themes` usage analysis (runtime impact assessment)
5. WebSocket & Ollama graceful degradation
6. SettingsModal tab implementations (7 tabs)
7. package.json peerDependencies + dead dependencies
8. Path alias consistency (tsconfig ↔ vite.config)

### Results

| Dimension | Finding | Status |
|-----------|---------|--------|
| **Store Completeness** | All 25 selectors/actions used by App.tsx exist in `useSystemStore` | PASS |
| **i18n Coverage** | `chat.welcome_title`, `welcome_subtitle`, `quick_action_1/2/3` present in both zh+en | PASS |
| **Zod v4 API** | `safeParse` on instances, `ZodType<Output>` exported, `.issues` with `.path`+`.message` | PASS |
| **next-themes** | Only in `sonner.tsx` Toaster — never mounted in app tree, zero runtime calls | PASS (dead code) |
| **WebSocket Degradation** | `onclose`/`onerror` → status=`simulation`, exponential backoff, no crash | PASS |
| **Ollama Degradation** | Failed fetch → `disconnected` status, try/catch guarded | PASS |
| **SettingsModal Tabs** | 7 tabs (general/models/gitops/extensions/security/appearance/agents) all implemented | PASS |
| **peerDependencies** | `react`+`react-dom` in `peerDependencies` (not `dependencies`), `peerDependenciesMeta.optional:true` | PASS |
| **Dead Dependencies** | `@mui/*` installed but unused; `next-themes` used only in dead code Toaster | Low (no runtime impact) |
| **Path Aliases** | `@/` → `./src/*` in both `tsconfig.json` paths + `vite.config.ts` resolve.alias | PASS |

### Dead Code Inventory

| File / Package | Type | Impact |
|----------------|------|--------|
| `console/ClusterTopology.tsx` | Component | Exported never imported. Harmless. |
| `components/ui/sonner.tsx` | Component | Exports `Toaster` never mounted. `next-themes` import never executes. |
| `@mui/material` + peers | npm package | ~30MB installed, zero imports in `src/`. No runtime cost. |
| `react-dnd` + backend | npm package | Installed via platform scaffold. Not imported in current code. |

### Conclusion

**Zero new bugs discovered.** Codebase is production-ready for Figma Make sandbox execution. If `TypeError: Failed to fetch dynamically imported module` persists, the cause is almost certainly a **stale browser cache** of the pre-fix chunk containing the old `figma:asset` import. Solution: hard-refresh (Ctrl+Shift+R) or clear browser cache.

---

*Phase 31.5 deep integrity audit complete. 2026-02-17.*

---

## 19. Knowledge Base — Spec vs Implementation Gap Analysis

### Reference Document

`/docs/YYC3-AI-Knowledge-Base.md` — AI智能知识库产品规格文档（手动编辑），定义6大功能模块、四大核心特性（智能/高效/便捷/真实）、技术架构蓝图。

### Current Two KB Components

| Component | Location | Key Capabilities |
|-----------|----------|-----------------|
| **KnowledgeBaseView** | `views/` | 8 categories, localStorage CRUD, keyword search, sorting, starring |
| **KnowledgeBase** | `console/` | 8 categories, dual-write (localStorage + NAS SQLite), importance, agents, access count, source tracking, Event Bus |

### Coverage Summary

- **Covered**: CRUD, categories, tags, full-text search, NAS persistence, importance, agent linking, source tracking, access analytics, starring
- **Frontend-feasible gaps**: JSON Export/Import, LLM auto-summary (via LLM Bridge), fuzzy search highlighting, tag co-occurrence graph, version history
- **Backend-required gaps**: semantic vector search, OCR/ASR multi-modal, collaborative editing, knowledge graph NER

### Priority Queue (Frontend-Only)

1. JSON Export/Import (Low effort, High impact)
2. LLM Bridge auto-summary (Medium effort, High impact)
3. Fuzzy search with highlighting (Low effort, Medium impact)

---

*Phase 32 Knowledge Base gap analysis complete. 2026-02-17.*