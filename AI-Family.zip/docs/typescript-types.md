# YYC3 Hacker Chatbot - TypeScript Global Type Definitions (Full Catalog)

> **Version**: Phase 25.0 | **Updated**: 2026-02-14
> **Source of Truth**: `/src/lib/types.ts` + module-local types

---

## Table of Contents

1. [Centralized Types (types.ts)](#1-centralized-types)
2. [Store Types (store.ts)](#2-store-types)
3. [API Layer Types (api.ts)](#3-api-layer-types)
4. [LLM Bridge Types (llm-bridge.ts)](#4-llm-bridge-types)
5. [LLM Provider Types (llm-providers.ts)](#5-llm-provider-types)
6. [LLM Router Types (llm-router.ts)](#6-llm-router-types)
7. [NAS Client Types (nas-client.ts)](#7-nas-client-types)
8. [MCP Protocol Types (mcp-protocol.ts)](#8-mcp-protocol-types)
9. [Event Bus Types (event-bus.ts)](#9-event-bus-types)
10. [Persistence Engine Types (persistence-engine.ts)](#10-persistence-engine-types)
11. [Agent Orchestrator Types (agent-orchestrator.ts)](#11-agent-orchestrator-types)
12. [Agent Identity Types (agent-identity.ts)](#12-agent-identity-types)
13. [Type Dependency Graph](#13-type-dependency-graph)
14. [Type Migration Status](#14-type-migration-status)

---

## 1. Centralized Types (`/src/lib/types.ts`)

### 1.1 System-Level Types

```typescript
type SystemStatus = 'optimal' | 'warning' | 'critical' | 'booting';
type ViewMode = 'terminal' | 'console' | 'projects' | 'artifacts' | 'monitor';
type ConsoleTabId =
  | 'dashboard' | 'ai' | 'agent_identity' | 'family_presence'
  | 'knowledge_base' | 'token_usage' | 'architecture' | 'docker'
  | 'devops' | 'mcp' | 'persist' | 'orchestrate' | 'nas_deployment'
  | 'metrics_history' | 'remote_docker_deploy' | 'ollama_manager'
  | 'api_docs' | 'settings' | 'smoke_test';
type Language = 'zh' | 'en';
```

### 1.2 Agent Types

```typescript
type AgentId = 'navigator' | 'thinker' | 'prophet' | 'bole' | 'pivot' | 'sentinel' | 'grandmaster';
type AgentRole = 'architect' | 'coder' | 'auditor' | 'orchestrator';

interface AgentInfo {
  id: AgentId;
  name: string;        // Chinese name
  nameEn: string;      // English name
  role: string;
  desc: string;
  descEn: string;
  icon: string;        // lucide icon name
  color: string;       // Tailwind text color
  bgColor: string;     // Tailwind bg color
  borderColor: string;
}

// Runtime constant: AGENT_REGISTRY: AgentInfo[] (7 entries)
```

### 1.3 Chat & Message Types

```typescript
interface ChatMessage {
  id: string;
  role: 'user' | 'ai';
  content: string;
  timestamp: string;
  agentName?: string;
  agentRole?: AgentRole;
  attachments?: FileAttachment[];
}

interface AgentChatMessage {
  id: string;
  role: 'user' | 'agent' | 'system';
  content: string;
  timestamp: string;
  thinking?: boolean;
}

interface ChatArtifact {
  code: string;
  language: string;
  title: string;
  type?: 'react' | 'text' | 'shell';
}

interface FileAttachment {
  id: string;
  name: string;
  size: number;
  type: string;        // MIME type
  dataUrl?: string;
  content?: string;
}
```

### 1.4 Cluster & Device Types

```typescript
type NodeId = 'm4-max' | 'imac-m4' | 'matebook' | 'yanyucloud';
type DeviceStatus = 'online' | 'offline' | 'standby' | 'unknown';
type ServiceStatus = 'up' | 'down' | 'unknown';
type ServiceProtocol = 'http' | 'https' | 'ssh' | 'ws' | 'tcp';

interface NodeMetricsSnapshot {
  cpu: number;
  memory: number;
  disk: number;
  network: number;
  temperature: number;
  processes: number;
  uptime: number;
}

interface ClusterMetricsSnapshot {
  'm4-max': NodeMetricsSnapshot;
  'imac-m4': NodeMetricsSnapshot;
  'matebook': NodeMetricsSnapshot;
  'yanyucloud': NodeMetricsSnapshot;
  timestamp: number;
}
```

### 1.5 LLM & Provider Types

```typescript
type LLMApiFormat = 'openai' | 'anthropic';
type ProviderId = 'openai' | 'anthropic' | 'deepseek' | 'zhipu' | 'google' | 'groq' | 'ollama' | 'lmstudio';
type LLMErrorCode = 'AUTH_FAILED' | 'RATE_LIMITED' | 'CONTEXT_TOO_LONG' | 'MODEL_NOT_FOUND' | 'NETWORK_ERROR' | 'CORS_ERROR' | 'TIMEOUT' | 'PROVIDER_ERROR' | 'UNKNOWN';
type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';
```

### 1.6 Ollama-Specific Types

```typescript
interface OllamaModelInfo {
  name: string;
  model: string;
  modified_at: string;
  size: number;
  digest: string;
  details: {
    parent_model: string;
    format: string;
    family: string;
    families: string[];
    parameter_size: string;
    quantization_level: string;
  };
}

interface OllamaTagsResponse { models: OllamaModelInfo[]; }
interface OllamaRunningModel { name: string; model: string; size: number; digest: string; expires_at: string; size_vram: number; }
interface OllamaProcessResponse { models: OllamaRunningModel[]; }
type OllamaConnectionStatus = 'connected' | 'disconnected' | 'checking' | 'error';
```

### 1.7 Event Bus Types

```typescript
type EventCategory = 'persist' | 'orchestrate' | 'mcp' | 'system' | 'security' | 'ui';
type EventLevel = 'debug' | 'info' | 'warn' | 'error' | 'success';
```

### 1.8 DevOps Types

```typescript
type DAGNodeType = 'trigger' | 'build' | 'test' | 'security' | 'deploy' | 'notify' | 'approval' | 'script' | 'mcp-tool';
type DAGNodeStatus = 'idle' | 'running' | 'success' | 'failed';

interface LogEntry { id: string; timestamp: string; level: 'info'|'warn'|'error'|'success'; source: string; message: string; }
interface CustomTemplate { id: string; name: string; category: string; desc: string; content: string; createdAt: string; updatedAt: string; isCustom: true; }
interface DAGNode { id: string; type: DAGNodeType; label: string; x: number; y: number; config: Record<string, string>; status?: DAGNodeStatus; }
interface DAGEdge { id: string; source: string; target: string; condition?: string; }
interface DAGWorkflow { id: string; name: string; description: string; nodes: DAGNode[]; edges: DAGEdge[]; createdAt: string; updatedAt: string; }
```

### 1.9 NAS Diagnostics Types

```typescript
type DiagnosticStatus = 'HEALTHY' | 'PARTIAL' | 'DEGRADED' | 'CRITICAL';
interface EndpointDiagnostic { id: string; name: string; url: string; status: 'ok'|'timeout'|'error'|'pending'; latencyMs: number; error?: string; }
```

### 1.10 API Documentation Types

```typescript
interface ApiEndpoint { id: string; method: 'GET'|'POST'|'PUT'|'DELETE'|'PATCH'|'HEAD'; path: string; summary: string; description: string; category: string; requestBody?: { contentType: string; schema: Record<string, unknown>; example: string; }; parameters?: ApiParameter[]; responses: ApiResponse[]; tags: string[]; }
interface ApiParameter { name: string; in: 'query'|'path'|'header'|'body'; required: boolean; type: string; description: string; default?: string; }
interface ApiResponse { status: number; description: string; example?: string; }
```

### 1.11 Prompt Template Types

```typescript
interface PromptTemplate { id: string; icon: string; label: string; labelEn: string; prompt: string; category: 'code'|'devops'|'analysis'|'security'|'creative'|'general'; color: string; }
// Runtime constant: PROMPT_TEMPLATES: PromptTemplate[] (12 entries)
```

### 1.12 File Upload Constants

```typescript
const ACCEPTED_FILE_TYPES: Record<string, string[]>;  // 5 categories
const MAX_FILE_SIZE = 10 * 1024 * 1024;  // 10MB
const MAX_FILES = 10;
```

### 1.13 Utility Type Helpers

```typescript
type RequiredPick<T, K extends keyof T> = Partial<T> & Pick<T, K>;
type Dict<T> = Record<string, T>;
type Nullable<T> = T | null;
```

---

## 2. Store Types (`/src/lib/store.ts`)

```typescript
interface SystemState {
  // Navigation
  activeView: ViewMode;
  consoleTab: string;
  consoleAgent: string | null;
  // Layout
  sidebarCollapsed: boolean;
  sidebarPinned: boolean;
  isMobile: boolean;
  isTablet: boolean;
  // Chat
  messages: ChatMessage[];
  isStreaming: boolean;
  isArtifactsOpen: boolean;
  activeArtifact: ChatArtifact | null;
  // Agent Chat
  agentChatHistories: Record<string, AgentChatMessage[]>;
  // Settings
  isSettingsOpen: boolean;
  settingsTab: string;
  // System Health
  status: SystemStatus;
  latency: number;
  cpuLoad: number;
  clusterMetrics: ClusterMetricsSnapshot | null;
  // Data
  logs: LogEntry[];
  dbConnected: boolean;
  // --- 40+ action methods ---
}
```

**Re-exported from types.ts**: SystemStatus, ViewMode, LogEntry, ChatMessage, ChatArtifact, AgentChatMessage, NodeMetricsSnapshot, ClusterMetricsSnapshot, CustomTemplate, DAGNode, DAGEdge, DAGWorkflow

---

## 3. API Layer Types (`/src/lib/api.ts`)

```typescript
type ConnectionStatus = 'connected' | 'disconnected' | 'checking';

interface DBSession { id: string; title: string; created_at: string; updated_at: string; is_archived: boolean; metadata: Record<string, unknown>; }
interface DBMessage { id: string; session_id: string; role: 'user'|'ai'|'system'; content: string; agent_name?: string; agent_role?: string; timestamp: string; tokens_used: number; }
interface DBAgentSession { id: string; agent_id: string; agent_name: string; created_at: string; updated_at: string; turn_count: number; total_tokens: number; is_active: boolean; }
interface DBAgentMessage { id: string; session_id: string; agent_id: string; role: 'user'|'agent'|'system'; content: string; timestamp: string; thinking_time: number; }
interface DBMetricPoint { id: number; node_id: string; metric_type: string; value: number; unit: string; recorded_at: string; }
interface DBLogEntry { id: number; level: 'info'|'warn'|'error'|'success'|'debug'; source: string; message: string; timestamp: string; }
interface DBArtifact { id: string; title: string; artifact_type: string; language: string; content: string; size_bytes: number; version: string; generated_by?: string; agent_id?: string; tags: string[]; is_starred: boolean; created_at: string; updated_at: string; }
interface DBNode { id: string; display_name: string; node_type: string; hostname: string; cpu_model: string; ram_gb: number; storage_desc: string; os: string; status: string; last_heartbeat: string; }
interface DBProject { id: string; name: string; description: string; project_type: string; language: string; language_color: string; branch: string; status: string; health: string; service_count: number; stars: number; last_commit_at: string; created_at: string; }
```

---

## 4. LLM Bridge Types (`/src/lib/llm-bridge.ts`)

```typescript
interface LLMMessage { role: 'system'|'user'|'assistant'; content: string; }
interface LLMRequestOptions { providerId: string; modelId: string; messages: LLMMessage[]; apiKey: string; endpoint?: string; temperature?: number; maxTokens?: number; stream?: boolean; signal?: AbortSignal; proxyUrl?: string; }
interface LLMResponse { content: string; model: string; provider: string; usage: TokenUsage; finishReason: string; latencyMs: number; }
interface TokenUsage { promptTokens: number; completionTokens: number; totalTokens: number; }
interface StreamChunk { type: 'content'|'done'|'error'; content: string; usage?: TokenUsage; finishReason?: string; }
type StreamCallback = (chunk: StreamChunk) => void;
class LLMError extends Error { code: LLMErrorCode; provider: string; statusCode?: number; retryable: boolean; }
interface LLMResponseWithFailover extends LLMResponse { failover?: FailoverResult; }
interface ProviderHealthResult { providerId: string; status: 'ok'|'error'|'no_key'; latencyMs?: number; error?: string; model?: string; }
interface UsageRecord { date: string; provider: string; model: string; agentId: string; promptTokens: number; completionTokens: number; totalTokens: number; costUsd: number; latencyMs: number; }
interface ProviderConfig { providerId: string; apiKey: string; endpoint: string; enabled: boolean; defaultModel: string; }
```

---

## 5. LLM Provider Types (`/src/lib/llm-providers.ts`)

```typescript
type ApiFormat = 'openai' | 'anthropic';
interface ProviderModel { id: string; name: string; contextWindow: number; maxOutput: number; costPer1kInput?: number; costPer1kOutput?: number; supportsStreaming: boolean; supportsVision?: boolean; supportsTools?: boolean; free?: boolean; }
interface ProviderDefinition { id: string; name: string; displayName: string; apiFormat: ApiFormat; defaultEndpoint: string; authHeaderKey: string; authPrefix: string; models: ProviderModel[]; defaultModel: string; color: string; icon: string; notes?: string; }
interface AgentModelRoute { agentId: string; preferredProviders: string[]; preferredModels: string[]; systemPrompt: string; temperature: number; maxTokens: number; }
```

**Runtime Constants**: `PROVIDERS: Record<string, ProviderDefinition>` (8 providers), `AGENT_ROUTES: Record<string, AgentModelRoute>` (7 agents)

---

## 6. LLM Router Types (`/src/lib/llm-router.ts`)

```typescript
type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';
interface CircuitBreakerConfig { failureThreshold: number; recoveryTimeMs: number; successThreshold: number; monitorWindowMs: number; }
interface FailoverResult { success: boolean; providerId: string; modelId: string; attemptedProviders: { providerId: string; modelId: string; error?: string }[]; failoverCount: number; }
```

---

## 7. NAS Client Types (`/src/lib/nas-client.ts`)

```typescript
interface DeviceConfig { id: string; hostName: string; displayName: string; ip: string; chip: string; cores: string; ram: string; storage: string; os: string; role: string; icon: string; color: string; status: DeviceStatus; lastPing: number; latencyMs: number; services: DeviceService[]; }
interface DeviceService { id: string; name: string; port: number; protocol: ServiceProtocol; path?: string; enabled: boolean; status: ServiceStatus; description: string; }
interface NasSQLiteConfig { host: string; port: number; dbPath: string; }
interface SQLiteQueryResult { columns: string[]; rows: unknown[][]; rowCount: number; changesCount: number; }
interface DockerConfig { host: string; port: number; apiVersion: string; }
interface DockerContainer { Id: string; Names: string[]; Image: string; ImageID: string; Command: string; Created: number; State: string; Status: string; Ports: { IP?: string; PrivatePort: number; PublicPort?: number; Type: string }[]; Labels: Record<string, string>; SizeRw?: number; SizeRootFs?: number; }
interface DockerImage { Id: string; RepoTags: string[]; Created: number; Size: number; VirtualSize: number; }
interface DockerSystemInfo { Containers: number; ContainersRunning: number; ContainersPaused: number; ContainersStopped: number; Images: number; Driver: string; MemTotal: number; NCPU: number; OperatingSystem: string; KernelVersion: string; Architecture: string; ServerVersion: string; Name: string; }
```

---

## 8. MCP Protocol Types (`/src/lib/mcp-protocol.ts`)

```typescript
interface MCPJsonRpcRequest { jsonrpc: '2.0'; id: string|number; method: string; params?: Record<string, unknown>; }
interface MCPJsonRpcResponse { jsonrpc: '2.0'; id: string|number; result?: unknown; error?: { code: number; message: string; data?: unknown }; }
interface MCPToolParameter { name: string; type: 'string'|'number'|'boolean'|'object'|'array'; description: string; required: boolean; default?: unknown; enum?: string[]; }
interface MCPTool { name: string; description: string; inputSchema: { type: 'object'; properties: Record<string, { type: string; description?: string; enum?: string[]; default?: unknown }>; required?: string[] }; annotations?: { title?: string; readOnlyHint?: boolean; destructiveHint?: boolean; idempotentHint?: boolean; openWorldHint?: boolean }; }
interface MCPToolCallRequest { name: string; arguments: Record<string, unknown>; }
interface MCPToolCallResult { content: { type: 'text'|'image'|'resource'; text?: string; data?: string; mimeType?: string; resource?: { uri: string; text?: string; blob?: string } }[]; isError?: boolean; }
interface MCPResource { uri: string; name: string; description?: string; mimeType?: string; annotations?: { audience?: string[]; priority?: number }; }
interface MCPResourceTemplate { uriTemplate: string; name: string; description?: string; mimeType?: string; }
interface MCPResourceContent { uri: string; mimeType?: string; text?: string; blob?: string; }
interface MCPPrompt { name: string; description?: string; arguments?: { name: string; description?: string; required?: boolean }[]; }
interface MCPPromptMessage { role: 'user'|'assistant'; content: { type: 'text'|'image'|'resource'; text?: string; data?: string; mimeType?: string; resource?: { uri: string; text?: string } }; }
type MCPTransport = 'stdio' | 'http-sse' | 'streamable-http';
interface MCPServerDefinition { id: string; name: string; version: string; description: string; transport: MCPTransport; command?: string; args?: string[]; env?: Record<string, string>; url?: string; capabilities: { tools: boolean; resources: boolean; prompts: boolean; logging: boolean; sampling: boolean }; tools: MCPTool[]; resources: MCPResource[]; resourceTemplates: MCPResourceTemplate[]; prompts: MCPPrompt[]; status: 'connected'|'disconnected'|'error'|'initializing'; lastConnected?: number; error?: string; category: 'builtin'|'community'|'custom'; tags: string[]; icon?: string; color?: string; createdAt: string; updatedAt: string; }
interface MCPCallPreset { id: string; name: string; description: string; method: string; paramsTemplate: Record<string, unknown>; exampleResponse: unknown; category: 'lifecycle'|'tools'|'resources'|'prompts'|'utilities'; }
interface MCPCallResult { success: boolean; method: string; serverId: string; latencyMs: number; response: MCPJsonRpcResponse; timestamp: number; }
```

---

## 9. Event Bus Types (`/src/lib/event-bus.ts`)

```typescript
interface BusEvent { id: string; timestamp: string; category: EventCategory; type: string; level: EventLevel; source: string; message: string; metadata?: Record<string, unknown>; }
type EventSubscriber = (event: BusEvent) => void;
type EventFilter = { category?: EventCategory|EventCategory[]; level?: EventLevel|EventLevel[]; type?: string|RegExp; };
```

---

## 10. Persistence Engine Types (`/src/lib/persistence-engine.ts`)

```typescript
type PersistDomain = 'chat_sessions' | 'chat_messages' | 'agent_sessions' | 'agent_messages' | 'metrics_snapshots' | 'system_logs' | 'workflows' | 'templates' | 'artifacts' | 'mcp_registry' | 'mcp_call_log' | 'device_configs' | 'llm_configs' | 'llm_usage' | 'preferences' | 'knowledge_base' | 'agent_profiles';

interface PersistRecord { id: string; domain: PersistDomain; data: unknown; version: number; createdAt: string; updatedAt: string; synced: boolean; }
interface PersistSnapshot { id: string; timestamp: string; domains: PersistDomain[]; data: Record<PersistDomain, unknown[]>; metadata: Record<string, unknown>; }
```

---

## 11. Agent Orchestrator Types (`/src/lib/agent-orchestrator.ts`)

```typescript
type CollaborationMode = 'pipeline' | 'parallel' | 'debate' | 'ensemble' | 'delegation';
type AgentRole = 'lead' | 'contributor' | 'reviewer' | 'judge' | 'observer';
type TaskStatus = 'pending' | 'decomposing' | 'assigning' | 'executing' | 'reviewing' | 'consensus' | 'completed' | 'failed' | 'human_review';
type AgentExecutionStatus = 'idle' | 'thinking' | 'executing' | 'done' | 'error';
```

---

## 12. Agent Identity Types (`/src/lib/agent-identity.ts`)

```typescript
type PresenceStatus = 'online' | 'idle' | 'busy' | 'away' | 'offline';
type MoodState = 'focused' | 'creative' | 'calm' | 'alert' | 'resting';

interface AgentIdentity { title: string; subtitle: string; description: string; expertise: string[]; mood: MoodState; }
interface AgentProfile { agentId: string; primary: AgentIdentity; secondary: AgentIdentity; tertiary?: AgentIdentity; presence: PresenceStatus; lastSeen: string; heartbeatCount: number; signalMessage: string; activeIdentity: 'primary'|'secondary'|'tertiary'; createdAt: string; updatedAt: string; }
interface DeviceMemberProfile { deviceId: string; /* ... */ }
```

---

## 13. Type Dependency Graph

```
types.ts (Source of Truth)
  |
  +-- store.ts (imports + re-exports 12 types)
  |     |
  |     +-- App.tsx
  |     +-- ConsoleView.tsx
  |     +-- AgentChatInterface.tsx
  |     +-- McpWorkflowsView.tsx
  |     +-- WorkflowOrchestrator.tsx
  |     +-- SmokeTestRunner.tsx
  |     +-- PersistenceManager.tsx
  |     +-- LiveLogStream.tsx
  |
  +-- llm-bridge.ts (imports LLMErrorCode from types.ts indirectly)
  |     +-- llm-router.ts (imports LLMErrorCode)
  |     +-- llm-providers.ts (standalone, defines ProviderDefinition)
  |
  +-- nas-client.ts (standalone, uses DeviceStatus/ServiceStatus/ServiceProtocol concepts)
  +-- mcp-protocol.ts (standalone, full MCP type system)
  +-- event-bus.ts (duplicates EventCategory/EventLevel from types.ts)
  +-- persistence-engine.ts (imports from nas-client.ts)
  +-- agent-orchestrator.ts (standalone)
  +-- agent-identity.ts (standalone)
  +-- api.ts (standalone DB types)
```

---

## 14. Type Migration Status (Phase 24)

| Type | Original Location | Current Location | Migration Status |
|------|-------------------|------------------|-----------------|
| `SystemStatus` | store.ts | types.ts | Migrated, re-exported |
| `ViewMode` | store.ts | types.ts | Migrated, re-exported |
| `LogEntry` | store.ts (missing) | types.ts | Created, imported |
| `ChatMessage` | store.ts | types.ts | Migrated, re-exported |
| `ChatArtifact` | store.ts | types.ts | Migrated, re-exported |
| `AgentChatMessage` | store.ts | types.ts | Migrated, re-exported |
| `NodeMetricsSnapshot` | store.ts | types.ts | Migrated, re-exported |
| `ClusterMetricsSnapshot` | store.ts | types.ts | Migrated, re-exported |
| `CustomTemplate` | store.ts (missing) | types.ts | Created, imported |
| `DAGNode` | store.ts (missing) | types.ts | Created, imported |
| `DAGEdge` | store.ts (missing) | types.ts | Created, imported |
| `DAGWorkflow` | store.ts (missing) | types.ts | Created, imported |
| `EventCategory` | types.ts + event-bus.ts | Both (duplicate) | Needs dedup |
| `EventLevel` | types.ts + event-bus.ts | Both (duplicate) | Needs dedup |
| `CircuitState` | types.ts + llm-router.ts | Both (duplicate) | Needs dedup |
| `LLMErrorCode` | types.ts + llm-bridge.ts | Both (duplicate) | Needs dedup |
| `AgentRole` | types.ts + agent-orchestrator.ts | Both (different definitions!) | Conflict |

### Known Type Issues

1. **`AgentRole` conflict**: `types.ts` defines `'architect'|'coder'|'auditor'|'orchestrator'`, `agent-orchestrator.ts` defines `'lead'|'contributor'|'reviewer'|'judge'|'observer'`. These are different concepts and should be renamed.
2. **`EventCategory`/`EventLevel` duplication**: Defined in both `types.ts` and `event-bus.ts` with identical values.
3. **`CircuitState` duplication**: Defined in both `types.ts` and `llm-router.ts`.
4. **`LLMErrorCode` duplication**: Defined in both `types.ts` and `llm-bridge.ts`.

---

> **YYC3 Hacker Chatbot** - TypeScript Types Catalog v25.0
> Total Types: 80+ interfaces, 30+ type aliases, 5+ enums/constants
