# YYC3 Hacker Chatbot - Operations Guide
## Phase 22 Infrastructure Operations Manual

> 万象归元于云枢; 深栈智启新纪元

---

## 1. Environment Setup

### 1.1 Required Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
```

Key variables:
- `VITE_NAS_HOST` - NAS IP address (default: `192.168.3.45`)
- `VITE_DOCKER_API_PORT` - Docker Engine API port (default: `2375`)
- `VITE_SQLITE_PROXY_PORT` - SQLite HTTP Proxy port (default: `8484`)
- `VITE_HEARTBEAT_WS_PORT` - Heartbeat WebSocket port (default: `9090`)

### 1.2 Network Prerequisites

Ensure the following network connectivity from your development machine:

| Service | Host | Port | Protocol |
|---------|------|------|----------|
| NAS TOS Web UI | 192.168.3.45 | 9898 | HTTPS |
| Docker Engine API | 192.168.3.45 | 2375 | HTTP |
| SQLite HTTP Proxy | 192.168.3.45 | 8484 | HTTP |
| Heartbeat WebSocket | 192.168.3.45 | 9090 | WS |
| Ollama (M4 Max) | 192.168.3.22 | 11434 | HTTP |

---

## 2. NAS Auto-Diagnostics (Phase 22)

### Overview
The NAS Auto-Diagnostics system runs automatically when the Console Dashboard loads. It checks:

1. **NAS SQLite HTTP Proxy** - Tests `http://192.168.3.45:8484/api/db/query`
2. **Docker Engine API** - Tests `http://192.168.3.45:2375/v1.41/_ping`
3. **Heartbeat WebSocket** - Tests `ws://192.168.3.45:9090/ws/heartbeat`
4. **Device Cluster** - Pings all 4 devices (M4 Max, iMac, MateBook, NAS)

### Interpreting Results

| Status | Meaning | Action |
|--------|---------|--------|
| HEALTHY | All 7 checks pass | No action needed |
| PARTIAL | Some checks warn | Non-critical; deploy missing services |
| DEGRADED | Some checks fail | Core services may be offline |
| CRITICAL | Most checks fail | Network issue or NAS offline |

### Manual Re-scan
Click the "Re-scan" button in the diagnostics panel to re-run all checks.

---

## 3. Metrics History Dashboard (Phase 22)

### Data Source
Metrics are automatically archived every 30 seconds by the `persistence-binding.ts` module. Archives are stored in `localStorage` under the `yyc3-persist-metrics_snapshots` key.

### Rolling Window
- Maximum 100 snapshots are retained (configurable in `persistence-binding.ts`)
- At 30-second intervals, this covers approximately 50 minutes of history

### Supported Metrics
- **CPU Usage** - Per-node CPU utilization percentage
- **Memory Usage** - Per-node memory utilization percentage
- **Disk Usage** - Per-node disk utilization percentage
- **Network I/O** - Per-node network throughput (Mbps)
- **Temperature** - Per-node system temperature

### Chart Controls
- **Metric Selector** - Switch between CPU/Memory/Disk/Network/Temperature
- **Time Range** - Filter by 30min / 1hour / 6hours / All
- **Chart Type** - Toggle between Area and Line charts
- **Node Filter** - Enable/disable individual nodes on the chart
- **Export** - Download current chart data as JSON

---

## 4. Remote Docker Deployment (Phase 22)

### Prerequisites
1. Docker Engine API must be accessible at `http://192.168.3.45:2375`
2. The Docker API must have remote access enabled (no TLS in local network)
3. Required images should be either available locally on NAS or pullable from Docker Hub

### Available Service Templates

| Service | Image | Port | Description |
|---------|-------|------|-------------|
| Heartbeat WS | `node:20-alpine` | 9090 | Family presence heartbeat relay |
| SQLite Proxy | `yyc3/sqlite-http:latest` | 8484 | SQLite over HTTP API |
| Redis Cache | `redis:7-alpine` | 6379 | Key-value cache |
| MCP Server | `python:3.12-slim` | 8080 | MCP tool execution server |

### Deployment Workflow
1. Navigate to Console > Remote Deploy (cloud icon)
2. Click "Deploy" on the desired service template
3. The system will:
   - Pull the Docker image (if not cached)
   - Create the container with configured ports, volumes, and environment
   - Start the container
   - Verify the container is running
4. Check the deployment log for status updates

### Volume Requirements
Before deploying, ensure these directories exist on the NAS:

```bash
ssh root@192.168.3.45
mkdir -p /Volume2/yyc3/heartbeat
mkdir -p /Volume2/yyc3/data
mkdir -p /Volume2/yyc3/redis-data
mkdir -p /Volume2/yyc3/mcp-server
```

### Heartbeat Server Deployment (Manual)
If the one-click deploy fails for the heartbeat service, deploy manually:

```bash
# 1. Copy the server file to NAS
scp heartbeat-server.js root@192.168.3.45:/Volume2/yyc3/heartbeat/

# 2. SSH into NAS
ssh root@192.168.3.45

# 3. Navigate and start
cd /Volume2/yyc3/heartbeat
docker run -d --name yyc3-heartbeat-ws \
  --restart unless-stopped \
  -p 9090:9090 \
  -v $(pwd)/heartbeat-server.js:/app/server.js:ro \
  -w /app \
  node:20-alpine node server.js
```

---

## 5. NAS SQLite Table Setup

### Tables Required

Two tables need to be created on the NAS SQLite database:

#### knowledge_base
```sql
CREATE TABLE IF NOT EXISTS knowledge_base (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  summary TEXT,
  category TEXT NOT NULL DEFAULT 'general',
  tags TEXT,
  linked_agents TEXT,
  source TEXT,
  importance TEXT DEFAULT 'medium',
  access_count INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_kb_category ON knowledge_base(category);
CREATE INDEX IF NOT EXISTS idx_kb_importance ON knowledge_base(importance);
```

#### agent_profiles
```sql
CREATE TABLE IF NOT EXISTS agent_profiles (
  agent_id TEXT PRIMARY KEY,
  data TEXT NOT NULL,
  presence TEXT DEFAULT 'offline',
  heartbeat_count INTEGER DEFAULT 0,
  last_seen TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
```

### Automated Setup
Use the NAS Deployment Toolkit (Console > NAS Deploy) > NAS SQLite Table Manager to execute these SQL statements with one click.

---

## 6. Device Cluster Configuration

### Device Registry

| Device | IP | Role | Key Services |
|--------|-----|------|-------------|
| MacBook Pro M4 Max | 192.168.3.22 | Orchestrator | Ollama, Dev Server |
| iMac M4 | 192.168.3.77 | Visual/Auxiliary | SSH, Ollama |
| MateBook X Pro | 192.168.3.66 | Edge/Test | RDP |
| TerraMaster F4-423 | 192.168.3.45 | Data Center | Docker, SQLite, WebSocket, SMB |

### Editing Device Configuration
Device IPs and service ports can be modified through the Console UI. Changes are persisted to `localStorage` under `yyc3-device-configs`.

---

## 7. LLM Provider Configuration

### Supported Providers (8 registered)
1. OpenAI (GPT-4o, GPT-4-turbo)
2. Anthropic (Claude 3.5 Sonnet, Claude 3 Opus)
3. Google (Gemini 1.5 Pro, Gemini 1.5 Flash)
4. DeepSeek (DeepSeek-V3, DeepSeek-R1)
5. Ollama Local (llama3.2, qwen2.5, deepseek-r1)
6. LM Studio (via OpenAI-compatible API)
7. Groq (mixtral-8x7b, llama-3.3-70b)
8. OpenRouter (meta-llama, mistral)

### API Key Storage
API keys are encrypted using AES-GCM before storage in `localStorage`. Keys are stored under `yyc3-llm-api-keys`.

### Failover Chain
The system implements automatic failover: if the primary provider fails, it cascades to the next provider in the configured chain.

---

## 8. Persistence Architecture

### Storage Strategy Options
- **local-only** - localStorage only (offline-first, no sync)
- **nas-primary** - Always write to NAS, localStorage as backup
- **dual-write** - Write to both localStorage and NAS simultaneously
- **auto** - Detect NAS availability, dual-write if online

### Data Domains (16 total)
`chat_sessions`, `chat_messages`, `agent_sessions`, `agent_messages`,
`metrics_snapshots`, `system_logs`, `workflows`, `templates`,
`artifacts`, `mcp_registry`, `mcp_call_log`, `device_configs`,
`llm_configs`, `llm_usage`, `knowledge_base`, `agent_profiles`

### Snapshot System
- Create snapshots via Persistence Manager (Console > Persistence)
- Last 10 snapshots are retained
- Export/Import via JSON for backup

---

## 9. Troubleshooting

### NAS Unreachable
1. Check if NAS is powered on and connected to LAN
2. Verify IP address: `ping 192.168.3.45`
3. Check TOS Web UI: `https://192.168.3.45:9898`
4. If IP changed, update device configs in Console

### Docker API Not Responding
1. Ensure Docker service is running on NAS: `systemctl status docker`
2. Check Docker daemon is listening on TCP: `curl http://192.168.3.45:2375/v1.41/_ping`
3. Verify port 2375 is not blocked by firewall

### SQLite Proxy Not Responding
1. Check if sqlite-proxy container is running: `docker ps | grep sqlite`
2. Restart container: `docker restart yyc3-sqlite-proxy`
3. Verify database file exists: `ls -la /Volume2/yyc3/yyc3.db`

### Metrics Not Archiving
1. Ensure the dashboard is active (metrics archive requires `usePersistenceSync` to be mounted)
2. Check `localStorage` for `yyc3-persist-metrics_snapshots` key
3. Clear old data if localStorage quota exceeded

---

## 10. Phase Summary

| Phase | Content | Status |
|-------|---------|--------|
| 1-14 | Core infrastructure, LLM, encryption, agents | Complete |
| 15-16 | NAS client, Docker API, device cards, MCP | Complete |
| 17 | Persistence engine, orchestrator, dual-engine LLM | Complete |
| 18 | Event bus, persistence binding, metrics archive | Complete |
| 19 | Agent identity, family presence, knowledge base | Complete |
| 20 | KB/Agent persistence, heartbeat WS hook | Complete |
| 21 | NAS Deployment Toolkit, connectivity matrix | Complete |
| 22 | Auto-diagnostics, metrics history, remote deploy | Complete |

---

*Last updated: 2026-02-14 | Phase 22 Release*
