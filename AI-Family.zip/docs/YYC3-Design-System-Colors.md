# YYC3 Design System - 1.1 Color System (色彩系统)

## 🎨 Overview
The Color System is the foundational layer of the YYC3 user interface, designed to embody the "Professional & Reliable" brand identity while supporting the "Five Highs" (High Availability, Performance, Security, Maintainability, Extensibility).

## 🌈 Global Palette (全局色板)

### 🔵 Primary (品牌主色)
*Symbolizes Professionalism & Reliability*
*   **Token**: `primary` / `brand-900`
*   **Hex**: `#1a365d`
*   **Usage**: Primary Buttons, Headers, Key Branding Elements.

### 🔵 Secondary / Interaction (交互/辅助色)
*Symbolizes Technology & Agility*
*   **Token**: `secondary` / `brand-500`
*   **Hex**: `#3182ce`
*   **Usage**: Links, Active States, Focus Rings, Secondary Buttons.

### 🟢 Functional: Success (成功状态)
*Symbolizes Health & Stability*
*   **Token**: `success` / `success-500`
*   **Hex**: `#38a169`
*   **Usage**: Success Toasts, Online Indicators, Validated Inputs.

### 🔴 Functional: Error (错误状态)
*Symbolizes Alert & Criticality*
*   **Token**: `destructive` / `error-500`
*   **Hex**: `#e53e3e`
*   **Usage**: Error Messages, Destructive Actions, Critical Alerts.

### ⚪ Neutrals (中性色系)
*Used for Text, Borders, and Surfaces*
*   **Text (Primary)**: `#1a365d` (Light Mode) / `#cbd5e0` (Dark Mode)
*   **Text (Secondary)**: `#718096`
*   **Borders**: `#cbd5e0` (Light) / `#2d3748` (Dark)
*   **Backgrounds**: `#f7fafc` (Light) / `#050505` (Dark)

## 🌗 Theme Strategy (主题策略)

The system uses CSS Variables (Custom Properties) to support instant, flicker-free theme switching.

| Token | Light Mode Value | Dark Mode Value |
| :--- | :--- | :--- |
| `--background` | `#f7fafc` (Ice White) | `#050505` (Cyber Black) |
| `--foreground` | `#1a365d` (Deep Blue) | `#cbd5e0` (Soft Gray) |
| `--primary` | `#1a365d` (Deep Blue) | `#3182ce` (Tech Blue) |
| `--border` | `#cbd5e0` (Gray 300) | `#2d3748` (Gray 800) |

## ♿ Accessibility (无障碍标准)
*   **WCAG 2.1 AA**: All text pairings (Background vs Foreground) achieve a contrast ratio of at least 4.5:1.
*   **Color Independence**: Color is never used as the only visual cue for conveying information (icons or text labels always accompany status colors).

---
*System Version: 1.0.0 | Updated: 2026-02-08*
