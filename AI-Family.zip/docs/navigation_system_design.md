# YYC3 Navigation System Design - The "Five-Level Autonomous Unit"

## 🧭 Overview
The YYC3 platform employs a **Five-Level Autonomous Unit Navigation System** designed to handle the complexity of the Nine-Layer Architecture while maintaining user clarity and operational efficiency. This design aligns with the "Five Highs" (Availability, Performance, Security, Maintainability, Extensibility).

## 🏗️ Navigation Hierarchy

### Level 1: Global Context (The "Macro" View)
*   **Location**: Vertical Left Sidebar (Fixed).
*   **Purpose**: High-level domain switching.
*   **Items**:
    *   🏠 **Home**: Platform overview.
    *   📊 **Dashboard**: Personalized operational view.
    *   🧠 **AI Intelligence**: Layer-04 context.
    *   💼 **Business Services**: Layer-05 context.
    *   🗄️ **Data Management**: Layer-02 context.
    *   ⚙️ **System**: Layer-01/09 context.
    *   🔧 **Settings**: User preferences.

### Level 2: Functional Perspective (The "Meso" View)
*   **Location**: Horizontal Top Bar.
*   **Purpose**: Tool-specific views within the selected global context.
*   **Items**:
    *   📐 **Architecture**: Structural topology view.
    *   🔍 **Search**: Global resource finder.
    *   📚 **Docs**: Knowledge base access.
    *   🧪 **Testing**: CI/CD pipelines.
    *   📈 **Monitoring**: Real-time observability.
    *   🔐 **Security**: RBAC and audit.
    *   📊 **Analytics**: Business intelligence.

### Level 3: Architectural Layering (The "Micro" View)
*   **Location**: Collapsible/Contextual Sidebar (Inner Left).
*   **Purpose**: Navigating the specific strata of the Nine-Layer Architecture.
*   **Items**:
    *   **L09 System Settings**
    *   **L08 Extension & Evo**
    *   **L07 User Interaction**
    *   **L06 App Presentation**
    *   **L05 Business Logic**
    *   **L04 AI Intelligence**
    *   **L03 Core Services**
    *   **L02 Data Storage**
    *   **L01 Infrastructure**

### Level 4: Resource Units (The "Nano" View)
*   *Implementation Note: Contextual to the main content area.*
*   **Purpose**: Selecting specific instances (e.g., "Agent: Navigator", "Pod: redis-master-0").

### Level 5: Detail Properties (The "Pico" View)
*   *Implementation Note: Tabs/Panels within a resource card.*
*   **Purpose**: Viewing specific attributes (e.g., "Logs", "Metrics", "Config", "YAML").

## 🎨 UX Design Principles (The "Five Modernizations")
1.  **Immersive**: Glassmorphism, neon accents, and dark mode for a "Cyberpunk Console" feel.
2.  **Responsive**: Collapsible sidebars and touch-friendly targets.
3.  **Context-Aware**: Level 3 navigation only appears when "Architecture" view is active.
4.  **Performant**: Instant state switching without full page reloads.
5.  **Visualized**: Use of icons and color coding (Amber for AI, Cyan for UI, etc.) to reinforce mental models.

---
*Document Version: 1.0 | Status: Implemented (L1-L3)*
