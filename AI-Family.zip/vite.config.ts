import { defineConfig } from 'vite'
import path from 'path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({mode}) => ({
  plugins: [
    // The React and Tailwind plugins are both required for Make, even if
    // Tailwind is not being actively used – do not remove them
    react(),
    tailwindcss(),
  ],
  resolve: {
    alias: {
      // Alias @ to the src directory
      '@': path.resolve(__dirname, './src'),
    },
  },

  // File types to support raw imports. Never add .css, .tsx, or .ts files to this.
  assetsInclude: ['**/*.svg', '**/*.csv'],

  // ============================================================
  // Phase 34: Dev-mode CORS Proxy for Cloud LLM Providers
  // ============================================================
  // When running `vite dev` locally, browser fetch() to cloud APIs
  // (OpenAI, DeepSeek, Anthropic, etc.) is blocked by CORS.
  // These proxy rules transparently forward /api/proxy/<provider>/*
  // to the real cloud endpoint, bypassing CORS in development.
  //
  // In production builds the proxy is inactive — the app either
  // uses Ollama (local, no CORS) or a self-hosted API relay on NAS.
  // ============================================================
  server: mode === 'development' ? {
    proxy: {
      // OpenAI  →  https://api.openai.com/v1/*
      '/api/proxy/openai': {
        target: 'https://api.openai.com',
        changeOrigin: true,
        rewrite: (p: string) => p.replace(/^\/api\/proxy\/openai/, '/v1'),
        secure: true,
      },
      // DeepSeek  →  https://api.deepseek.com/v1/*
      '/api/proxy/deepseek': {
        target: 'https://api.deepseek.com',
        changeOrigin: true,
        rewrite: (p: string) => p.replace(/^\/api\/proxy\/deepseek/, '/v1'),
        secure: true,
      },
      // Anthropic  →  https://api.anthropic.com/v1/*
      '/api/proxy/anthropic': {
        target: 'https://api.anthropic.com',
        changeOrigin: true,
        rewrite: (p: string) => p.replace(/^\/api\/proxy\/anthropic/, '/v1'),
        secure: true,
      },
      // Zhipu (智谱)  →  https://open.bigmodel.cn/api/paas/v4/*
      '/api/proxy/zhipu': {
        target: 'https://open.bigmodel.cn',
        changeOrigin: true,
        rewrite: (p: string) => p.replace(/^\/api\/proxy\/zhipu/, '/api/paas/v4'),
        secure: true,
      },
      // Google Gemini  →  https://generativelanguage.googleapis.com/v1beta/openai/*
      '/api/proxy/gemini': {
        target: 'https://generativelanguage.googleapis.com',
        changeOrigin: true,
        rewrite: (p: string) => p.replace(/^\/api\/proxy\/gemini/, '/v1beta/openai'),
        secure: true,
      },
      // Groq  →  https://api.groq.com/openai/v1/*
      '/api/proxy/groq': {
        target: 'https://api.groq.com',
        changeOrigin: true,
        rewrite: (p: string) => p.replace(/^\/api\/proxy\/groq/, '/openai/v1'),
        secure: true,
      },
    },
  } : undefined,
}))