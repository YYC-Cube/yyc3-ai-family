**YYC3 π³ Chatbot Guidelines**
<!--
📊 项目概况

维度 状态 说明 

项目名称  yyc3-hacker-chatbot         版本 0.33.0 

技术栈   React18+TypeScript+Vite6    Zustand 状态管理

组件数量   93 个 TSX 组件             49 个使用 React Hooks

测试覆盖   1 个     测试文件    覆盖率严重不足 
// ... existing code ...

## ✅ 已修复问题
### 问题 1: MCP 协议实现不完整 — Phase 47 已修复 ✅
位置 : mcp-protocol.ts
修复内容 :
- executeMCPCall tools/call: 不再返回 `[Mock] Tool "X" executed...` 通用占位
- 新增 executeToolViaInfra(): 通过 nas-client/pg-telemetry-client 真实执行工具
- 新增 _toolMock(): 为每个工具返回结构化 JSON mock 数据(集群状态/Docker/SQL/文件等)
- 新增 _resourceMock(): resources/read 返回真实结构化资源数据
- generateMCPServerCode(): 生成 Node.js 真实实现代码(fs/pg/Docker API/GitHub)而非 TODO 占位
- prompts/get: 返回有意义的提示词模板而非 [Mock] 前缀

### 问题 2: 测试覆盖率严重不足 — Phase 48 已修复 ✅
位置 : src/lib/__tests__/
修复内容 :
- store.test.ts: 44 个测试用例，覆盖 Zustand Store 全部 actions（导航/布局/聊天/Agent 历史/设置/系统/复合操作）
- llm-bridge.test.ts: 20 个测试用例，覆盖 Provider 配置持久化、hasConfiguredProvider、getEnabledProviderIds、LLMError 类、Usage 追踪与汇总
- persistence-engine.test.ts: 36 个测试用例，覆盖 LocalStorageAdapter CRUD、PersistenceEngine 读写/事件系统/快照/导入导出/配置管理
- nas-client.test.ts: 24 个测试用例，覆盖 DEFAULT_DEVICES 注册表、设备/SQLite/Docker 配置持久化、Mock 数据完整性
- mcp-protocol.test.ts: 47 个测试用例，覆盖 Server Presets/Tool Schema/Registry CRUD/executeMCPCall 全方法/Rich Mock 数据/代码生成/调用日志

### 问题 3: Agent 聊天响应模板化 — Phase 49 已修复 ✅
位置 : AgentChatInterface.tsx
修复内容 :
- agentStreamChat() 已集成: LLM 流式响应为首选路径，模板仅作离线降级回退
- 新增 LLM 配置引导横幅: llmMode='template' 时显示醒目提示，一键跳转 Settings > Models
- 新增模板消息标签: 回退生成的消息显示 [TEMPLATE] 标识，与真实 AI 响应区分
- 新增 LLM 错误追踪: lastLlmError 状态记录失败原因，底栏显示 LLM_FALLBACK 指示
- 状态文本修正: 底栏从误导性的 "NEURAL_LINK: ACTIVE" 改为 "TEMPLATE_MODE"
- 模式指示灯修正: template 模式下由绿色改为琥珀色，视觉上区分两种工作模式

## 🔴 关键问题（需立即修复）

（暂无 P0 级问题）

🚨## 警告问题（建议优化）
### 警告 1: NAS 连接降级策略不明确 — Phase 50 已修复 ✅
位置 : persistence-engine.ts
修复内容 :
- 新增 MAX_SYNC_QUEUE_SIZE = 1000 常量，队列超限时自动淘汰最旧条目
- 新增 enqueue() 私有方法，替代直接 push，统一队列管理入口
- 新增 scheduleRetry() 指数退避重试机制 (1s → 2s → 4s → ... → 60s max)
- 新增 getSyncStatus() 方法，返回 NAS 状态/待同步数/重试计数/溢出数等综合信息
- 新增 queue-overflow 事件类型，队列溢出时通知 UI 层
- ConsoleView.tsx 头部新增 NAS 同步状态指示器 (NAS:OK / NAS:OFF / Q:N / SYNC:N)

### 警告 2: 响应式设计未完全覆盖
位置 : ConsoleView.tsx:120-130

现状 : 移动端导航栏压缩，部分控制台面板已有基础适配（isMobile 判断），后续可进一步优化

建议 :

- 为复杂面板添加移动端专用视图
- 实现触摸手势支持
- 优化小屏幕下的表格和图表展示

### 警告 3: 错误边界处理不完整 — Phase 50 已修复 ✅
位置 : App.tsx + ConsoleView.tsx
修复内容 :
- ComponentErrorBoundary.tsx 已于 Phase 50 初期创建（赛博朋克风格，支持 Retry/Stack Trace/Compact 模式）
- ConsoleView.tsx: 6 个关键面板已包裹 ComponentErrorBoundary（AgentChat/DevOps/TokenUsage/Docker/MCP/StreamDiagnostics/HardwareMonitor）
- App.tsx: 7 个主视图已包裹 ComponentErrorBoundary（Console/Monitor/Projects/Artifacts/Services/Knowledge/Bookmarks）
- 所有 onError 回调均记录至 Zustand addLog / console.error，便于追踪

✅ P0 MCP 工具实现 Phase 47 已完成 ✅
✅ P1 测试覆盖率提升 Phase 48 已完成 ✅ (6 个测试文件, 171+ 测试用例)
✅ P0 Agent 真实 LLM 集成 Phase 49 已完成 ✅
✅ P1 NAS 同步队列优化 Phase 50 已完成 ✅ (队列上限+指数退避+UI指示器)
✅ P2 错误边界细化 Phase 50 已完成 ✅ (13+ 组件包裹局部错误恢复)
🟢 P2 移动端适配完善 6h 用户体验
-->