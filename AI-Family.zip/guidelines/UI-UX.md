# Family-π³ 前端 UI/UX 改进任务

## 当前状态
项目已实现九层架构和七大智能体，但存在以下 UI/UX 改进点：

## 任务清单

### 1. Agent 聊天界面优化
- 当前：AgentChatInterface 使用模板响应
- 目标：集成真实 LLM 流式响应，添加打字机效果
- 文件：src/app/components/console/AgentChatInterface.tsx
- 参考：src/lib/llm-bridge.ts 的 agentStreamChat()

### 2. 同步状态可视化
- 当前：NAS 同步状态仅在控制台显示
- 目标：添加全局同步指示器（顶部状态栏）
- 显示：待同步数量、最后同步时间、连接状态

### 3. 移动端导航优化
- 当前：侧边栏在移动端压缩为图标
- 目标：实现底部标签栏导航（移动端专属）
- 参考：iOS Tab Bar 设计模式

### 4. 错误状态设计
- 当前：全局错误页面较简陋
- 目标：设计友好的错误状态页面
- 包含：错误图标、描述、重试按钮、返回首页

### 5. 加载状态骨架屏
- 当前：部分组件使用 Loader2 旋转图标
- 目标：为关键组件添加骨架屏
- 组件：ConsoleView, AgentChatInterface, MetricsDashboard

### 6. 暗色主题一致性
- 当前：部分组件颜色硬编码
- 目标：统一使用 CSS 变量
- 变量：--background, --foreground, --primary, --accent

## 设计规范
- 配色：赛博朋克风格，深色背景 (#050505)
- 强调色：琥珀色 (领航员)、蓝色 (思想家)、紫色 (先知)
- 字体：等宽字体用于代码，无衬线字体用于 UI
- 动画：使用 Framer Motion，时长 200-500ms

## 技术约束
- 使用 Tailwind CSS 4.x
- 组件基于 Radix UI 原语
- 状态管理使用 Zustand
- 遵循现有文件结构和命名规范